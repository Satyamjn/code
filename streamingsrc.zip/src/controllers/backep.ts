// // contentController.ts - COMPLETE FIXED VERSION
// import { and, desc, eq, sql, inArray, count, gt } from "drizzle-orm";
// import { Request, Response } from "express";
// import { asyncHandler } from "../utils/asyncHandler.js";
// import { HTTP_STATUS } from "../constants/constant.js";
// import ApiResponse from "../utils/ApiResponse.js";
// import ApiError from "../utils/ApiError.js";
// import {
//   db,
//   uploads,
//   videos,
//   uploadAssets,
//   videoAssets ,
//   watchHistory,
//   profiles,
//   genres,
// } from "@digiiplex6112/db";

// // Active statuses
// const ACTIVE_STATUSES = ["READY", "APPROVED", "PUBLISHED"] as const;


// interface NewlyAddedItem {
//   id: string;
//   title: string;
//   description: string | null;
//   type: string | null;
//   contentKind: string;
//   genreId: string | null;
//   languageId: string | null;
//   createdAt: Date;
//   thumbnail: string | null;
//   trailer: string | null;
// }

// interface GenreSection {
//   genreId: string;
//   genreName: string;
//   totalCount: number;
//   items: NewlyAddedItem[];
// }

// interface PaginatedData<T> {
//   data: T[];
//   pagination: {
//     currentPage: number;
//     totalPages: number;
//     totalItems: number;
//     hasNextPage: boolean;
//     limit: number;
//   };
// }

// const attachAssets = async (uploadRows: any[]): Promise<any[]> => {
//   if (!uploadRows.length) return [];

//   const uploadIds = uploadRows.map((row) => row.id);

//   const assets = await db
//     .select()
//     .from(uploadAssets)
//     .where(
//       and(
//         inArray(uploadAssets.uploadId, uploadIds),
//         eq(uploadAssets.isLatest, true),
//         eq(uploadAssets.deletedFlg, false)
//       )
//     );

//   const assetsByUploadId: Record<string, any[]> = assets.reduce((acc: Record<string, any[]>, asset) => {
//     if (!acc[asset.uploadId]) acc[asset.uploadId] = [];
//     acc[asset.uploadId].push(asset);
//     return acc;
//   }, {});

//   return uploadRows.map((upload) => ({
//     id: upload.id,
//     title: upload.title,
//     description: upload.description,
//     type: upload.type,
//     contentKind: upload.contentKind,
//     genreId: upload.genreId,
//     languageId: upload.languageId,
//     createdAt: upload.createdAt,
//     thumbnail: assetsByUploadId[upload.id]?.find((a) => a.assetRole === "THUMBNAIL")?.masterPlaylistUrl || null,
//     trailer: assetsByUploadId[upload.id]?.find((a) => a.assetRole === "TRAILER")?.masterPlaylistUrl || null,
//   }));
// };


// export const getContinueWatching = asyncHandler(async (req: Request, res: Response) => {
//   const userId = req.user.id; 

//   const page = Math.max(Number(req.query.page) || 1, 1);
//   const limit = Math.max(Number(req.query.limit) || 6, 1);
//   const offset = (page - 1) * limit;

//   const historyData = await db
//     .select({
//       id: watchHistory.id,
//       position: watchHistory.position,
//       duration: watchHistory.duration,
//       watchedAt: watchHistory.watchedAt,
//       videoId: watchHistory.videoId,
//       videoAssetId: watchHistory.videoAssetId,
//     })
//     .from(watchHistory)
//     .where(
//       and(
//         eq(watchHistory.userId, userId),
//         eq(watchHistory.completed, false),
//         gt(watchHistory.position, 0)
//       )
//     )
//     .orderBy(desc(watchHistory.watchedAt))
//     .limit(limit)
//     .offset(offset);

//   // ---------------- EMPTY ----------------
//   if (!historyData.length) {
//     return res.status(200).json(
//       new ApiResponse(200, "No continue watching data", {
//         data: [],
//         pagination: {
//           page,
//           limit,
//           total: 0,
//           hasNextPage: false,
//         },
//       })
//     );
//   }

//   // ---------------- VIDEO IDS ----------------
//   const videoIds = historyData.map((h) => h.videoId);

//   // ---------------- VIDEOS ----------------
//   const videosData = await db
//     .select()
//     .from(videos)
//     .where(inArray(videos.id, videoIds));

//   // ---------------- ASSETS ----------------
//   const assetsData = await db
//     .select()
//     .from(videoAssets)
//     .where(inArray(videoAssets.videoId, videoIds));

//   const videoMap = new Map(videosData.map((v) => [v.id, v]));
//   const assetMap = new Map(assetsData.map((a) => [a.videoId, a]));

//   // ---------------- FORMAT ----------------
//   const result = historyData.map((item) => {
//     const video = videoMap.get(item.videoId);
//     const asset = assetMap.get(item.videoId);

//     const position = item.position ?? 0;
//     const duration = item.duration ?? 0;

//     return {
//       id: video?.id ?? null,
//       title: video?.title ?? null,
//       description: video?.description ?? null,
//       thumbnail: asset?.thumbnailUrl ?? asset?.posterUrl ?? null,
//       position,
//       duration,
//       progress: duration ? Math.round((position / duration) * 100) : 0,
//       watchedAt: item.watchedAt,
//     };
//   });

//   // ---------------- RESPONSE ----------------
//   return res.status(200).json(
//     new ApiResponse(200, "Continue watching fetched successfully", {
//       data: result,
//       pagination: {
//         page,
//         limit,
//         total: historyData.length,
//         hasNextPage: historyData.length === limit,
//       },
//     })
//   );
// });


// export const getTop10 = asyncHandler(async (req: Request, res: Response) => {
//   const profileId = Array.isArray(req.params.profileId)
//     ? req.params.profileId[0]
//     : req.params.profileId;

//   const page = Number(req.query.page) || 1;
//   const limit = Number(req.query.limit) || 10;
//   const offset = (page - 1) * limit;

  
//   const profileData = await db
//     .select()
//     .from(profiles)
//     .where(eq(profiles.id, profileId))
//     .limit(1);

//   const profile = profileData[0];

//   if (!profile) {
//     throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");
//   }

//   const userId = profile.userId;

  
//   const topContent = await db
//     .select({
//       videoId: watchHistory.videoId,
//       viewCount: count(watchHistory.id).as("viewCount"),
//     })
//     .from(watchHistory)
//     .where(eq(watchHistory.userId, userId))
//     .groupBy(watchHistory.videoId)
//     .orderBy(sql`COUNT(${watchHistory.id}) DESC`)
//     .limit(limit)
//     .offset(offset);


//   if (!topContent.length) {
//     return res.status(200).json(
//       new ApiResponse(200, "No top content", {
//         data: [],
//         pagination: {
//           currentPage: page,
//           totalPages: 0,
//           totalItems: 0,
//           hasNextPage: false,
//           limit,
//         },
//       })
//     );
//   }


//   const videoIds = topContent.map((t) => t.videoId);

//   const videosData = await db
//     .select()
//     .from(videos)
//     .where(inArray(videos.id, videoIds));


//   const assetsData = await db
//     .select()
//     .from(videoAssets)
//     .where(inArray(videoAssets.videoId, videoIds));

//   const assetMap = new Map(assetsData.map((a) => [a.videoId, a]));
//   const videoMap = new Map(videosData.map((v) => [v.id, v]));

  
//   const formatted = topContent.map((item, index) => {
//     const video = videoMap.get(item.videoId);
//     const asset = assetMap.get(item.videoId);

//     return {
//       id: video?.id || null,
//       title: video?.title || null,
//       description: video?.description || null,

//       contentKind: "VIDEO",

//       genreId: video?.genres?.[0] || null,
//       languageId: null,

//       createdAt: video?.createdAt || null,

//       thumbnail:
//         asset?.thumbnailUrl ||
//         asset?.posterUrl ||
//         null,

//       trailer:
//         asset?.masterPlaylistUrl || null,

//       rank: offset + index + 1,
//       views: Number(item.viewCount || 0),
//     };
//   });

  
//   const totalResult = await db
//     .select({ total: count(sql`DISTINCT ${watchHistory.videoId}`) })
//     .from(watchHistory)
//     .where(eq(watchHistory.userId, userId));

//   const total = Number(totalResult[0]?.total || 0);

  
//   return res.status(200).json(
//     new ApiResponse(200, "Top 10 fetched successfully", {
//       data: formatted,
//       pagination: {
//         currentPage: page,
//         totalPages: Math.ceil(total / limit),
//         totalItems: total,
//         hasNextPage: offset + limit < total,
//         limit,
//       },
//     })
//   );
// });


// export const getNewlyAdded = asyncHandler(
//   async (req: Request, res: Response): Promise<Response> => {
//     const profileId = Array.isArray(req.params.profileId)
//       ? req.params.profileId[0]
//       : req.params.profileId;

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const viewAll = req.query.viewAll === "true";

//     const finalLimit = viewAll ? limit : 6;
//     const offset = (page - 1) * finalLimit;

//     // PROFILE CHECK
//     const profile = await db.query.profiles.findFirst({
//       where: eq(profiles.id, profileId),
//     });

//     if (!profile) {
//       throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");
//     }

//     // FETCH DATA
//     const recentUploads = await db
//       .select()
//       .from(uploads)
//       .where(
//         and(
//           inArray(uploads.status, ACTIVE_STATUSES),
//           eq(uploads.deletedFlg, false)
//         )
//       )
//       .orderBy(desc(uploads.createdAt))
//       .limit(finalLimit)
//       .offset(offset);

//     if (!recentUploads.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No newly added content", {
//           data: [],
//           pagination: {
//             currentPage: page,
//             totalPages: 0,
//             totalItems: 0,
//             hasNextPage: false,
//             limit: finalLimit,
//           },
//         })
//       );
//     }

//     const uploadsWithAssets: any[] = await attachAssets(recentUploads);

//     const formattedData: {
//       id: string;
//       title: string;
//       description: string | null;
//       type: string | null;
//       contentKind: string;
//       genreId: string | null;
//       languageId: string | null;
//       createdAt: Date;
//       thumbnail: string | null;
//       trailer: string | null;
//     }[] = uploadsWithAssets.map((upload) => ({
//       id: upload.id,
//       title: upload.title ?? "",
//       description: upload.description ?? null,
//       type: upload.type ?? null,
//       contentKind: upload.contentKind ?? "VIDEO",
//       genreId: upload.genreId ?? null,
//       languageId: upload.languageId ?? null,
//       createdAt: upload.createdAt,
//       thumbnail: upload.thumbnail ?? null,
//       trailer: upload.trailer ?? null,
//     }));

//     const totalResult = await db
//       .select({ total: count() })
//       .from(uploads)
//       .where(
//         and(
//           inArray(uploads.status, ACTIVE_STATUSES),
//           eq(uploads.deletedFlg, false)
//         )
//       );

//     const total = Number(totalResult[0]?.total || 0);

//     return res.status(200).json(
//       new ApiResponse(200, "Newly added fetched successfully", {
//         data: formattedData,
//         pagination: {
//           currentPage: page,
//           totalPages: Math.ceil(total / finalLimit),
//           totalItems: total,
//           hasNextPage: offset + finalLimit < total,
//           limit: finalLimit,
//         },
//       })
//     );
//   }
// );

// export const getSelectedGenres = asyncHandler(
//   async (req: Request, res: Response): Promise<Response> => {
//     const profileId = Array.isArray(req.params.profileId)
//       ? req.params.profileId[0]
//       : req.params.profileId;

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const viewAll = req.query.viewAll === "true";
//     const specificGenreId = req.query.genreId
//       ? String(req.query.genreId)
//       : null;

//     const finalLimit = viewAll ? limit : 6;
//     const offset = (page - 1) * finalLimit;

//     const profile = await db.query.profiles.findFirst({
//       where: eq(profiles.id, profileId),
//     });

//     if (!profile) {
//       throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");
//     }

//     const selectedGenreIds: string[] = profile.genresIds || [];

//     if (!selectedGenreIds.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No genres selected for this profile", {
//           data: [],
//           pagination: { currentPage: page, limit: finalLimit },
//         })
//       );
//     }

//     let targetGenreIds = selectedGenreIds;

//     if (specificGenreId) {
//       targetGenreIds = selectedGenreIds.includes(specificGenreId)
//         ? [specificGenreId]
//         : [];
//     }

//     if (!targetGenreIds.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No matching genre found", {
//           data: [],
//           pagination: { currentPage: page, limit: finalLimit },
//         })
//       );
//     }

//     const genreList = await db
//       .select({ id: genres.id, name: genres.name })
//       .from(genres)
//       .where(inArray(genres.id, targetGenreIds));

//     const result: GenreSection[] = [];

//     for (const genre of genreList) {
//       const content = await db
//         .select()
//         .from(uploads)
//         .where(
//           and(
//             eq(uploads.genreId, genre.id),
//             inArray(uploads.status, ACTIVE_STATUSES),
//             eq(uploads.deletedFlg, false)
//           )
//         )
//         .orderBy(desc(uploads.createdAt))
//         .limit(finalLimit)
//         .offset(offset);

//       const contentWithAssets = await attachAssets(content);

//       const items: NewlyAddedItem[] = contentWithAssets.map((item) => ({
//         id: item.id,
//         title: item.title ?? "",
//         description: item.description ?? null,
//         type: item.type ?? null,
//         contentKind: item.contentKind ?? "VIDEO",
//         genreId: item.genreId ?? null,
//         languageId: item.languageId ?? null,
//         createdAt: item.createdAt,
//         thumbnail: item.thumbnail ?? null,
//         trailer: item.trailer ?? null,
//       }));

//       result.push({
//         genreId: genre.id,
//         genreName: genre.name,
//         totalCount: content.length,
//         items,
//       });
//     }

//     return res.status(200).json(
//       new ApiResponse(200, "Selected genres fetched successfully", {
//         data: result,
//         pagination: {
//           currentPage: page,
//           limit: finalLimit,
//         },
//       })
//     );
//   }
// );


// export const getTop10 = asyncHandler(async (req: Request, res: Response) => {
//   const profileId = Array.isArray(req.params.profileId)
//     ? req.params.profileId[0]
//     : req.params.profileId;

//   const page = Math.max(Number(req.query.page) || 1, 1);
//   const limit = Math.max(Number(req.query.limit) || 10, 1);
//   const offset = (page - 1) * limit;

//   const languageId = req.query.languageId ? String(req.query.languageId) : null;
//   const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

//   // ✅ FIX: db.query nahi, db.select use karo
//   const profileData = await db
//     .select({ id: profiles.id })
//     .from(profiles)
//     .where(
//       and(
//         eq(profiles.id, profileId),
//         eq(profiles.userId, req.user.id)
//       )
//     )
//     .limit(1);

//   if (!profileData[0]) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//   // ✅ FIX: profile.userId nahi, seedha JWT se lo
//   const userId = req.user.id;

//   const topContent = await db
//     .select({
//       videoId: watchHistory.videoId,
//       viewCount: count(watchHistory.id).as("viewCount"),
//     })
//     .from(watchHistory)
//     .where(eq(watchHistory.userId, userId))
//     .groupBy(watchHistory.videoId)
//     .orderBy(sql`COUNT(${watchHistory.id}) DESC`)
//     .limit(limit)
//     .offset(offset);

//   if (!topContent.length) {
//     return res.status(200).json(
//       new ApiResponse(200, "No top content", {
//         data: [],
//         pagination: {
//           currentPage: page,
//           totalPages: 0,
//           totalItems: 0,
//           hasNextPage: false,
//           limit,
//         },
//       })
//     );
//   }

//   const videoIds = topContent.map((t) => t.videoId);

//   const videosData = await db
//     .select()
//     .from(videos)
//     .where(inArray(videos.id, videoIds));

//   const uploadIds = videosData.map((v) => v.uploadId).filter(Boolean);

//   const uploadsData = uploadIds.length
//     ? await db
//         .select()
//         .from(uploads)
//         .where(inArray(uploads.id, uploadIds as string[]))
//     : [];

//   const filteredUploadIds = new Set(
//     uploadsData
//       .filter((u) => {
//         if (languageId && u.languageId !== languageId) return false;
//         if (contentKind && u.contentKind !== contentKind) return false;
//         return true;
//       })
//       .map((u) => u.id)
//   );

//   const assetsData = await db
//     .select()
//     .from(videoAssets)
//     .where(inArray(videoAssets.videoId, videoIds));

//   const assetMap = new Map<string, any>();
//   for (const a of assetsData) {
//     if (!assetMap.has(a.videoId) || a.assetType === "MAIN") {
//       assetMap.set(a.videoId, a);
//     }
//   }

//   const videoMap = new Map(videosData.map((v) => [v.id, v]));
//   const uploadMap = new Map(uploadsData.map((u) => [u.id, u]));

//   const formatted = topContent
//     .map((item, index) => {
//       const video = videoMap.get(item.videoId);
//       if (!video) return null;
//       const upload = uploadMap.get(video.uploadId);
//       if (languageId || contentKind) {
//         if (!upload || !filteredUploadIds.has(upload.id)) return null;
//       }
//       const asset = assetMap.get(item.videoId);

//       return {
//         id: video.id,
//         title: video.title,
//         description: video.description ?? null,
//         type: upload?.type ?? null,
//         contentKind: upload?.contentKind ?? null,
//         genreId: upload?.genreId ?? null,
//         languageId: upload?.languageId ?? null,
//         createdAt: video.createdAt,
//         thumbnail: asset?.thumbnailUrl ?? asset?.posterUrl ?? null,
//         trailer: asset?.masterPlaylistUrl ?? null,
//         rank: offset + index + 1,
//         views: Number(item.viewCount || 0),
//       };
//     })
//     .filter(Boolean);

//   const [{ total }] = await db
//     .select({ total: count(sql`DISTINCT ${watchHistory.videoId}`) })
//     .from(watchHistory)
//     .where(eq(watchHistory.userId, userId));

//   const totalNum = Number(total || 0);

//   return res.status(200).json(
//     new ApiResponse(200, "Top 10 fetched successfully", {
//       data: formatted,
//       pagination: {
//         currentPage: page,
//         totalPages: Math.ceil(totalNum / limit),
//         totalItems: totalNum,
//         hasNextPage: offset + limit < totalNum,
//         limit,
//       },
//     })
//   );
// });


// export const getNewlyAdded = asyncHandler(
//   async (req: Request, res: Response): Promise<Response> => {
//     const profileId = Array.isArray(req.params.profileId)
//       ? req.params.profileId[0]
//       : req.params.profileId;

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const viewAll = req.query.viewAll === "true";

//     const languageId = req.query.languageId ? String(req.query.languageId) : null;
//     const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

//     const finalLimit = viewAll ? limit : 6;
//     const offset = (page - 1) * finalLimit;

//     // ✅ FIX: db.query.profiles.findFirst nahi, db.select use karo
//     const profileData = await db
//       .select({ id: profiles.id })
//       .from(profiles)
//       .where(
//         and(
//           eq(profiles.id, profileId),
//           eq(profiles.userId, req.user.id)
//         )
//       )
//       .limit(1);

//     if (!profileData[0]) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//     // profileData use nahi hota yahan — sirf validate kiya
//     const whereClause = buildUploadFilters({ languageId, contentKind });

//     const recentUploads = await db
//       .select()
//       .from(uploads)
//       .where(whereClause)
//       .orderBy(desc(uploads.createdAt))
//       .limit(finalLimit)
//       .offset(offset);

//     if (!recentUploads.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No newly added content", {
//           data: [],
//           pagination: {
//             currentPage: page,
//             totalPages: 0,
//             totalItems: 0,
//             hasNextPage: false,
//             limit: finalLimit,
//           },
//         })
//       );
//     }

//     const uploadsWithAssets = await attachAssets(recentUploads);

//     const [{ total }] = await db
//       .select({ total: count() })
//       .from(uploads)
//       .where(whereClause);

//     const totalNum = Number(total || 0);

//     return res.status(200).json(
//       new ApiResponse(200, "Newly added fetched successfully", {
//         data: uploadsWithAssets,
//         pagination: {
//           currentPage: page,
//           totalPages: Math.ceil(totalNum / finalLimit),
//           totalItems: totalNum,
//           hasNextPage: offset + finalLimit < totalNum,
//           limit: finalLimit,
//         },
//       })
//     );
//   }
// );


// export const getSelectedGenres = asyncHandler(
//   async (req: Request, res: Response): Promise<Response> => {
//     const profileId = Array.isArray(req.params.profileId)
//       ? req.params.profileId[0]
//       : req.params.profileId;

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const viewAll = req.query.viewAll === "true";
//     const specificGenreId = req.query.genreId ? String(req.query.genreId) : null;

//     const languageId = req.query.languageId ? String(req.query.languageId) : null;
//     const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

//     const finalLimit = viewAll ? limit : 6;
//     const offset = (page - 1) * finalLimit;

//     // ✅ FIX: genresIds bhi select karo, db.query nahi
//     const profileData = await db
//       .select({ id: profiles.id, genresIds: profiles.genresIds })
//       .from(profiles)
//       .where(
//         and(
//           eq(profiles.id, profileId),
//           eq(profiles.userId, req.user.id)
//         )
//       )
//       .limit(1);

//     if (!profileData[0]) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//     // ✅ FIX: profile nahi, profileData[0] use karo
//     const selectedGenreIds: string[] = profileData[0].genresIds || [];

//     if (!selectedGenreIds.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No genres selected for this profile", {
//           data: [],
//           pagination: { currentPage: page, limit: finalLimit },
//         })
//       );
//     }

//     let targetGenreIds = selectedGenreIds;
//     if (specificGenreId) {
//       targetGenreIds = selectedGenreIds.includes(specificGenreId)
//         ? [specificGenreId]
//         : [];
//     }

//     if (!targetGenreIds.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No matching genre found", {
//           data: [],
//           pagination: { currentPage: page, limit: finalLimit },
//         })
//       );
//     }

//     const genreList = await db
//       .select({ id: genres.id, name: genres.name })
//       .from(genres)
//       .where(inArray(genres.id, targetGenreIds));

//     const result: GenreSection[] = [];

//     for (const genre of genreList) {
//       const whereClause = buildUploadFilters({
//         genreId: genre.id,
//         languageId,
//         contentKind,
//       });

//       const [{ total }] = await db
//         .select({ total: count() })
//         .from(uploads)
//         .where(whereClause);

//       const totalCount = Number(total || 0);

//       const content = await db
//         .select()
//         .from(uploads)
//         .where(whereClause)
//         .orderBy(desc(uploads.createdAt))
//         .limit(finalLimit)
//         .offset(offset);

//       const contentWithAssets = await attachAssets(content);

//       result.push({
//         genreId: genre.id,
//         genreName: genre.name,
//         totalCount,
//         items: contentWithAssets,
//       });
//     }

//     return res.status(200).json(
//       new ApiResponse(200, "Selected genres fetched successfully", {
//         data: result,
//         pagination: {
//           currentPage: page,
//           limit: finalLimit,
//         },
//       })
//     );
//   }
// );