import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { CssBaseline, ThemeProvider } from "@mui/material";
import { theme } from "./theme/theme";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const queryClient = new QueryClient();
import "./main.css"
ReactDOM.createRoot(document.getElementById("root")).render(

  
  <React.StrictMode>
      <BrowserRouter>
 <QueryClientProvider client={queryClient}>
    <ThemeProvider theme={theme}>
      <CssBaseline />

      <App />
    </ThemeProvider>
    </QueryClientProvider>
      </BrowserRouter>
  </React.StrictMode>,
);
