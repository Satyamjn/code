import { Request, Response, NextFunction } from "express";
import ApiError from "../utils/ApiError.js";
import { HTTP_STATUS } from "../constants/constant.js";
import { verifyAccessToken } from "../utils/jwt.js";
import { ACCESS_TOKEN_COOKIE } from "../utils/authCookies.js";
import { db, Users } from "@digiiplex6112/db";  // ← ADD
import { eq } from "drizzle-orm";               // ← ADD

export const authMiddleware = async (
  req: Request,
  _res: Response,
  next: NextFunction,
) => {
  const authHeader = req.headers.authorization;
  const token =
    req.cookies?.[ACCESS_TOKEN_COOKIE] ||
    (authHeader?.startsWith("Bearer ") ? authHeader.split(" ")[1] : undefined);

  if (!token) {
    throw new ApiError(HTTP_STATUS.UNAUTHORIZED, "Token missing");
  }

  try {
    const decoded = await verifyAccessToken(token);

    // ← NEW: DB se user fetch karo aur checks karo
    const [user] = await db
      .select({
        id: Users.id,
        role: Users.role,
        isActive: Users.isActive,
        isDeleted: Users.isDeleted,
        tokenVersion: Users.tokenVersion,
      })
      .from(Users)
      .where(eq(Users.id, decoded.id))
      .limit(1);

    if (!user || user.isDeleted) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "User not found");
    }

    if (!user.isActive) {
      throw new ApiError(HTTP_STATUS.FORBIDDEN, "Account banned. Please contact support.");
    }

    // ← NEW: tokenVersion mismatch check
    if (decoded.tokenVersion !== user.tokenVersion) {
      throw new ApiError(HTTP_STATUS.UNAUTHORIZED, "Session expired. Please login again.");
    }

    // purana code same hai — koi change nahi
    req.user = decoded;
    next();
  } catch (err) {
    if (err instanceof ApiError) throw err; // ← ApiError as-is throw karo
    throw new ApiError(HTTP_STATUS.UNAUTHORIZED, "Invalid token");
  }
};