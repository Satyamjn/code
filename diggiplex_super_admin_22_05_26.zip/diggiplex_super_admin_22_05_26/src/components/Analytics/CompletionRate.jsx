import React, { useState, useEffect } from "react";
import { Box, Typography, Paper } from "@mui/material";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { COLORS } from "../../theme/theme";

const CompletionRate = () => {
  const [data, setData] = useState([
    { name: "Video 1", rate: 78 },
    { name: "Video 2", rate: 82 },
    { name: "Video 3", rate: 65 },
    { name: "Video 4", rate: 91 },
    { name: "Video 5", rate: 73 },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setData(prev => prev.map(item => ({
        ...item,
        rate: Math.min(100, Math.max(50, item.rate + Math.floor(Math.random() * 10) - 3)),
      })));
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Paper sx={{ background: COLORS.background, p: 2 }}>
      <Typography variant="h6" sx={{ color: COLORS.primary, mb: 2 }}>Completion Rate (%) - Live</Typography>
      <ResponsiveContainer width="100%" height={400}>
        <BarChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#333" />
          <XAxis dataKey="name" stroke={COLORS.textMuted} />
          <YAxis stroke={COLORS.textMuted} />
          <Tooltip contentStyle={{ backgroundColor: COLORS.background, borderColor: COLORS.primary }} />
          <Bar dataKey="rate" radius={[8, 8, 0, 0]}>
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={entry.rate > 80 ? COLORS.success : entry.rate > 60 ? COLORS.primary : COLORS.warning} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </Paper>
  );
};

export default CompletionRate;