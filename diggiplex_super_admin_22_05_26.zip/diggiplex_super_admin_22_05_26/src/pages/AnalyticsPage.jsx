// export { default } from "../components/Analytics/AnalyticsPage";

import React, { useState } from "react";
import { Box, Typography, Tabs, Tab, Paper, Button, Menu, MenuItem } from "@mui/material";
import { Download, PictureAsPdf, TableChart } from "@mui/icons-material";
import WatchTimes from "../components/Analytics/WatchTimes";
import CompletionRate from "../components/Analytics/CompletionRate";
import RevenueHistory from "../components/Analytics/RevenueHistory";
import BoostContent from "../components/Analytics/BoostContent";
import { COLORS } from "../theme/theme";

const AnalyticsPage = () => {
  const [tabValue, setTabValue] = useState(0);
  const [exportAnchorEl, setExportAnchorEl] = useState(null);

  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 3 }}>
        <Typography variant="h5" sx={{ fontWeight: 700, color: COLORS.primary }}>
          Analytics Dashboard
        </Typography>
        <Button
          variant="outlined"
          startIcon={<Download />}
          onClick={(e) => setExportAnchorEl(e.currentTarget)}
          sx={{ color: COLORS.primary, borderColor: COLORS.primary, "&:hover": { borderColor: COLORS.primary, backgroundColor: `${COLORS.primary}10` } }}
        >
          Export Data
        </Button>
        <Menu anchorEl={exportAnchorEl} open={Boolean(exportAnchorEl)} onClose={() => setExportAnchorEl(null)}>
          <MenuItem onClick={() => setExportAnchorEl(null)}><PictureAsPdf sx={{ mr: 1 }} /> Export as PDF</MenuItem>
          <MenuItem onClick={() => setExportAnchorEl(null)}><TableChart sx={{ mr: 1 }} /> Export as Excel</MenuItem>
        </Menu>
      </Box>

      <Paper sx={{ background: COLORS.background, borderRadius: "20px", border: `1px solid ${COLORS.primary}20` }}>
        <Tabs
          value={tabValue}
          onChange={(e, v) => setTabValue(v)}
          sx={{
            borderBottom: `1px solid ${COLORS.primary}20`,
            "& .MuiTab-root": { color: COLORS.textMuted, "&.Mui-selected": { color: COLORS.primary } },
            "& .MuiTabs-indicator": { backgroundColor: COLORS.primary },
          }}
        >
          <Tab label="Watch Time" />
          <Tab label="Completion Rate" />
          <Tab label="Revenue History" />
          <Tab label="Boost Content" />
        </Tabs>

        <Box sx={{ p: 3 }}>
          {tabValue === 0 && <WatchTimes />}
          {tabValue === 1 && <CompletionRate />}
          {tabValue === 2 && <RevenueHistory />}
          {tabValue === 3 && <BoostContent />}
        </Box>
      </Paper>
    </Box>
  );
};

export default AnalyticsPage;