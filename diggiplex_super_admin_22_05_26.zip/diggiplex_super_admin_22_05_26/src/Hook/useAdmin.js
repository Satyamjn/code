// src/Hook/useAdmin.js
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { createAdmin, adminList, adminDetails, updateAdmin, deleteAdmin } from "../Api/api";
import { toast } from "react-toastify";

// ================= GET ADMIN LIST =================
export const useGetAdmins = (page, limit) => {
  return useQuery({
    queryKey: ["admins", page, limit],
    queryFn: () => adminList({ page, limit }), 
    keepPreviousData: true, 
  });
};


// ================= GET ADMIN DETAILS =================
export const useGetAdminDetails = (id) => {
  return useQuery({
    queryKey: ["admin", id],
    queryFn: () => adminDetails(id),
    enabled: !!id, 
  });
};

// ================= CREATE ADMIN =================
export const useCreateAdmin = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: createAdmin,
    onSuccess: () => {
      toast.success("Admin created successfully!");
      queryClient.invalidateQueries({ queryKey: ["admins"] });
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Failed to create admin"
      );
    },
  });
};

// ================= UPDATE ADMIN =================
export const useUpdateAdmin = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateAdmin,
    onSuccess: () => {
      toast.success("Admin updated successfully!");
      queryClient.invalidateQueries({ queryKey: ["admins"] });
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Failed to update admin"
      );
    },
  });
};

// ================= DELETE ADMIN =================
export const useDeleteAdmin = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteAdmin,
    onSuccess: () => {
      toast.success("Admin deleted successfully!");
      queryClient.invalidateQueries({ queryKey: ["admins"] });
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Failed to delete admin"
      );
    },
  });
};