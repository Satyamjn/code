import React, { useState } from "react";
import {
  Container,
  Box,
  Typography,
  TextField,
  Button,
  Paper,
  Alert,
  CircularProgress,
  ThemeProvider,
  createTheme,
  CssBaseline,
  InputAdornment,
  IconButton,
} from "@mui/material";
import { styled } from "@mui/material/styles";
import EmailIcon from "@mui/icons-material/Email";
import LockIcon from "@mui/icons-material/Lock";
import Visibility from "@mui/icons-material/Visibility";
import VisibilityOff from "@mui/icons-material/VisibilityOff";
import LoginIcon from "@mui/icons-material/Login";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import { useNavigate } from "react-router-dom";
import { useLogin } from "../Hook/userLogin";
import { toast } from "react-toastify";
// Custom theme with specified colors
const theme = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#f5c77a", // text color / primary accent
    },
    background: {
      default: "#1C1616",
      paper: "#1C1616",
    },
    text: {
      primary: "#f5c77a",
      secondary: "#e0cba0",
    },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
      letterSpacing: "-0.5px",
      color: "#f5c77a",
    },
    body1: {
      color: "#e0cba0",
    },
  },
  shape: {
    borderRadius: 16,
  },
  components: {
    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            backgroundColor: "#2a2323",
            borderRadius: "12px",
            "& fieldset": {
              borderColor: "#f5c77a40",
            },
            "&:hover fieldset": {
              borderColor: "#f5c77a",
            },
            "&.Mui-focused fieldset": {
              borderColor: "#f5c77a",
            },
          },
          "& .MuiInputLabel-root": {
            color: "#f5c77a",
          },
          "& .MuiInputBase-input": {
            color: "#f5c77a",
          },
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: "40px",
          padding: "12px 24px",
          fontWeight: 600,
          textTransform: "none",
          fontSize: "1rem",
        },
      },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: "none",
        },
      },
    },
  },
});

// Styled Paper component for glassmorphic effect
const StyledPaper = styled(Paper)(({ theme }) => ({
  background: "rgba(28, 22, 22, 0.95)",
  backdropFilter: "blur(2px)",
  borderRadius: "32px",
  padding: theme.spacing(5, 4),
  boxShadow:
    "0 25px 45px -12px rgba(0,0,0,0.5), 0 0 0 1px rgba(245,199,122,0.15)",
  transition: "transform 0.2s ease",
  width: "100%",
}));

const ThankYouPaper = styled(Paper)(({ theme }) => ({
  background: "rgba(28, 22, 22, 0.98)",
  borderRadius: "40px",
  padding: theme.spacing(6, 4),
  textAlign: "center",
  boxShadow: "0 30px 50px -20px black",
  border: `1px solid ${theme.palette.primary.main}40`,
  animation: "fadeSlideUp 0.5s ease-out",
}));

// Keyframes for animation
const GlobalStyle = () => (
  <style>
    {`
      @keyframes fadeSlideUp {
        from {
          opacity: 0;
          transform: translateY(30px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
      .thankyou-animation {
        animation: fadeSlideUp 0.5s ease-out;
      }
    `}
  </style>
);

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();

 const loginMutation = useLogin();

  const loading = loginMutation.isPending;

  // validation
  const validateForm = () => {
    if (!email.trim()) return setError("Email required"), false;
    if (!password.trim()) return setError("Password required"), false;
    return true;
  };
  //  handle login
const handleLogin = (e) => {
  e.preventDefault();
  setError("");

  if (!validateForm()) return;

  loginMutation.mutate(
    { email, password },
    {
      onSuccess: (data) => {
        console.log("Login Success:", data);

        // ❌ Status false = login failed
        if (!data?.status) {
          toast.error(data?.message || "Login failed");
          setError(data?.message || "Invalid credentials");
          navigate("/");
          return;
        }

        const token = data?.data?.accessToken;

        // ❌ Token nahi mila
        if (!token) {
          toast.error("Authentication failed. Please try again.");
          setError("No token received");
          navigate("/");
          return;
        }

        // ✅ Tokens save karo
        localStorage.setItem("accessToken", data?.data?.accessToken);
        localStorage.setItem("refreshToken", data?.data?.refreshToken);

        // ✅ User info save karo
        localStorage.setItem(
          "user",
          JSON.stringify({
            id: data?.data?.id,
            email: data?.data?.email,
            role: data?.data?.role,
          })
        );

        toast.success(data?.message || "Login successful");
        navigate("/dashboard");
      },

      onError: (err) => {
        const statusCode = err?.response?.status;

        // ✅ 401 = wrong email/password
        if (statusCode === 401) {
          const msg = err?.response?.data?.message || "Invalid email or password";
          toast.error(msg);
          setError(msg);
          navigate("/");
          return;
        }

        // Other errors
        const msg =
          err?.response?.data?.message ||
          err?.message ||
          "Login failed. Please try again.";

        toast.error(msg);
        setError(msg);
        navigate("/");
      },
    }
  );
}; 
  

  // Login form view
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <GlobalStyle />
      <Container
        maxWidth="sm"
        sx={{
          minHeight: "100vh",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          py: 3,
        }}
      >
        <StyledPaper elevation={6}>
          {/* Logo / Project Name */}
          <Box textAlign="center" mb={4}>
            <Typography
              variant="h4"
              component="h1"
              sx={{
                fontWeight: 800,
                letterSpacing: "-0.02em",
                background: "linear-gradient(135deg, #f5c77a 0%, #ffdf9c 100%)",
                backgroundClip: "text",
                WebkitBackgroundClip: "text",
                color: "#f5c77a",
                textShadow: "0 2px 4px rgba(0,0,0,0.2)",
              }}
            >
              DIGIIPLEX
            </Typography>
          </Box>

          {/* Error Alert */}
          {error && (
            <Alert
              severity="error"
              sx={{
                mb: 3,
                backgroundColor: "rgba(211,47,47,0.15)",
                color: "#ffaa88",
                borderRadius: "16px",
                "& .MuiAlert-icon": {
                  color: "#f5c77a",
                },
              }}
              onClose={() => setError("")}
            >
              {error}
            </Alert>
          )}

         

          <form onSubmit={handleLogin}>
            {/* Email Field */}
            <TextField
              fullWidth
              label="Email Address"
              type="email"
              variant="outlined"
              margin="normal"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              disabled={loading}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <EmailIcon sx={{ color: "#f5c77a" }} />
                  </InputAdornment>
                ),
              }}
              sx={{ mb: 2.5 }}
            />

            {/* Password Field */}
            <TextField
              fullWidth
              label="Password"
              type={showPassword ? "text" : "password"}
              variant="outlined"
              margin="normal"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={loading}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <LockIcon sx={{ color: "#f5c77a" }} />
                  </InputAdornment>
                ),
                endAdornment: (
                  <InputAdornment position="end">
                    <IconButton
                      aria-label="toggle password visibility"
                      onClick={() => setShowPassword(!showPassword)}
                      edge="end"
                      sx={{ color: "#f5c77a" }}
                    >
                      {showPassword ? <VisibilityOff /> : <Visibility />}
                    </IconButton>
                  </InputAdornment>
                ),
              }}
              sx={{ mb: 3 }}
            />

            {/* Login Button */}
            {/* Login Button */}
            <Box sx={{ display: "flex", justifyContent: "center" }}>
              <Button
                type="submit"
                variant="contained"
                size="large"
                disabled={loading}
                sx={{
                  backgroundColor: "#f5c77a",
                  color: "#1C1616",
                  fontWeight: 700,
                  fontSize: "1rem",
                  py: 1.5,
                  px: 4,
                  minWidth: "200px",
                  borderRadius: "40px",
                  "&:hover": {
                    backgroundColor: "#ffda96",
                    transform: "scale(1.01)",
                    transition: "all 0.2s",
                  },
                  "&.Mui-disabled": {
                    backgroundColor: "#f5c77a80",
                    color: "#1C1616",
                  },
                }}
                startIcon={!loading && <LoginIcon />}
              >
                {loading ? (
                  <CircularProgress size={24} sx={{ color: "#1C1616" }} />
                ) : (
                  "Login "
                )}
              </Button>
            </Box>

          </form>
        </StyledPaper>
      </Container>
    </ThemeProvider>
  );
};

export default Login;
