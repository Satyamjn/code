import {
  Box, Typography, Grid, Card, CardContent, Chip,
  Table, TableBody, TableCell, TableContainer, TableHead,
  TableRow, Divider, LinearProgress, Button
} from "@mui/material";
import AccountBalanceWalletRoundedIcon from "@mui/icons-material/AccountBalanceWalletRounded";
import TrendingUpRoundedIcon from "@mui/icons-material/TrendingUpRounded";
import CallMadeRoundedIcon from "@mui/icons-material/CallMadeRounded";
import DownloadRoundedIcon from "@mui/icons-material/DownloadRounded";
import { COLORS } from "../../theme/theme";

const MONTHLY = [
  { month: "Jun", value: 12400 }, { month: "Jul", value: 18200 }, { month: "Aug", value: 15600 },
  { month: "Sep", value: 21800 }, { month: "Oct", value: 28400 }, { month: "Nov", value: 24200 },
  { month: "Dec", value: 32800, current: true },
];

const TRANSACTIONS = [
  { id: "TXN-2847", date: "Dec 12, 2024", source: "Ad Revenue", amount: "₹8,240", status: "Paid", type: "credit" },
  { id: "TXN-2846", date: "Dec 10, 2024", source: "Subscription Share", amount: "₹12,500", status: "Paid", type: "credit" },
  { id: "TXN-2845", date: "Dec 8, 2024", source: "Super Thanks", amount: "₹3,180", status: "Pending", type: "credit" },
  { id: "TXN-2844", date: "Dec 5, 2024", source: "Channel Membership", amount: "₹6,400", status: "Paid", type: "credit" },
  { id: "TXN-2843", date: "Dec 3, 2024", source: "Payout Withdrawal", amount: "₹45,000", status: "Processed", type: "debit" },
  { id: "TXN-2842", date: "Nov 28, 2024", source: "Ad Revenue", amount: "₹9,840", status: "Paid", type: "credit" },
  { id: "TXN-2841", date: "Nov 22, 2024", source: "Brand Deal", amount: "₹28,000", status: "Paid", type: "credit" },
];

const STATUS_STYLES = {
  Paid: { bg: "rgba(76,175,125,0.12)", border: "rgba(76,175,125,0.3)", color: COLORS.success },
  Pending: { bg: "rgba(245,199,122,0.12)", border: "rgba(245,199,122,0.3)", color: COLORS.accent },
  Processed: { bg: "rgba(123,97,255,0.12)", border: "rgba(123,97,255,0.3)", color: "#7B61FF" },
};

const REVENUE_SOURCES = [
  { name: "Ad Revenue", pct: 42, amount: "₹1,02,400", color: COLORS.accent },
  { name: "Subscription Share", pct: 28, amount: "₹68,200", color: "#7B61FF" },
  { name: "Brand Deals", pct: 18, amount: "₹43,800", color: "#FF6B6B" },
  { name: "Channel Membership", pct: 12, amount: "₹29,200", color: COLORS.success },
];

function RevenueBarChart() {
  const max = Math.max(...MONTHLY.map((d) => d.value));
  return (
    <Box sx={{ display: "flex", alignItems: "flex-end", gap: 1.5, height: 140, px: 1 }}>
      {MONTHLY.map(({ month, value, current }, i) => (
        <Box key={i} sx={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 0.5, height: "100%" }}>
          <Typography sx={{ fontSize: "0.62rem", color: current ? COLORS.accent : COLORS.textMuted, fontWeight: current ? 700 : 400 }}>
            ₹{(value / 1000).toFixed(0)}K
          </Typography>
          <Box sx={{ flex: 1, width: "100%", display: "flex", flexDirection: "column", justifyContent: "flex-end" }}>
            <Box
              sx={{
                width: "100%",
                height: `${(value / max) * 100}%`,
                borderRadius: "8px 8px 4px 4px",
                background: current
                  ? `linear-gradient(to top, ${COLORS.accentDark}, ${COLORS.accent})`
                  : "rgba(245,199,122,0.18)",
                boxShadow: current ? `0 0 20px rgba(245,199,122,0.4)` : "none",
                minHeight: 8,
                transition: "height 0.3s",
              }}
            />
          </Box>
          <Typography sx={{ fontSize: "0.62rem", color: current ? COLORS.accent : COLORS.textMuted }}>{month}</Typography>
        </Box>
      ))}
    </Box>
  );
}

export default function RevenuePage() {
  return (
    <Box>
      <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 3 }}>
        <Box>
          <Typography variant="h5" sx={{ fontWeight: 700, mb: 0.5 }}>Revenue</Typography>
          <Typography sx={{ color: COLORS.textSecondary, fontSize: "0.88rem" }}>
            Earnings overview and payout history
          </Typography>
        </Box>
        <Button
          variant="outlined"
          size="small"
          startIcon={<DownloadRoundedIcon />}
          sx={{
            borderColor: COLORS.border,
            color: COLORS.textSecondary,
            borderRadius: "10px",
            "&:hover": { borderColor: COLORS.accent, color: COLORS.accent },
          }}
        >
          Export
        </Button>
      </Box>

      <Grid container spacing={2.5}>
        {/* Revenue summary */}
        <Grid item xs={12} md={4}>
          <Card
            sx={{
              background: `linear-gradient(135deg, rgba(245,199,122,0.12) 0%, rgba(196,154,78,0.06) 100%)`,
              border: `1px solid rgba(245,199,122,0.25)`,
              position: "relative",
              overflow: "hidden",
            }}
          >
            <CardContent sx={{ p: 3, "&:last-child": { pb: 3 } }}>
              <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 2 }}>
                <Box
                  sx={{
                    width: 46, height: 46, borderRadius: "12px",
                    background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.accentDark})`,
                    display: "flex", alignItems: "center", justifyContent: "center",
                    boxShadow: `0 4px 16px rgba(245,199,122,0.3)`,
                  }}
                >
                  <AccountBalanceWalletRoundedIcon sx={{ color: "#0F0A0A", fontSize: 22 }} />
                </Box>
                <Chip
                  icon={<TrendingUpRoundedIcon style={{ fontSize: 12 }} />}
                  label="+32% MoM"
                  size="small"
                  sx={{
                    bgcolor: "rgba(76,175,125,0.12)",
                    border: "1px solid rgba(76,175,125,0.3)",
                    color: COLORS.success,
                    fontWeight: 700,
                    fontSize: "0.7rem",
                  }}
                />
              </Box>

              <Typography sx={{ fontSize: "0.8rem", color: COLORS.textSecondary, mb: 0.5 }}>
                Total Earnings (Dec 2024)
              </Typography>
              <Typography sx={{ fontSize: "2.2rem", fontWeight: 800, color: COLORS.accent, letterSpacing: "-0.03em", lineHeight: 1 }}>
                ₹2,43,600
              </Typography>
              <Typography sx={{ fontSize: "0.75rem", color: COLORS.textSecondary, mt: 0.8 }}>
                +₹58,400 compared to last month
              </Typography>

              <Divider sx={{ borderColor: "rgba(245,199,122,0.15)", my: 2.5 }} />

              <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                {[
                  { label: "Available", value: "₹1,84,200", color: COLORS.accent },
                  { label: "Pending", value: "₹59,400", color: COLORS.warning },
                ].map(({ label, value, color }) => (
                  <Box key={label}>
                    <Typography sx={{ fontSize: "0.68rem", color: COLORS.textSecondary }}>{label}</Typography>
                    <Typography sx={{ fontSize: "0.95rem", fontWeight: 700, color }}>{value}</Typography>
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Monthly chart */}
        <Grid item xs={12} md={5}>
          <Card>
            <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
              <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2 }}>
                <Box>
                  <Typography sx={{ fontSize: "0.92rem", fontWeight: 700 }}>Monthly Earnings</Typography>
                  <Typography sx={{ fontSize: "0.72rem", color: COLORS.textSecondary }}>Last 7 months</Typography>
                </Box>
                <Typography sx={{ fontSize: "0.72rem", color: COLORS.accent, fontWeight: 600 }}>₹32.8K Dec</Typography>
              </Box>
              <RevenueBarChart />
            </CardContent>
          </Card>
        </Grid>

        {/* Payout Status */}
        <Grid item xs={12} md={3}>
          <Card>
            <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
              <Typography sx={{ fontSize: "0.92rem", fontWeight: 700, mb: 0.5 }}>Payout Status</Typography>
              <Typography sx={{ fontSize: "0.72rem", color: COLORS.textSecondary, mb: 2.5 }}>Next payout: Dec 28</Typography>

              <Box
                sx={{
                  p: 2, borderRadius: "5px",
                  bgcolor: "rgba(76,175,125,0.08)",
                  border: "1px solid rgba(76,175,125,0.2)",
                  mb: 2,
                  display: "flex", alignItems: "center", gap: 1.5,
                }}
              >
                <Box sx={{ width: 10, height: 10, borderRadius: "50%", bgcolor: COLORS.success, boxShadow: `0 0 8px ${COLORS.success}` }} />
                <Box>
                  <Typography sx={{ fontSize: "0.8rem", fontWeight: 700, color: COLORS.success }}>Account Verified</Typography>
                  <Typography sx={{ fontSize: "0.68rem", color: COLORS.textSecondary }}>HDFC Bank •••• 4821</Typography>
                </Box>
              </Box>

              <Box sx={{ mb: 2 }}>
                <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.8 }}>
                  <Typography sx={{ fontSize: "0.75rem", color: COLORS.textSecondary }}>Threshold progress</Typography>
                  <Typography sx={{ fontSize: "0.75rem", fontWeight: 700, color: COLORS.accent }}>₹1,84K / ₹2L</Typography>
                </Box>
                <LinearProgress
                  variant="determinate"
                  value={92}
                  sx={{
                    height: 8,
                    "& .MuiLinearProgress-bar": {
                      background: `linear-gradient(90deg, ${COLORS.accentDark}, ${COLORS.accent})`,
                    },
                  }}
                />
                <Typography sx={{ fontSize: "0.68rem", color: COLORS.textMuted, mt: 0.5 }}>
                  ₹16K more to trigger payout
                </Typography>
              </Box>

              <Button
                variant="contained"
                fullWidth
                endIcon={<CallMadeRoundedIcon fontSize="small" />}
                sx={{
                  background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.accentDark})`,
                  color: "#0F0A0A",
                  fontWeight: 700,
                  fontSize: "0.8rem",
                  borderRadius: "5px",
                  py: 1,
                }}
              >
                Request Payout
              </Button>
            </CardContent>
          </Card>
        </Grid>

        {/* Revenue breakdown */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
              <Typography sx={{ fontSize: "0.92rem", fontWeight: 700, mb: 0.5 }}>Revenue Sources</Typography>
              <Typography sx={{ fontSize: "0.72rem", color: COLORS.textSecondary, mb: 2.5 }}>Breakdown by income type</Typography>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                {REVENUE_SOURCES.map(({ name, pct, amount, color }) => (
                  <Box key={name}>
                    <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.6 }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <Box sx={{ width: 8, height: 8, borderRadius: "50%", bgcolor: color, boxShadow: `0 0 6px ${color}` }} />
                        <Typography sx={{ fontSize: "0.78rem", color: COLORS.textSecondary }}>{name}</Typography>
                      </Box>
                      <Box sx={{ textAlign: "right" }}>
                        <Typography sx={{ fontSize: "0.78rem", fontWeight: 700, color }}>{amount}</Typography>
                        <Typography sx={{ fontSize: "0.65rem", color: COLORS.textMuted }}>{pct}%</Typography>
                      </Box>
                    </Box>
                    <LinearProgress
                      variant="determinate"
                      value={pct}
                      sx={{
                        height: 5,
                        "& .MuiLinearProgress-bar": { background: color },
                      }}
                    />
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Transaction history */}
        <Grid item xs={12} md={8}>
          <Card>
            <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
              <Box sx={{ display: "flex", justifyContent: "space-between", mb: 2.5 }}>
                <Box>
                  <Typography sx={{ fontSize: "0.92rem", fontWeight: 700 }}>Transaction History</Typography>
                  <Typography sx={{ fontSize: "0.72rem", color: COLORS.textSecondary }}>Recent revenue events</Typography>
                </Box>
                <Typography sx={{ fontSize: "0.75rem", color: COLORS.accent, cursor: "pointer", fontWeight: 600 }}>
                  View all →
                </Typography>
              </Box>
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell>Transaction</TableCell>
                      <TableCell>Date</TableCell>
                      <TableCell>Source</TableCell>
                      <TableCell align="right">Amount</TableCell>
                      <TableCell>Status</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {TRANSACTIONS.map((tx) => (
                      <TableRow key={tx.id} sx={{ "&:hover": { bgcolor: "rgba(255,255,255,0.02)" } }}>
                        <TableCell>
                          <Typography sx={{ fontSize: "0.78rem", fontWeight: 600, color: COLORS.textSecondary }}>
                            {tx.id}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Typography sx={{ fontSize: "0.78rem", color: COLORS.textSecondary }}>{tx.date}</Typography>
                        </TableCell>
                        <TableCell>
                          <Typography sx={{ fontSize: "0.78rem", color: COLORS.text }}>{tx.source}</Typography>
                        </TableCell>
                        <TableCell align="right">
                          <Typography
                            sx={{
                              fontSize: "0.82rem",
                              fontWeight: 700,
                              color: tx.type === "debit" ? COLORS.error : COLORS.success,
                            }}
                          >
                            {tx.type === "debit" ? "−" : "+"}{tx.amount}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          <Chip
                            label={tx.status}
                            size="small"
                            sx={{
                              bgcolor: STATUS_STYLES[tx.status].bg,
                              border: `1px solid ${STATUS_STYLES[tx.status].border}`,
                              color: STATUS_STYLES[tx.status].color,
                              fontWeight: 600,
                              fontSize: "0.68rem",
                              height: 20,
                            }}
                          />
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
