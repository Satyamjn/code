// src/pages/CreateLanguage.jsx
import React, { useState, useEffect } from "react";
import { toast } from "react-toastify";
import {
  useAddLanguage,
  useUpdateLanguage,
  useDeleteLanguage,
  useGetAllLanguages,
} from "../Hook/useLenguage";
const CreateLanguage = () => {
  const [formData, setFormData] = useState({
    name: "",
    image: null,
  });
  const [imagePreview, setImagePreview] = useState(null);
  const [error, setError] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  
  // Modal states
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedLanguage, setSelectedLanguage] = useState(null);
  const [deleteTarget, setDeleteTarget] = useState(null);
  const [editFormData, setEditFormData] = useState({
    name: "",
    image: null,
  });
  const [editImagePreview, setEditImagePreview] = useState(null);

  // Hooks
  const addLanguageMutation = useAddLanguage();
  const updateLanguageMutation = useUpdateLanguage();
  const deleteLanguageMutation = useDeleteLanguage();

  const {
    data: languagesData,
    isLoading,
    isError,
    error: fetchError,
    refetch,
  } = useGetAllLanguages(currentPage, itemsPerPage);

  // Get languages from response
  const languages = languagesData?.data?.languages || [];
  const pagination = languagesData?.data?.pagination || { 
    total: 0, 
    page: 1, 
    limit: itemsPerPage, 
    totalPages: 1 
  };
  const totalPages = pagination.totalPages || 1;

  // Handle form input change
  const handleInputChange = (field) => (event) => {
    setFormData({ ...formData, [field]: event.target.value });
    setError("");
  };

  // Handle image change for create
  const handleImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      // Validate file type
      if (!file.type.startsWith('image/')) {
        toast.error("Please select an image file");
        return;
      }
      
      // Validate file size (max 5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image size should be less than 5MB");
        return;
      }

      setFormData({ ...formData, image: file });
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle edit image change
  const handleEditImageChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error("Please select an image file");
        return;
      }
      
      if (file.size > 5 * 1024 * 1024) {
        toast.error("Image size should be less than 5MB");
        return;
      }

      setEditFormData({ ...editFormData, image: file });
      
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Validate form
  const validateForm = () => {
    if (!formData.name.trim()) {
      setError("Name is required");
      toast.error("Name is required");
      return false;
    }
    if (formData.name.trim().length < 2) {
      setError("Name must be at least 2 characters");
      toast.error("Name must be at least 2 characters");
      return false;
    }
    if (!formData.image) {
      setError("Image is required");
      toast.error("Image is required");
      return false;
    }
    return true;
  };

  // Create language
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    const formDataToSend = new FormData();
    formDataToSend.append('name', formData.name);
    formDataToSend.append('image', formData.image);

    addLanguageMutation.mutate(formDataToSend, {
      onSuccess: () => {
        setFormData({ name: "", image: null });
        setImagePreview(null);
        setError("");
        refetch();
      },
    });
  };

  // Open edit modal
  const handleEdit = (language) => {
    setSelectedLanguage(language);
    setEditFormData({
      name: language.name,
      image: null,
    });
    setEditImagePreview(language.image);
    setIsEditModalOpen(true);
  };

  // Update language
  const handleUpdate = () => {
    if (!editFormData.name.trim()) {
      toast.error("Name is required");
      return;
    }

    const formDataToSend = new FormData();
    formDataToSend.append('name', editFormData.name);
    if (editFormData.image) {
      formDataToSend.append('image', editFormData.image);
    }

    updateLanguageMutation.mutate(
      { id: selectedLanguage.id, data: formDataToSend },
      {
        onSuccess: () => {
          setIsEditModalOpen(false);
          setSelectedLanguage(null);
          setEditFormData({ name: "", image: null });
          setEditImagePreview(null);
          refetch();
        },
      }
    );
  };

  // Delete language
  const handleDelete = (id, name) => {
    setDeleteTarget({ id, name });
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;

    deleteLanguageMutation.mutate(deleteTarget.id, {
      onSuccess: () => {
        setIsDeleteModalOpen(false);
        setDeleteTarget(null);
        refetch();
      },
    });
  };

  // Open view modal
  const handleView = (language) => {
    setSelectedLanguage(language);
    setIsViewModalOpen(true);
  };

  // Close modals
  const closeModals = () => {
    setIsViewModalOpen(false);
    setIsEditModalOpen(false);
    setSelectedLanguage(null);
  };

  return (
    <div className="min-h-screen relative" style={{ background: 'rgba(15, 10, 10, 0.85)' }}>
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-6">
          <h5 className="text-xl font-bold text-[#f5c77a]">Language Management</h5>
          <p className="text-[#B3B3B3] text-sm mt-1">Create and manage languages</p>
        </div>

        {/* Form Card */}
        <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.125)] p-6 mb-8">
          <h6 className="text-md font-semibold text-[#f5c77a] mb-4">Create New Language</h6>
          <form onSubmit={handleSubmit}>
            {error && (
              <div className="mb-4 p-3 bg-[rgba(244,67,54,0.15)] border border-[rgba(244,67,54,0.3)] rounded-lg text-[#ffaa88] text-sm flex items-start gap-2">
                <i className="fas fa-exclamation-circle mt-0.5"></i>
                <span>{error}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#f5c77a]">
                  <i className="fas fa-language"></i>
                </div>
                <input
                  type="text"
                  placeholder="Language Name"
                  value={formData.name}
                  onChange={handleInputChange('name')}
                  disabled={addLanguageMutation.isPending}
                  className="w-full h-12 pl-10 pr-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition disabled:opacity-50"
                />
              </div>

              <div className="relative">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageChange}
                  disabled={addLanguageMutation.isPending}
                  className="w-full h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] text-white file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-[#f5c77a] file:text-[#0F0A0A] hover:file:bg-[#c49a4e] transition disabled:opacity-50"
                />
              </div>
            </div>

            {/* Image Preview */}
            {imagePreview && (
              <div className="mb-4">
                <p className="text-sm text-[#B3B3B3] mb-2">Image Preview:</p>
                <div className="w-32 h-32 rounded-lg overflow-hidden border border-[rgba(245,199,122,0.3)]">
                  <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={addLanguageMutation.isPending}
              className="h-12 px-6 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded-lg hover:shadow-[0_6px_28px_rgba(245,199,122,0.45)] disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 text-sm"
            >
              {addLanguageMutation.isPending ? (
                <>
                  <svg className="animate-spin h-4 w-4 text-[#0F0A0A]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span>Creating...</span>
                </>
              ) : (
                <>
                  <i className="fas fa-plus-circle"></i>
                  <span>Create Language</span>
                </>
              )}
            </button>
          </form>
        </div>

        {/* Languages List Table */}
        <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.125)] overflow-hidden">
          <div className="p-4 border-b border-[rgba(255,255,255,0.07)]">
            <h6 className="text-lg font-semibold text-[#f5c77a]">Languages List</h6>
            <p className="text-[#B3B3B3] text-sm mt-1">Total Languages: {pagination.total || 0}</p>
          </div>
          
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="flex justify-center items-center py-12">
                <svg className="animate-spin h-8 w-8 text-[#f5c77a]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              </div>
            ) : isError ? (
              <div className="text-center py-12 text-red-400">
                <i className="fas fa-exclamation-triangle text-3xl mb-2 block"></i>
                <p>{fetchError?.message || "Failed to load languages"}</p>
              </div>
            ) : languages?.length > 0 ? (
              <>
                <table className="w-full">
                  <thead className="bg-[#231D1D] border-b border-[rgba(255,255,255,0.07)]">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">S.No</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Image</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Name</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Status</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Created At</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[rgba(255,255,255,0.07)]">
                    {languages.map((language, index) => (
                      <tr key={language.id} className="hover:bg-[rgba(245,199,122,0.05)] transition">
                        <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                          {(currentPage - 1) * itemsPerPage + index + 1}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="w-12 h-12 rounded-lg overflow-hidden bg-[#231D1D] border border-[rgba(245,199,122,0.3)]">
                            <img src={language.image} alt={language.name} className="w-full h-full object-cover" />
                          </div>
                        </td>
                        <td className="px-6 py-4 text-sm text-white whitespace-nowrap">
                          {language.name}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {language.isActive ? (
                            <span className="px-2 py-1 text-xs rounded-full bg-[rgba(76,175,80,0.15)] text-[#4caf7d] border border-[rgba(76,175,80,0.3)]">
                              <i className="fas fa-check-circle mr-1"></i> Active
                            </span>
                          ) : (
                            <span className="px-2 py-1 text-xs rounded-full bg-[rgba(255,152,0,0.15)] text-[#ff9800] border border-[rgba(255,152,0,0.3)]">
                              <i className="fas fa-clock mr-1"></i> Inactive
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                          {new Date(language.createdAt).toLocaleDateString()}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleView(language)}
                              className="px-3 py-1 text-xs bg-[rgba(33,150,243,0.15)] text-[#2196f3] rounded hover:bg-[rgba(33,150,243,0.25)] transition flex items-center gap-1"
                            >
                              <i className="fas fa-eye"></i> View
                            </button>
                            <button
                              onClick={() => handleEdit(language)}
                              className="px-3 py-1 text-xs bg-[rgba(245,199,122,0.15)] text-[#f5c77a] rounded hover:bg-[rgba(245,199,122,0.25)] transition flex items-center gap-1"
                            >
                              <i className="fas fa-edit"></i> Edit
                            </button>
                            <button
                              onClick={() => handleDelete(language.id, language.name)}
                              className="px-3 py-1 text-xs bg-[rgba(244,67,54,0.15)] text-[#f44336] rounded hover:bg-[rgba(244,67,54,0.25)] transition flex items-center gap-1"
                            >
                              <i className="fas fa-trash"></i> Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center gap-2 py-4 border-t border-[rgba(255,255,255,0.07)]">
                    <button
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                    >
                      Previous
                    </button>
                    {[...Array(totalPages)].map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setCurrentPage(i + 1)}
                        className={`px-3 py-1 text-sm rounded transition ${
                          currentPage === i + 1
                            ? "bg-[#f5c77a] text-[#0F0A0A]"
                            : "bg-[#231D1D] text-[#B3B3B3] hover:bg-[rgba(245,199,122,0.1)]"
                        }`}
                      >
                        {i + 1}
                      </button>
                    ))}
                    <button
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                    >
                      Next
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-12 text-[#B3B3B3]">
                <i className="fas fa-language text-3xl mb-2 block"></i>
                <p>No languages found</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* View Modal */}
      {isViewModalOpen && selectedLanguage && (
        <>
          <div className="fixed inset-0 bg-black/30  z-[9999]" onClick={closeModals} />
          <div className="fixed top-24 left-1/2 -translate-x-1/2 z-[9999] w-full max-w-lg px-4">
            <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.3)] shadow-2xl">
              <div className="flex justify-between items-center p-5 border-b border-[rgba(255,255,255,0.07)]">
                <h3 className="text-xl font-semibold text-[#f5c77a] flex items-center gap-2">
                  <i className="fas fa-language"></i>
                  Language Details
                </h3>
                <button onClick={closeModals} className="text-[#B3B3B3] hover:text-white text-xl">
                  <i className="fas fa-times"></i>
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div className="flex justify-center">
                  <div className="w-32 h-32 rounded-lg overflow-hidden border-2 border-[#f5c77a]">
                    <img src={selectedLanguage.image} alt={selectedLanguage.name} className="w-full h-full object-cover" />
                  </div>
                </div>

                <div className="bg-[#231D1D] rounded-lg p-3">
                  <p className="text-xs text-[#B3B3B3] mb-1">Language Name</p>
                  <p className="text-white font-medium">{selectedLanguage.name}</p>
                </div>

                <div className="bg-[#231D1D] rounded-lg p-3">
                  <p className="text-xs text-[#B3B3B3] mb-1">Status</p>
                  <p className="text-white">
                    {selectedLanguage.isActive ? (
                      <span className="text-[#4caf7d]"><i className="fas fa-check-circle mr-1"></i> Active</span>
                    ) : (
                      <span className="text-[#ff9800]"><i className="fas fa-clock mr-1"></i> Inactive</span>
                    )}
                  </p>
                </div>

                <div className="bg-[#231D1D] rounded-lg p-3">
                  <p className="text-xs text-[#B3B3B3] mb-1">Created At</p>
                  <p className="text-white text-sm">{new Date(selectedLanguage.createdAt).toLocaleString()}</p>
                </div>

                <div className="bg-[#231D1D] rounded-lg p-3">
                  <p className="text-xs text-[#B3B3B3] mb-1">Language ID</p>
                  <p className="text-white text-xs font-mono break-all">{selectedLanguage.id}</p>
                </div>
              </div>

              <div className="flex justify-end gap-3 p-5 border-t border-[rgba(255,255,255,0.07)]">
                <button onClick={closeModals} className="px-5 py-2 bg-[#231D1D] text-white rounded">
                  Close
                </button>
                <button
                  onClick={() => {
                    closeModals();
                    handleEdit(selectedLanguage);
                  }}
                  className="px-5 py-2 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded"
                >
                  Edit Language
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Edit Modal */}
      {isEditModalOpen && selectedLanguage && (
        <>
          <div className="fixed inset-0 bg-black/30 z-[9999]" onClick={closeModals} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[9999] w-full max-w-md mx-4">
            <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.3)] shadow-2xl">
              <div className="flex justify-between items-center p-5 border-b border-[rgba(255,255,255,0.07)]">
                <h3 className="text-xl font-semibold text-[#f5c77a]">
                  <i className="fas fa-edit mr-2"></i>
                  Edit Language
                </h3>
                <button onClick={closeModals} className="text-[#B3B3B3] hover:text-white text-xl">
                  <i className="fas fa-times"></i>
                </button>
              </div>
              
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm text-[#B3B3B3] mb-2">Language Name</label>
                  <input
                    type="text"
                    value={editFormData.name}
                    onChange={(e) => setEditFormData({ ...editFormData, name: e.target.value })}
                    className="w-full h-11 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] text-white"
                  />
                </div>
                
                <div>
                  <label className="block text-sm text-[#B3B3B3] mb-2">Language Image</label>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleEditImageChange}
                    className="w-full h-11 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] text-white file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-[#f5c77a] file:text-[#0F0A0A]"
                  />
                </div>
                
                {editImagePreview && (
                  <div>
                    <p className="text-sm text-[#B3B3B3] mb-2">Image Preview:</p>
                    <div className="w-32 h-32 rounded-lg overflow-hidden border border-[rgba(245,199,122,0.3)]">
                      <img src={editImagePreview} alt="Preview" className="w-full h-full object-cover" />
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex justify-end gap-3 p-5 border-t border-[rgba(255,255,255,0.07)]">
                <button onClick={closeModals} className="px-5 py-2 bg-[#231D1D] text-white rounded">
                  Cancel
                </button>
                <button
                  onClick={handleUpdate}
                  disabled={updateLanguageMutation.isPending}
                  className="px-5 py-2 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded disabled:opacity-50"
                >
                  {updateLanguageMutation.isPending ? "Updating..." : "Update"}
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Delete Modal */}
      {isDeleteModalOpen && deleteTarget && (
        <>
          <div className="fixed inset-0 bg-black/40 z-[9999]" onClick={() => setIsDeleteModalOpen(false)} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[9999] w-full max-w-md px-4">
            <div className="bg-[#1C1616] rounded-lg border border-red-400/30 shadow-2xl">
              <div className="flex justify-between items-center p-5 border-b border-[rgba(255,255,255,0.07)]">
                <h3 className="text-lg font-semibold text-red-400 flex items-center gap-2">
                  <i className="fas fa-exclamation-triangle"></i>
                  Confirm Delete
                </h3>
                <button onClick={() => setIsDeleteModalOpen(false)} className="text-[#B3B3B3] hover:text-white">
                  <i className="fas fa-times"></i>
                </button>
              </div>

              <div className="p-6 text-center">
                <p className="text-[#B3B3B3]">Are you sure you want to delete</p>
                <p className="text-white font-semibold mt-2">{deleteTarget.name} ?</p>
              </div>

              <div className="flex justify-end gap-3 p-5 border-t border-[rgba(255,255,255,0.07)]">
                <button onClick={() => setIsDeleteModalOpen(false)} className="px-5 py-2 bg-[#231D1D] text-white rounded">
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  disabled={deleteLanguageMutation.isPending}
                  className="px-5 py-2 bg-red-500 text-white rounded hover:bg-red-600 disabled:opacity-50"
                >
                  {deleteLanguageMutation.isPending ? "Deleting..." : "Delete"}
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default CreateLanguage;