import {
  Card, CardContent, Box, Typography, Table, TableBody,
  TableCell, TableContainer, TableHead, TableRow, Chip,
  IconButton, LinearProgress, Avatar
} from "@mui/material";
import MoreVertRoundedIcon from "@mui/icons-material/MoreVertRounded";
import PlayArrowRoundedIcon from "@mui/icons-material/PlayArrowRounded";
import { COLORS } from "../../theme/theme";

const CONTENT = [
  { title: "Cinematic Travel Vlog - Bali 2024", category: "Travel", views: "284K", watchTime: "92%", status: "Approved", thumbnail: "🏝" },
  { title: "Complete React + TypeScript Course", category: "Tech", views: "156K", watchTime: "78%", status: "Approved", thumbnail: "💻" },
  { title: "Street Food Tour - Mumbai Night Life", category: "Food", views: "98K", watchTime: "85%", status: "Pending", thumbnail: "🍜" },
  { title: "Productivity System for Creators 2024", category: "Lifestyle", views: "62K", watchTime: "71%", status: "Approved", thumbnail: "📋" },
  { title: "Behind the Camera - My Setup Tour", category: "Tech", views: "41K", watchTime: "64%", status: "Rejected", thumbnail: "📷" },
];

const STATUS_COLORS = {
  Approved: { bg: "rgba(76,175,125,0.12)", border: "rgba(76,175,125,0.3)", color: COLORS.success },
  Pending: { bg: "rgba(245,199,122,0.12)", border: "rgba(245,199,122,0.3)", color: COLORS.accent },
  Rejected: { bg: "rgba(244,67,54,0.12)", border: "rgba(244,67,54,0.3)", color: COLORS.error },
};

export default function RecentContent() {
  return (
    <Card>
      <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", mb: 2.5 }}>
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 700, fontSize: "1rem" }}>
              Recent Uploads
            </Typography>
            <Typography sx={{ fontSize: "0.75rem", color: COLORS.textSecondary }}>
              Your latest content performance
            </Typography>
          </Box>
          <Typography sx={{ fontSize: "0.75rem", color: COLORS.accent, cursor: "pointer", fontWeight: 600 }}>
            View all →
          </Typography>
        </Box>

        <TableContainer>
          <Table size="small">
            <TableHead>
              <TableRow>
                <TableCell>Content</TableCell>
                <TableCell>Category</TableCell>
                <TableCell>Views</TableCell>
                <TableCell>Completion</TableCell>
                <TableCell>Status</TableCell>
                <TableCell align="right"></TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {CONTENT.map((item, idx) => (
                <TableRow
                  key={idx}
                  sx={{
                    "&:hover": { bgcolor: "rgba(255,255,255,0.02)" },
                    cursor: "pointer",
                    transition: "background 0.15s",
                  }}
                >
                  <TableCell>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
                      <Box
                        sx={{
                          width: 44, height: 32, borderRadius: "5px",
                          bgcolor: COLORS.surfaceElevated,
                          border: `1px solid ${COLORS.border}`,
                          display: "flex", alignItems: "center", justifyContent: "center",
                          fontSize: 16, flexShrink: 0,
                        }}
                      >
                        {item.thumbnail}
                      </Box>
                      <Typography sx={{ fontSize: "0.82rem", fontWeight: 500, color: COLORS.text }}>
                        {item.title.length > 32 ? item.title.slice(0, 32) + "…" : item.title}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Typography sx={{ fontSize: "0.78rem", color: COLORS.textSecondary }}>
                      {item.category}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography sx={{ fontSize: "0.82rem", fontWeight: 600, color: COLORS.text }}>
                      {item.views}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ minWidth: 100 }}>
                    <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                      <LinearProgress
                        variant="determinate"
                        value={parseInt(item.watchTime)}
                        sx={{
                          flex: 1, height: 5,
                          "& .MuiLinearProgress-bar": {
                            background: `linear-gradient(90deg, ${COLORS.accentDark}, ${COLORS.accent})`,
                          },
                        }}
                      />
                      <Typography sx={{ fontSize: "0.7rem", color: COLORS.textSecondary, minWidth: 30 }}>
                        {item.watchTime}
                      </Typography>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <Chip
                      label={item.status}
                      size="small"
                      sx={{
                        bgcolor: STATUS_COLORS[item.status].bg,
                        border: `1px solid ${STATUS_COLORS[item.status].border}`,
                        color: STATUS_COLORS[item.status].color,
                        fontWeight: 600,
                        fontSize: "0.7rem",
                      }}
                    />
                  </TableCell>
                  <TableCell align="right">
                    <IconButton size="small" sx={{ color: COLORS.textMuted, "&:hover": { color: COLORS.text } }}>
                      <MoreVertRoundedIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </CardContent>
    </Card>
  );
}
