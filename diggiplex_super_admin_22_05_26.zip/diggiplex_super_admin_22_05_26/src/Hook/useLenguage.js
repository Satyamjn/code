//src/Hook/useLenguage.js
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  addLanguageApi,
  getAllLanguagesApi,
  updateLanguageApi,
  deleteLanguageApi,
} from "../Api/api";
import { toast } from "react-toastify";

// GET
export const useGetAllLanguages = (page, limit) => {
  return useQuery({
    queryKey: ["language", page],
    queryFn: () => getAllLanguagesApi({ page, limit }),
  });
};

// CREATE
export const useAddLanguage = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: addLanguageApi,
    onSuccess: () => {
      toast.success("Language created successfully!");
      queryClient.invalidateQueries(["language"]);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to create language");
    },
  });
};

// UPDATE
export const useUpdateLanguage = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: updateLanguageApi,
    onSuccess: () => {
      toast.success("Language updated successfully!");
      queryClient.invalidateQueries(["language"]);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to update language");
    },
  });
};

// DELETE
export const useDeleteLanguage = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteLanguageApi,
    onSuccess: () => {
      toast.success("Language deleted successfully!");
      queryClient.invalidateQueries(["language"]);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to delete language");
    },
  });
};