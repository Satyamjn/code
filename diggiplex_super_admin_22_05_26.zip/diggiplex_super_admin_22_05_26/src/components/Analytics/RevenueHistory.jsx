import React, { useState, useEffect } from "react";
import { Paper, Typography, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Box, Chip } from "@mui/material";
import { TrendingUp, TrendingDown } from "@mui/icons-material";
import { COLORS } from "../../theme/theme";

const RevenueHistory = () => {
  const [revenueData, setRevenueData] = useState([
    { month: "January", revenue: 2450, growth: 12 },
    { month: "February", revenue: 2890, growth: 18 },
    { month: "March", revenue: 3240, growth: 12 },
    { month: "April", revenue: 3680, growth: 14 },
    { month: "May", revenue: 4120, growth: 12 },
    { month: "June", revenue: 4560, growth: 11 },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setRevenueData(prev => prev.map(item => ({
        ...item,
        revenue: item.revenue + Math.floor(Math.random() * 100) - 30,
        growth: Math.max(5, Math.min(25, item.growth + Math.floor(Math.random() * 4) - 2)),
      })));
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Paper sx={{ background: COLORS.background, p: 2 }}>
      <Typography variant="h6" sx={{ color: COLORS.primary, mb: 2 }}>Revenue History - Real-time</Typography>
      <TableContainer>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell sx={{ color: COLORS.textMuted }}>Month</TableCell>
              <TableCell sx={{ color: COLORS.textMuted }}>Revenue</TableCell>
              <TableCell sx={{ color: COLORS.textMuted }}>Growth</TableCell>
              <TableCell sx={{ color: COLORS.textMuted }}>Trend</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {revenueData.map((item, index) => (
              <TableRow key={index}>
                <TableCell sx={{ color: COLORS.primary }}>{item.month}</TableCell>
                <TableCell sx={{ color: COLORS.primary }}>${item.revenue.toLocaleString()}</TableCell>
                <TableCell sx={{ color: item.growth > 0 ? COLORS.success : COLORS.error }}>{item.growth}%</TableCell>
                <TableCell>
                  {item.growth > 0 ? <TrendingUp sx={{ color: COLORS.success }} /> : <TrendingDown sx={{ color: COLORS.error }} />}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
};

export default RevenueHistory;