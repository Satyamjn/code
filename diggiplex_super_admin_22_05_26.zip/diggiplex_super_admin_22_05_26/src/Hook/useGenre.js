import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  addGenreApi,
  updateGenreApi,
  deleteGenreApi,
  getAllGenreApi
} from "../Api/api";
import { toast } from "react-toastify";

// GET
export const useGetAllGenre = (page, limit) => {
  return useQuery({
    queryKey: ["genre", page],
    queryFn: () => getAllGenreApi({ page, limit }),
  });
};

// CREATE
export const useAddGenre = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: addGenreApi,
    onSuccess: () => {
      toast.success("Genre created successfully!");
      queryClient.invalidateQueries(["genre"]);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to create genre");
    },
  });
};

// UPDATE
export const useUpdateGenre = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }) => updateGenreApi({ id, data }), //  params id
    onSuccess: () => {
      toast.success("Genre updated successfully!");
      queryClient.invalidateQueries(["genre"]);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to update genre");
    },
  });
};

// DELETE
export const useDeleteGenre = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id) => deleteGenreApi(id), //  params id
    onSuccess: () => {
      toast.success("Genre deleted successfully!");
      queryClient.invalidateQueries(["genre"]);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to delete genre");
    },
  });
};