// src/pages/UserDetail.jsx
import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import {
  useGetUserDetails,
  useBanUser,
  useUnbanUser,
  useForceLogoutUser,
} from "../Hook/useUser";

import {
  Alert,
  Avatar,
  Box,
  Button,
  Chip,
  CircularProgress,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Grid,
  IconButton,
  Paper,
  Snackbar,
  Stack,
  Tab,
  Tabs,
  Tooltip,
  Typography,
  TextField
} from "@mui/material";

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import BlockIcon from "@mui/icons-material/Block";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import PhonelinkEraseIcon from "@mui/icons-material/PhonelinkErase";
import RefreshIcon from "@mui/icons-material/Refresh";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";

/* ─── Helpers ─── */
const fmtDate = (d) =>
  d
    ? new Date(d).toLocaleString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "N/A";

const fmtDOB = (d) =>
  d
    ? new Date(d).toLocaleDateString("en-IN", {
        day: "numeric",
        month: "long",
        year: "numeric",
      })
    : "N/A";

const getAuthLabel = (p) =>
  ({ PHONE: "Phone", EMAIL: "Email", GOOGLE: "Google" })[p?.toUpperCase()] ||
  p ||
  "Unknown";

const getAuthIcon = (p) =>
  ({ PHONE: "📱", EMAIL: "✉️", GOOGLE: "🔵" })[p?.toUpperCase()] || "🔐";

/* ─── InfoField ─── */
const InfoField = ({ label, value, mono = false, onCopy }) => (
  <Paper variant="outlined" sx={{ p: 1.5, borderRadius: 2, height: "100%" }}>
    <Typography variant="caption" color="text.secondary" display="block" gutterBottom>
      {label}
    </Typography>
    <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1}>
      <Typography
        variant="body2"
        sx={mono ? { fontFamily: "monospace", wordBreak: "break-all", fontSize: 12 } : {}}
      >
        {value || "N/A"}
      </Typography>
      {onCopy && value && (
        <Tooltip title="Copy">
          <IconButton size="small" onClick={() => onCopy(value)}>
            <ContentCopyIcon sx={{ fontSize: 14 }} />
          </IconButton>
        </Tooltip>
      )}
    </Stack>
  </Paper>
);

/* ─── Main ─── */
const UserDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState(0);
  const [confirm, setConfirm] = useState(null);
  const [toast, setToast] = useState(null); // { msg, severity }
const [reason, setReason] = useState("")
  /* ── Hooks ── */
  const {
    data: userDetailsData,
    isLoading,
    isError,
    error: fetchError,
    refetch: fetchUser,
  } = useGetUserDetails(id);

  const { mutate: banUser, isPending: isBanning } = useBanUser(id);
  const { mutate: unbanUser, isPending: isUnbanning } = useUnbanUser(id);
  const { mutate: forceLogout, isPending: isLoggingOut } = useForceLogoutUser(id);

  const actionLoading = isBanning || isUnbanning || isLoggingOut;

  const user = userDetailsData?.data?.user || null;
  const profiles = userDetailsData?.data?.profiles || [];

  /* ── Utilities ── */
  const showToast = (msg, severity = "success") => setToast({ msg, severity });

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text).catch(() => {});
    showToast("Copied to clipboard", "info");
  };

  /* ── Ban / Unban ── */
  const handleBanToggle = () => {
    const isBanned = !user.isActive;
    setConfirm({
      type: "ban",
      title: isBanned ? "Unban User" : "Ban User",
      message: isBanned
        ? "Are you sure you want to unban this user? They will regain access to the platform."
        : "Are you sure you want to ban this user? They will lose access immediately.",
      confirmLabel: isBanned ? "Yes, Unban" : "Yes, Ban",
      confirmColor: isBanned ? "success" : "error",
    });
  };

const executeBan = () => {
  if (user.isActive) {
    banUser(reason, { onSettled: () => { setConfirm(null); setReason(""); } });
  } else {
    unbanUser(reason, { onSettled: () => { setConfirm(null); setReason(""); } });
  }
}; 

  /* ── Force Logout ── */
  const handleDeviceLogout = () => {
    setConfirm({
      type: "logout",
      title: "Force Device Logout",
      message:
        "This will invalidate all active sessions for this user across all devices. They will be logged out immediately.",
      confirmLabel: "Force Logout",
      confirmColor: "warning",
    });
  };

const executeDeviceLogout = () => {
  forceLogout(
    { reason },
    {
      onSettled: () => {
        setConfirm(null);
        setReason("");
      },
    }
  );
}; 
  const onConfirmAction = () => {
    if (confirm?.type === "ban") executeBan();
    if (confirm?.type === "logout") executeDeviceLogout();
  };


  // Reusable Info Card Component

const InfoCard = ({ label, value }) => {
  return (
    <Box
      sx={{
        p: 2.2,
        borderRadius: "18px",
        background: "rgba(255,255,255,0.03)",
        border: "1px solid rgba(255,255,255,0.06)",
        transition: "0.3s",
        height: "100%",
        "&:hover": {
          transform: "translateY(-3px)",
          borderColor: "rgba(255,180,90,0.25)",
          background: "rgba(255,255,255,0.05)",
        },
      }}
    >
      <Typography
        sx={{
          color: "rgba(255,255,255,0.45)",
          fontSize: "0.72rem",
          fontWeight: 700,
          letterSpacing: 1,
          mb: 1,
        }}
      >
        {label}
      </Typography>

      <Typography
        sx={{
          color: "#fff",
          fontSize: "1rem",
          fontWeight: 600,
          wordBreak: "break-word",
        }}
      >
        {value}
      </Typography>
    </Box>
  );
};
  /* ── Loading ── */
  if (isLoading) {
    return (
      <Box
        minHeight="100vh"
        display="flex"
        alignItems="center"
        justifyContent="center"
        flexDirection="column"
        gap={2}
      >
        <CircularProgress />
        <Typography variant="body2" color="text.secondary">
          Loading user details…
        </Typography>
      </Box>
    );
  }

  /* ── Error ── */
  if (isError) {
    const errMsg =
      fetchError?.response?.data?.message ||
      fetchError?.message ||
      "Something went wrong";
    return (
      <Box
        minHeight="100vh"
        display="flex"
        alignItems="center"
        justifyContent="center"
        flexDirection="column"
        gap={2}
      >
        <WarningAmberIcon color="error" sx={{ fontSize: 48 }} />
        <Typography color="error">{errMsg}</Typography>
        <Button variant="contained" onClick={fetchUser}>
          Try Again
        </Button>
        <Button startIcon={<ArrowBackIcon />} onClick={() => navigate(-1)}>
          Go Back
        </Button>
      </Box>
    );
  }

  if (!user) return null;

  return (
    <Box sx={{ minHeight: "100vh", bgcolor: "background.default", pb: 6 }}>

      {/* ── Header ── */}
      <Paper
        elevation={0}
        square
        sx={{ px: 3, pt: 3, pb: 2, borderBottom: 1, borderColor: "divider" }}
      >
        <Button
          startIcon={<ArrowBackIcon />}
          size="small"
          onClick={() => navigate(-1)}
          sx={{ mb: 2 }}
        >
          Back to Users
        </Button>

        <Stack
          direction="row"
          alignItems="flex-start"
          spacing={2}
          flexWrap="wrap"
          gap={1}
        >
          <Avatar sx={{ width: 64, height: 64, fontSize: 28, bgcolor: "action.selected" }}>
            {getAuthIcon(user.auth_provider)}
          </Avatar>

          <Box flex={1} minWidth={0}>
            <Stack
              direction="row"
              alignItems="center"
              spacing={1}
              flexWrap="wrap"
              mb={0.5}
            >
              <Typography variant="h5" fontWeight={700}>
                {user.email || user.phone || "Unknown User"}
              </Typography>
              <Chip
                label={user.role || "USER"}
                size="small"
                color="primary"
                variant="outlined"
              />
            </Stack>

            <Stack direction="row" spacing={1} flexWrap="wrap">
              <Chip
                size="small"
                label={user.isActive ? "Active" : "Banned"}
                color={user.isActive ? "success" : "error"}
                icon={user.isActive ? <CheckCircleIcon /> : <BlockIcon />}
              />
              <Chip
                size="small"
                label={user.isVerified ? "Verified" : "Unverified"}
                color={user.isVerified ? "success" : "warning"}
                variant="outlined"
              />
              {user.isDeleted && (
                <Chip size="small" label="Deleted" color="error" />
              )}
              <Chip
                size="small"
                label={`${getAuthLabel(user.auth_provider)} Auth`}
                variant="outlined"
              />
            </Stack>
          </Box>

          <Stack direction="row" spacing={1} flexWrap="wrap">
            <Button
              size="small"
              variant="outlined"
              startIcon={<RefreshIcon />}
              onClick={fetchUser}
            >
              Refresh
            </Button>
            <Button
              size="small"
              variant="outlined"
              color={user.isActive ? "error" : "success"}
              startIcon={user.isActive ? <BlockIcon /> : <CheckCircleIcon />}
              onClick={handleBanToggle}
              disabled={actionLoading}
            >
              {user.isActive ? "Ban User" : "Unban User"}
            </Button>
            {/* <Button
              size="small"
              variant="outlined"
              color="warning"
              startIcon={<PhonelinkEraseIcon />}
              onClick={handleDeviceLogout}
              disabled={actionLoading}
            >
              Force Logout
            </Button> */}
          </Stack>
        </Stack>
      </Paper>

      {/* ── Tabs ── */}
      <Box sx={{ borderBottom: 1, borderColor: "divider", px: 3 }}>
        <Tabs value={activeTab} onChange={(_, v) => setActiveTab(v)}>
          <Tab label="Overview" />
          <Tab label={`Profiles (${profiles.length})`} />
          <Tab label="Actions" />
        </Tabs>
      </Box>

      <Box sx={{ maxWidth: 1200, mx: "auto", px: 3, pt: 3 }}>

        {/* ── Overview Tab ── */}
    {activeTab === 0 && (
  <Stack spacing={3}>
    {/* Combined Account Card */}
    <Paper
      elevation={0}
      sx={{
        p: 3,
        borderRadius: "24px",
        background:
          "linear-gradient(145deg, #1a120d 0%, #241811 50%, #120d09 100%)",
        border: "1px solid rgba(255,255,255,0.06)",
        boxShadow: "0 10px 30px rgba(0,0,0,0.35)",
        overflow: "hidden",
        position: "relative",
      }}
    >
      {/* Glow Effect */}
      <Box
        sx={{
          position: "absolute",
          top: -80,
          right: -80,
          width: 220,
          height: 220,
          borderRadius: "50%",
          background: "rgba(255,140,0,0.08)",
          filter: "blur(60px)",
        }}
      />

      {/* Header */}
      <Box mb={3}>
        <Typography
          sx={{
            color: "#fff",
            fontWeight: 700,
            fontSize: "1.2rem",
            mb: 0.5,
          }}
        >
          Account Overview
        </Typography>

        <Typography
          sx={{
            color: "rgba(255,255,255,0.55)",
            fontSize: "0.9rem",
          }}
        >
          User account details and status information
        </Typography>
      </Box>

      {/* Account Information */}
      <Box mb={4}>
        <Typography
          sx={{
            color: "#c9a46b",
            fontSize: "0.78rem",
            fontWeight: 700,
            letterSpacing: 1,
            mb: 2,
          }}
        >
          ACCOUNT INFORMATION
        </Typography>

        <Grid container spacing={2}>
          {user.email && (
            <Grid item xs={12} sm={6} md={4}>
              <InfoCard
                label="EMAIL ADDRESS"
                value={user.email}
              />
            </Grid>
          )}

          {user.phone && (
            <Grid item xs={12} sm={6} md={4}>
              <InfoCard
                label="PHONE NUMBER"
                value={user.phone}
              />
            </Grid>
          )}

          <Grid item xs={12} sm={6} md={4}>
            <InfoCard
              label="AUTH PROVIDER"
              value={`${getAuthIcon(
                user.auth_provider
              )} ${getAuthLabel(user.auth_provider)}`}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <InfoCard
              label="ROLE"
              value={user.role || "USER"}
            />
          </Grid>

          {user.dob && (
            <Grid item xs={12} sm={6} md={4}>
              <InfoCard
                label="DATE OF BIRTH"
                value={fmtDOB(user.dob)}
              />
            </Grid>
          )}

          <Grid item xs={12} sm={6} md={4}>
            <InfoCard
              label="MEMBER SINCE"
              value={fmtDate(user.createdAt)}
            />
          </Grid>

          <Grid item xs={12} sm={6} md={4}>
            <InfoCard
              label="LAST UPDATED"
              value={fmtDate(user.updatedAt)}
            />
          </Grid>
        </Grid>
      </Box>

      {/* Account Status */}
      <Box>
        <Typography
          sx={{
            color: "#c9a46b",
            fontSize: "0.78rem",
            fontWeight: 700,
            letterSpacing: 1,
            mb: 2,
          }}
        >
          ACCOUNT STATUS
        </Typography>

        <Grid container spacing={2}>
          {[
            {
              label: "ACTIVE",
              ok: user.isActive,
              desc: user.isActive
                ? "User can access platform"
                : "User is banned",
            },
            {
              label: "VERIFIED",
              ok: user.isVerified,
              desc: user.isVerified
                ? "Identity verified"
                : "Verification pending",
            },
            {
              label: "NOT DELETED",
              ok: !user.isDeleted,
              desc: user.isDeleted
                ? "Account deleted"
                : "Account active",
            },
          ].map((s) => (
            <Grid item xs={12} sm={6} md={4} key={s.label}>
              <Box
                sx={{
                  p: 2.2,
                  borderRadius: "18px",
                  background: "rgba(255,255,255,0.03)",
                  border: "1px solid rgba(255,255,255,0.06)",
                  transition: "0.3s",
                  "&:hover": {
                    transform: "translateY(-3px)",
                    borderColor: s.ok
                      ? "rgba(76,175,80,0.4)"
                      : "rgba(244,67,54,0.4)",
                  },
                }}
              >
                <Typography
                  sx={{
                    color: "rgba(255,255,255,0.5)",
                    fontSize: "0.72rem",
                    mb: 1,
                    fontWeight: 700,
                    letterSpacing: 1,
                  }}
                >
                  {s.label}
                </Typography>

                <Chip
                  size="small"
                  label={s.ok ? "YES" : "NO"}
                  sx={{
                    mb: 1,
                    fontWeight: 700,
                    background: s.ok
                      ? "rgba(76,175,80,0.15)"
                      : "rgba(244,67,54,0.15)",
                    color: s.ok ? "#4caf50" : "#f44336",
                    border: `1px solid ${
                      s.ok
                        ? "rgba(76,175,80,0.3)"
                        : "rgba(244,67,54,0.3)"
                    }`,
                  }}
                />

                <Typography
                  sx={{
                    color: "rgba(255,255,255,0.55)",
                    fontSize: "0.8rem",
                  }}
                >
                  {s.desc}
                </Typography>
              </Box>
            </Grid>
          ))}
        </Grid>
      </Box>
    </Paper>
  </Stack>
)}

        {/* ── Profiles Tab ── */}

{activeTab === 1 && (
  <>
    {profiles.length === 0 ? (
      <Box textAlign="center" py={8}>
        <Typography fontSize={48}>👤</Typography>
        <Typography variant="body1" color="text.secondary" mt={1}>
          No profiles created yet
        </Typography>
        <Typography variant="body2" color="text.secondary">
          User hasn't set up any profile
        </Typography>
      </Box>
    ) : (
      <Grid container spacing={2}>
        {profiles.map((profile, i) => (
          <Grid item xs={12} sm={6} md={4} key={profile.id || i}>
            <Paper variant="outlined" sx={{ p: 2, borderRadius: 2 }}>
              <Stack direction="row" spacing={1.5} alignItems="center" mb={1}>
                <Avatar
                  src={profile.profileImg || undefined}        // ✅ was profile.avatar
                  sx={{ width: 40, height: 40 }}
                >
                  {profile.profileName?.[0]?.toUpperCase() || "?"}  {/* ✅ was profile.name */}
                </Avatar>
                <Box>
                  <Typography variant="body2" fontWeight={500}>
                    {profile.profileName || "Unnamed Profile"}   {/* ✅ was profile.name */}
                  </Typography>
                  {profile.profile_role && (                      // ✅ was profile.type
                    <Typography
                      variant="caption"
                      color="text.secondary"
                      textTransform="uppercase"
                    >
                      {profile.profile_role} · {profile.device_type}  {/* ✅ added device_type */}
                    </Typography>
                  )}
                </Box>
              </Stack>
              <Divider sx={{ mb: 1 }} />
           
              {profile.createdAt && (
                <Typography
                  variant="caption"
                  color="text.secondary"
                  display="block"
                  mt={0.5}
                >
                  Created {fmtDate(profile.createdAt)}
                </Typography>
              )}
            </Paper>
          </Grid>
        ))}
      </Grid>
    )}
  </>
)}

        {/* ── Actions Tab ── */}
        {activeTab === 2 && (
          <Stack spacing={2}>

            {/* Ban / Unban */}
            <Paper
              variant="outlined"
              sx={{
                p: 2.5,
                borderRadius: 2,
                borderColor: user.isActive ? "error.main" : "success.main",
              }}
            >
              <Stack
                direction="row"
                alignItems="flex-start"
                justifyContent="space-between"
                flexWrap="wrap"
                gap={2}
              >
                <Box>
                  <Stack direction="row" alignItems="center" spacing={1} mb={1}>
                    {user.isActive ? (
                      <BlockIcon color="error" />
                    ) : (
                      <CheckCircleIcon color="success" />
                    )}
                    <Typography variant="h6" fontWeight={600}>
                      {user.isActive ? "Ban User" : "Unban User"}
                    </Typography>
                  </Stack>
                  <Typography variant="body2" color="text.secondary" maxWidth={500}>
                    {user.isActive
                      ? "Banning this user will immediately revoke their access. They won't be able to log in until unbanned."
                      : "Unbanning this user will restore their access to the platform."}
                  </Typography>
                  <Box mt={1}>
                    <Chip
                      size="small"
                      label={user.isActive ? "Active" : "Banned"}
                      color={user.isActive ? "success" : "error"}
                    />
                  </Box>
                </Box>
                <Button
                  variant="outlined"
                  color={user.isActive ? "error" : "success"}
                  startIcon={user.isActive ? <BlockIcon /> : <CheckCircleIcon />}
                  onClick={handleBanToggle}
                  disabled={actionLoading}
                >
                  {user.isActive ? "Ban This User" : "Unban This User"}
                </Button>
              </Stack>
            </Paper>

            {/* Force Logout */}
            <Paper
              variant="outlined"
              sx={{ p: 2.5, borderRadius: 2, borderColor: "warning.main" }}
            >
              <Stack
                direction="row"
                alignItems="flex-start"
                justifyContent="space-between"
                flexWrap="wrap"
                gap={2}
              >
                <Box>
                  <Stack direction="row" alignItems="center" spacing={1} mb={1}>
                    <PhonelinkEraseIcon color="warning" />
                    <Typography variant="h6" fontWeight={600}>
                      Force Device Logout
                    </Typography>
                  </Stack>
                  <Typography variant="body2" color="text.secondary" maxWidth={500}>
                    Terminates all active sessions for this user across every device.
                    JWT tokens will be invalidated immediately.
                  </Typography>
                  <Stack direction="row" spacing={1} mt={1} flexWrap="wrap">
                    {["Mobile", "Web", "TV", "Tablet"].map((d) => (
                      <Chip
                        key={d}
                        size="small"
                        label={d}
                        color="warning"
                        variant="outlined"
                      />
                    ))}
                  </Stack>
                </Box>
                <Button
                  variant="outlined"
                  color="warning"
                  startIcon={<PhonelinkEraseIcon />}
                  onClick={handleDeviceLogout}
                  disabled={actionLoading}
                >
                  Logout All Devices
                </Button>
              </Stack>
            </Paper>

            {/* Danger note */}
            <Alert severity="warning" icon={<WarningAmberIcon />}>
              These actions are logged and visible to all admins. Use with caution.
            </Alert>
          </Stack>
        )}
      </Box>

      {/* ── Confirm Dialog ── */}
  <Dialog
  open={!!confirm}
  onClose={() => !actionLoading && setConfirm(null)}
  maxWidth="xs"
  fullWidth
>
  <DialogTitle>{confirm?.title}</DialogTitle>
  <DialogContent>
    <Typography variant="body2" color="text.secondary" mb={2}>
      {confirm?.message}
    </Typography>

    {/* ✅ Sirf ban/unban ke liye reason field */}
    {confirm?.type === "ban" && (
      <TextField
        fullWidth
        size="small"
        label="Reason (optional)"
        placeholder={
          user?.isActive
            ? "e.g. Policy violation, Spam..."
            : "e.g. Appeal approved..."
        }
        value={reason}
        onChange={(e) => setReason(e.target.value)}
        disabled={actionLoading}
        multiline
        rows={2}
        sx={{ mt: 1 }}
      />
    )}
  </DialogContent>
  <DialogActions>
    <Button
      onClick={() => { setConfirm(null); setReason(""); }}
      disabled={actionLoading}
    >
      Cancel
    </Button>
    <Button
      variant="contained"
      color={confirm?.confirmColor || "primary"}
      onClick={onConfirmAction}
      disabled={actionLoading}
    >
      {actionLoading ? "Processing…" : confirm?.confirmLabel}
    </Button>
  </DialogActions>
</Dialog> 

      {/* ── Snackbar Toast ── */}
      <Snackbar
        open={!!toast}
        autoHideDuration={3000}
        onClose={() => setToast(null)}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert
          severity={toast?.severity || "success"}
          onClose={() => setToast(null)}
          variant="filled"
        >
          {toast?.msg}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default UserDetail;