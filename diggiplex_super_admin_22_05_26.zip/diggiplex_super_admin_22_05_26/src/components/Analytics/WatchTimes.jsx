import React, { useState, useEffect } from "react";
import { Box, Typography, Paper } from "@mui/material";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from "recharts";
import { COLORS } from "../../theme/theme";

const WatchTimes = () => {
  const [data, setData] = useState([
    { name: "Mon", hours: 240 },
    { name: "Tue", hours: 280 },
    { name: "Wed", hours: 320 },
    { name: "Thu", hours: 290 },
    { name: "Fri", hours: 350 },
    { name: "Sat", hours: 420 },
    { name: "Sun", hours: 380 },
  ]);

  // Real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setData(prev => prev.map(item => ({
        ...item,
        hours: item.hours + Math.floor(Math.random() * 30) - 10,
      })));
    }, 8000);
    return () => clearInterval(interval);
  }, []);

  return (
    <Paper sx={{ background: COLORS.background, p: 2 }}>
      <Typography variant="h6" sx={{ color: COLORS.primary, mb: 2 }}>Watch Time (Hours) - Real-time</Typography>
      <ResponsiveContainer width="100%" height={400}>
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorHours" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={COLORS.primary} stopOpacity={0.8}/>
              <stop offset="95%" stopColor={COLORS.primary} stopOpacity={0}/>
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="#333" />
          <XAxis dataKey="name" stroke={COLORS.textMuted} />
          <YAxis stroke={COLORS.textMuted} />
          <Tooltip contentStyle={{ backgroundColor: COLORS.background, borderColor: COLORS.primary, color: COLORS.primary }} />
          <Area type="monotone" dataKey="hours" stroke={COLORS.primary} fillOpacity={1} fill="url(#colorHours)" />
        </AreaChart>
      </ResponsiveContainer>
    </Paper>
  );
};

export default WatchTimes;