import { Box, Typography, Grid, Card, CardContent, Button, Stack, Chip } from "@mui/material";
import AddCircleOutlineRoundedIcon from "@mui/icons-material/AddCircleOutlineRounded";
import ListAltRoundedIcon from "@mui/icons-material/ListAltRounded";
import { useNavigate } from "react-router-dom";
import { COLORS } from "../theme/theme";

export const CONTENT_TYPES = [
  { id: "movies", label: "Movies", accept: "MP4, MOV, MKV up to 20GB", duration: "90-180 min" },
  { id: "webseries", label: "Web Series", accept: "MP4, MOV, MKV up to 15GB", duration: "20-60 min" },
  { id: "music", label: "Music", accept: "MP3, WAV, FLAC up to 500MB", duration: "2-8 min" },
  { id: "shortfilm", label: "Short Film", accept: "MP4, MOV, MKV up to 8GB", duration: "5-40 min" },
  { id: "podcast", label: "Podcast", accept: "MP3, WAV, AAC up to 2GB", duration: "10-120 min" },
  { id: "standup-comedy", label: "Standup Comedy", accept: "MP4, MOV, MKV up to 10GB", duration: "15-90 min" },
];
export default function ContentType() {
  const navigate = useNavigate();

  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h5" sx={{ fontWeight: 700, mb: 0.5 }}>
          Creator Studio
        </Typography>
        <Typography sx={{ color: COLORS.textSecondary, fontSize: "0.88rem" }}>
          Select a content type and go to upload or list view.
        </Typography>
      </Box>

      <Grid container spacing={2.2}>
        {CONTENT_TYPES.map((type) => (
          <Grid item xs={12} md={6} lg={4} key={type.id}>
            <Card>
              <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
                <Typography sx={{ fontWeight: 700, fontSize: "1rem", mb: 1 }}>
                  {type.label}
                </Typography>
                <Stack direction="row" spacing={1} sx={{ mb: 2 }}>
                  <Chip
                    label={type.duration}
                    size="small"
                    sx={{
                      bgcolor: COLORS.surfaceElevated,
                      border: `1px solid ${COLORS.border}`,
                      color: COLORS.textSecondary,
                    }}
                  />
                </Stack>

                <Box sx={{ display: "flex", gap: 1.2 }}>
                  <Button
                    variant="contained"
                    size="small"
                    fullWidth
                    startIcon={<AddCircleOutlineRoundedIcon />}
                    onClick={() => navigate(`/studio/${type.id}/upload`)}
                  >
                    Upload
                  </Button>
                  <Button
                    variant="outlined"
                    size="small"
                    fullWidth
                    startIcon={<ListAltRoundedIcon />}
                    onClick={() => navigate(`/library`)}
                    sx={{
                      borderColor: COLORS.border,
                      color: COLORS.textSecondary,
                      "&:hover": { borderColor: COLORS.accent, color: COLORS.accent },
                    }}
                  >
                    View List
                  </Button>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
}
