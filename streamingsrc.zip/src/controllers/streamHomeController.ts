import { and, desc, eq, sql, inArray, count, gt } from "drizzle-orm";
import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler.js";
import { HTTP_STATUS } from "../constants/constant.js";
import ApiResponse from "../utils/ApiResponse.js";
import ApiError from "../utils/ApiError.js";
import {
  db,
  uploads,
  videos,
  uploadAssets,
  videoAssets,
  watchHistory,
  profiles,
  genres,
} from "@digiiplex6112/db";

const ACTIVE_STATUSES = ["PUBLISHED"] as const;

interface ContentItem {
  id: string;
  videoId: string | null;
  title: string;
  description: string | null;
  type: string | null;
  contentKind: string | null;
  genreId: string | null;
  languageId: string | null;
  createdAt: Date | null;
  thumbnail: string | null;
  trailer: string | null;
}

interface GenreSection {
  genreId: string;
  genreName: string;
  totalCount: number;
  items: ContentItem[];
}

// ── OPTIMIZED: assets + videos PARALLEL fetch ──
const attachAssets = async (uploadRows: any[]): Promise<ContentItem[]> => {
  if (!uploadRows.length) return [];

  const uploadIds = uploadRows.map((row) => row.id);

  const [assets, videosData] = await Promise.all([
    db
      .select()
      .from(uploadAssets)
      .where(
        and(
          inArray(uploadAssets.uploadId, uploadIds),
          eq(uploadAssets.isLatest, true),
          eq(uploadAssets.deletedFlg, false)
        )
      ),
    db.select().from(videos).where(inArray(videos.uploadId, uploadIds)),
  ]);

  const videoByUploadId = new Map(videosData.map((v) => [v.uploadId, v]));

  const assetsByUploadId: Record<string, any[]> = assets.reduce(
    (acc: Record<string, any[]>, asset) => {
      if (!acc[asset.uploadId]) acc[asset.uploadId] = [];
      acc[asset.uploadId].push(asset);
      return acc;
    },
    {}
  );

  return uploadRows.map((upload) => ({
    id: upload.id,
    videoId: videoByUploadId.get(upload.id)?.id ?? null,
    title: upload.title ?? "",
    description: upload.description ?? null,
    type: upload.type ?? null,
    contentKind: upload.contentKind ?? null,
    genreId: upload.genreId ?? null,
    languageId: upload.languageId ?? null,
    createdAt: upload.createdAt,
    thumbnail:
      assetsByUploadId[upload.id]?.find((a) => a.assetRole === "THUMBNAIL")
        ?.masterPlaylistUrl ?? null,
    trailer:
      assetsByUploadId[upload.id]?.find((a) => a.assetRole === "TRAILER")
        ?.masterPlaylistUrl ?? null,
  }));
};

const buildUploadFilters = (opts: {
  genreId?: string;
  languageIds?: string[];
  contentKind?: string | null;
}) => {
  const conditions: any[] = [
    inArray(uploads.status, ACTIVE_STATUSES),
    eq(uploads.deletedFlg, false),
  ];

  if (opts.genreId) {
    conditions.push(eq(uploads.genreId, opts.genreId));
  }
  // ✅ languageIds empty ho to filter nahi lagega
  if (opts.languageIds && opts.languageIds.length > 0) {
    conditions.push(inArray(uploads.languageId, opts.languageIds));
  }
  if (opts.contentKind) {
    conditions.push(eq(uploads.contentKind, opts.contentKind as any));
  }

  return and(...conditions);
};



// ══════════════════════════════════════════════════
// getFeaturedContent
// ══════════════════════════════════════════════════
export const getFeaturedContent = asyncHandler(
  async (req: Request, res: Response): Promise<Response> => {
    const profileId = Array.isArray(req.params.profileId)
      ? req.params.profileId[0]
      : req.params.profileId;

    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.max(Number(req.query.limit) || 6, 1);
    const viewAll = req.query.viewAll === "true";
    const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

    // ✅ languageId body se lo
    const bodyLanguageId = req.body.languageId ? String(req.body.languageId) : null;

    const finalLimit = viewAll ? limit : 6;
    const offset = (page - 1) * finalLimit;

    // ✅ Pehle profile fetch karo — languageIds lene ke liye
    const profile = await db.query.profiles.findFirst({
      where: eq(profiles.id, profileId),
    });
    if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

    // ✅ body se languageId aaye to use karo, warna profile ki languagesIds
    const languageIds: string[] = bodyLanguageId
      ? [bodyLanguageId]
      : profile.languagesIds || [];

    const whereClause = buildUploadFilters({ languageIds, contentKind });

    const [recentUploads, [{ total }]] = await Promise.all([
      db
        .select()
        .from(uploads)
        .where(whereClause)
        .orderBy(desc(uploads.createdAt))
        .limit(finalLimit)
        .offset(offset),
      db.select({ total: count() }).from(uploads).where(whereClause),
    ]);

    if (!recentUploads.length) {
      return res.status(200).json(
        new ApiResponse(200, "No featured content found", {
          data: [],
          pagination: {
            currentPage: page,
            totalPages: 0,
            totalItems: 0,
            hasNextPage: false,
            limit: finalLimit,
          },
        })
      );
    }

    const uploadsWithAssets = await attachAssets(recentUploads);
    const totalNum = Number(total || 0);

    return res.status(200).json(
      new ApiResponse(200, "Featured content fetched successfully", {
        data: uploadsWithAssets,
        pagination: {
          currentPage: page,
          totalPages: Math.ceil(totalNum / finalLimit),
          totalItems: totalNum,
          hasNextPage: offset + finalLimit < totalNum,
          limit: finalLimit,
        },
      })
    );
  }
); 
// ══════════════════════════════════════════════════
// getContinueWatching
// ══════════════════════════════════════════════════
export const getContinueWatching = asyncHandler(
  async (req: Request, res: Response) => {
    const userId = req.user.id;

    const { profileId } = req.body;
    if (!profileId) {
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "profileId is required in request body");
    }

    // ✅ Profile verify + languageIds lo
    const profile = await db.query.profiles.findFirst({
      where: and(eq(profiles.id, profileId), eq(profiles.userId, userId)),
    });
    if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.max(Number(req.query.limit) || 6, 1);
    const offset = (page - 1) * limit;
    const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

    // ✅ Profile ki selected languages
    const languageIds: string[] = profile.languagesIds || [];

    const historyWhere = and(
      eq(watchHistory.userId, userId),
      eq(watchHistory.profileId, profileId),
      eq(watchHistory.completed, false),
      gt(watchHistory.position, 0)
    );

    const [historyRows, [{ total }]] = await Promise.all([
      db
        .select({
          id: watchHistory.id,
          position: watchHistory.position,
          duration: watchHistory.duration,
          watchedAt: watchHistory.watchedAt,
          videoId: watchHistory.videoId,
          videoAssetId: watchHistory.videoAssetId,
        })
        .from(watchHistory)
        .where(historyWhere)
        .orderBy(desc(watchHistory.watchedAt))
        .limit(limit)
        .offset(offset),
      db.select({ total: count() }).from(watchHistory).where(historyWhere),
    ]);

    if (!historyRows.length) {
      return res.status(200).json(
        new ApiResponse(200, "No continue watching data", {
          data: [],
          pagination: { currentPage: page, limit, total: 0, hasNextPage: false },
        })
      );
    }

    const videoIds = historyRows.map((h) => h.videoId);

    const [videosData, assetsData] = await Promise.all([
      db.select().from(videos).where(inArray(videos.id, videoIds)),
      db.select().from(videoAssets).where(inArray(videoAssets.videoId, videoIds)),
    ]);

    const uploadIds = videosData.map((v) => v.uploadId).filter(Boolean);

    // ✅ languageIds filter uploads mein bhi lagao
    const uploadConditions: any[] = [
      inArray(uploads.id, uploadIds as string[]),
    ];
    if (contentKind) {
      uploadConditions.push(eq(uploads.contentKind, contentKind as any));
    }
    if (languageIds.length > 0) {
      uploadConditions.push(inArray(uploads.languageId, languageIds));
    }

    const uploadsData = uploadIds.length
      ? await db.select().from(uploads).where(and(...uploadConditions))
      : [];

    const videoMap = new Map(videosData.map((v) => [v.id, v]));
    const uploadMap = new Map(uploadsData.map((u) => [u.id, u]));

    const assetMap = new Map<string, any>();
    for (const a of assetsData) {
      if (!assetMap.has(a.videoId) || a.assetType === "MAIN") {
        assetMap.set(a.videoId, a);
      }
    }

    const result = historyRows
      .map((item) => {
        const video = videoMap.get(item.videoId);
        const upload = video ? uploadMap.get(video.uploadId) : undefined;

        if (video?.uploadId && !upload) return null;

        const asset = assetMap.get(item.videoId);
        const position = item.position ?? 0;
        const duration = item.duration ?? 0;

        return {
          id: upload?.id ?? null,
          videoId: video?.id ?? null,
          title: video?.title ?? null,
          description: video?.description ?? null,
          type: upload?.type ?? null,
          contentKind: upload?.contentKind ?? null,
          genreId: upload?.genreId ?? null,
          languageId: upload?.languageId ?? null,
          thumbnail: asset?.thumbnailUrl ?? asset?.posterUrl ?? null,
          trailer: asset?.masterPlaylistUrl ?? null,
          position,
          duration,
          progress: duration ? Math.round((position / duration) * 100) : 0,
          watchedAt: item.watchedAt,
        };
      })
      .filter(Boolean);

    return res.status(200).json(
      new ApiResponse(200, "Continue watching fetched successfully", {
        data: result,
        pagination: {
          currentPage: page,
          limit,
          total: Number(total),
          hasNextPage: offset + limit < Number(total),
        },
      })
    );
  }
);

// ══════════════════════════════════════════════════
// getTop10
// ══════════════════════════════════════════════════
export const getTop10 = asyncHandler(async (req: Request, res: Response) => {
  const profileId = Array.isArray(req.params.profileId)
    ? req.params.profileId[0]
    : req.params.profileId;

  const page = Math.max(Number(req.query.page) || 1, 1);
  const limit = Math.max(Number(req.query.limit) || 10, 1);
  const offset = (page - 1) * limit;
  const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

  // ✅ Profile fetch karo
  const profile = await db.query.profiles.findFirst({
    where: eq(profiles.id, profileId),
  });
  if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

  const userId = profile.userId;

  // ✅ Profile ki selected languages — body se nahi
  const languageIds: string[] = profile.languagesIds || [];

  const [topContent, [{ total }]] = await Promise.all([
    db
      .select({
        videoId: watchHistory.videoId,
        viewCount: count(watchHistory.id).as("viewCount"),
      })
      .from(watchHistory)
      .where(
        and(
          eq(watchHistory.userId, userId),
          eq(watchHistory.profileId, profileId) // ✅ profileId filter
        )
      )
      .groupBy(watchHistory.videoId)
      .orderBy(sql`COUNT(${watchHistory.id}) DESC`)
      .limit(limit)
      .offset(offset),
    db
      .select({ total: count(sql`DISTINCT ${watchHistory.videoId}`) })
      .from(watchHistory)
      .where(
        and(
          eq(watchHistory.userId, userId),
          eq(watchHistory.profileId, profileId) // ✅ profileId filter
        )
      ),
  ]);

  if (!topContent.length) {
    return res.status(200).json(
      new ApiResponse(200, "No top content", {
        data: [],
        pagination: {
          currentPage: page,
          totalPages: 0,
          totalItems: 0,
          hasNextPage: false,
          limit,
        },
      })
    );
  }

  const videoIds = topContent.map((t) => t.videoId);

  const [videosData, assetsData] = await Promise.all([
    db.select().from(videos).where(inArray(videos.id, videoIds)),
    db.select().from(videoAssets).where(inArray(videoAssets.videoId, videoIds)),
  ]);

  const uploadIds = videosData.map((v) => v.uploadId).filter(Boolean);

  let uploadsData: any[] = [];
  if (uploadIds.length) {
    uploadsData = await db
      .select()
      .from(uploads)
      .where(inArray(uploads.id, uploadIds as string[]));
  }

  // ✅ Profile ki languageIds se filter
  const filteredUploadIds = new Set(
    uploadsData
      .filter((u) => {
        if (languageIds.length > 0 && !languageIds.includes(u.languageId)) return false;
        if (contentKind && u.contentKind !== contentKind) return false;
        return true;
      })
      .map((u) => u.id)
  );

  const assetMap = new Map<string, any>();
  for (const a of assetsData) {
    if (!assetMap.has(a.videoId) || a.assetType === "MAIN") {
      assetMap.set(a.videoId, a);
    }
  }

  const videoMap = new Map(videosData.map((v) => [v.id, v]));
  const uploadMap = new Map(uploadsData.map((u) => [u.id, u]));

  const formatted = topContent
    .map((item, index) => {
      const video = videoMap.get(item.videoId);
      if (!video) return null;
      const upload = uploadMap.get(video.uploadId);
      if (upload && !filteredUploadIds.has(upload.id)) return null;
      const asset = assetMap.get(item.videoId);

      return {
        id: upload?.id ?? null,
        videoId: video.id,
        title: video.title,
        description: video.description ?? null,
        type: upload?.type ?? null,
        contentKind: upload?.contentKind ?? null,
        genreId: upload?.genreId ?? null,
        languageId: upload?.languageId ?? null,
        createdAt: video.createdAt,
        thumbnail: asset?.thumbnailUrl ?? asset?.posterUrl ?? null,
        trailer: asset?.masterPlaylistUrl ?? null,
        rank: offset + index + 1,
        views: Number(item.viewCount || 0),
      };
    })
    .filter(Boolean);

  const totalNum = Number(total || 0);

  return res.status(200).json(
    new ApiResponse(200, "Top 10 fetched successfully", {
      data: formatted,
      pagination: {
        currentPage: page,
        totalPages: Math.ceil(totalNum / limit),
        totalItems: totalNum,
        hasNextPage: offset + limit < totalNum,
        limit,
      },
    })
  );
});

// ══════════════════════════════════════════════════
// getNewlyAdded
// ══════════════════════════════════════════════════
export const getNewlyAdded = asyncHandler(
  async (req: Request, res: Response): Promise<Response> => {
    const profileId = Array.isArray(req.params.profileId)
      ? req.params.profileId[0]
      : req.params.profileId;

    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.max(Number(req.query.limit) || 6, 1);
    const viewAll = req.query.viewAll === "true";
    const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

    const finalLimit = viewAll ? limit : 6;
    const offset = (page - 1) * finalLimit;

    // ✅ Pehle profile fetch karo — languageIds lene ke liye
    const profile = await db.query.profiles.findFirst({
      where: eq(profiles.id, profileId),
    });
    if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

    // ✅ Profile ki selected languages — body se nahi
    const languageIds: string[] = profile.languagesIds || [];

    const whereClause = buildUploadFilters({ languageIds, contentKind });

    const [recentUploads, [{ total }]] = await Promise.all([
      db
        .select()
        .from(uploads)
        .where(whereClause)
        .orderBy(desc(uploads.createdAt))
        .limit(finalLimit)
        .offset(offset),
      db.select({ total: count() }).from(uploads).where(whereClause),
    ]);

    if (!recentUploads.length) {
      return res.status(200).json(
        new ApiResponse(200, "No newly added content", {
          data: [],
          pagination: {
            currentPage: page,
            totalPages: 0,
            totalItems: 0,
            hasNextPage: false,
            limit: finalLimit,
          },
        })
      );
    }

    const uploadsWithAssets = await attachAssets(recentUploads);
    const totalNum = Number(total || 0);

    return res.status(200).json(
      new ApiResponse(200, "Newly added fetched successfully", {
        data: uploadsWithAssets,
        pagination: {
          currentPage: page,
          totalPages: Math.ceil(totalNum / finalLimit),
          totalItems: totalNum,
          hasNextPage: offset + finalLimit < totalNum,
          limit: finalLimit,
        },
      })
    );
  }
);

// ══════════════════════════════════════════════════
// getSelectedGenres
// ══════════════════════════════════════════════════
export const getSelectedGenres = asyncHandler(
  async (req: Request, res: Response): Promise<Response> => {
    const profileId = Array.isArray(req.params.profileId)
      ? req.params.profileId[0]
      : req.params.profileId;

    const page = Math.max(Number(req.query.page) || 1, 1);
    const limit = Math.max(Number(req.query.limit) || 6, 1);
    const viewAll = req.query.viewAll === "true";
    const specificGenreId = req.query.genreId ? String(req.query.genreId) : null;
    const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

    const finalLimit = viewAll ? limit : 6;
    const offset = (page - 1) * finalLimit;

    // ✅ Profile fetch karo
    const profile = await db.query.profiles.findFirst({
      where: eq(profiles.id, profileId),
    });
    if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

    // ✅ Dono profile se lo — body se nahi
    const selectedGenreIds: string[] = profile.genresIds || [];
    const languageIds: string[] = profile.languagesIds || [];

    if (!selectedGenreIds.length) {
      return res.status(200).json(
        new ApiResponse(200, "No genres selected for this profile", {
          data: [],
          pagination: { currentPage: page, limit: finalLimit },
        })
      );
    }

    let targetGenreIds = selectedGenreIds;
    if (specificGenreId) {
      targetGenreIds = selectedGenreIds.includes(specificGenreId)
        ? [specificGenreId]
        : [];
    }

    if (!targetGenreIds.length) {
      return res.status(200).json(
        new ApiResponse(200, "No matching genre found", {
          data: [],
          pagination: { currentPage: page, limit: finalLimit },
        })
      );
    }

    const genreList = await db
      .select({ id: genres.id, name: genres.name })
      .from(genres)
      .where(inArray(genres.id, targetGenreIds));

    // ✅ Sab genres ke liye parallel queries
    const result: GenreSection[] = await Promise.all(
      genreList.map(async (genre) => {
        // ✅ languageIds profile se aa rahi hain
        const whereClause = buildUploadFilters({
          genreId: genre.id,
          languageIds,
          contentKind,
        });

        const [[{ total }], content] = await Promise.all([
          db.select({ total: count() }).from(uploads).where(whereClause),
          db
            .select()
            .from(uploads)
            .where(whereClause)
            .orderBy(desc(uploads.createdAt))
            .limit(finalLimit)
            .offset(offset),
        ]);

        const contentWithAssets = await attachAssets(content);

        return {
          genreId: genre.id,
          genreName: genre.name,
          totalCount: Number(total || 0),
          items: contentWithAssets,
        };
      })
    );

    return res.status(200).json(
      new ApiResponse(200, "Selected genres fetched successfully", {
        data: result,
        pagination: {
          currentPage: page,
          limit: finalLimit,
        },
      })
    );
  }
);   



// import { and, desc, eq, sql, inArray, count, gt, asc } from "drizzle-orm";
// import { Request, Response } from "express";
// import { asyncHandler } from "../utils/asyncHandler.js";
// import { HTTP_STATUS } from "../constants/constant.js";
// import ApiResponse from "../utils/ApiResponse.js";
// import ApiError from "../utils/ApiError.js";
// import {
//   db,
//   uploads,
//   videos,
//   uploadAssets,
//   videoAssets,
//   watchHistory,
//   profiles,
//   genres,
// } from "@digiiplex6112/db";


// const ACTIVE_STATUSES = ["PUBLISHED"] as const;

// interface ContentItem {
//   id: string;
//   videoId: string | null;
//   title: string;
//   description: string | null;
//   type: string | null;
//   contentKind: string | null;
//   genreId: string | null;
//   languageId: string | null;
//   createdAt: Date | null;
//   thumbnail: string | null;
//   trailer: string | null;
// }

// interface GenreSection {
//   genreId: string;
//   genreName: string;
//   totalCount: number;
//   items: ContentItem[];
// }

// // ── Helper: languageIds array normalize karo ──
// const parseLanguageIds = (raw: any): string[] => {
//   if (Array.isArray(raw)) return raw;
//   if (raw) return [raw];
//   return [];
// };

// // ── OPTIMIZED: assets + videos PARALLEL fetch ──
// const attachAssets = async (uploadRows: any[]): Promise<ContentItem[]> => {
//   if (!uploadRows.length) return [];

//   const uploadIds = uploadRows.map((row) => row.id);

//   // assets aur videos dono parallel mein fetch karo
//   const [assets, videosData] = await Promise.all([
//     db
//       .select()
//       .from(uploadAssets)
//       .where(
//         and(
//           inArray(uploadAssets.uploadId, uploadIds),
//           eq(uploadAssets.isLatest, true),
//           eq(uploadAssets.deletedFlg, false)
//         )
//       ),
//     db
//       .select()
//       .from(videos)
//       .where(inArray(videos.uploadId, uploadIds)),
//   ]);

//   const videoByUploadId = new Map(videosData.map((v) => [v.uploadId, v]));

//   const assetsByUploadId: Record<string, any[]> = assets.reduce(
//     (acc: Record<string, any[]>, asset) => {
//       if (!acc[asset.uploadId]) acc[asset.uploadId] = [];
//       acc[asset.uploadId].push(asset);
//       return acc;
//     },
//     {}
//   );

//   return uploadRows.map((upload) => ({
//     id: upload.id,
//     videoId: videoByUploadId.get(upload.id)?.id ?? null,
//     title: upload.title ?? "",
//     description: upload.description ?? null,
//     type: upload.type ?? null,
//     contentKind: upload.contentKind ?? null,
//     genreId: upload.genreId ?? null,
//     languageId: upload.languageId ?? null,
//     createdAt: upload.createdAt,
//     thumbnail:
//       assetsByUploadId[upload.id]?.find((a) => a.assetRole === "THUMBNAIL")
//         ?.masterPlaylistUrl ?? null,
//     trailer:
//       assetsByUploadId[upload.id]?.find((a) => a.assetRole === "TRAILER")
//         ?.masterPlaylistUrl ?? null,
//   }));
// };

// const buildUploadFilters = (opts: {
//   genreId?: string;
//   languageIds?: string[];
//   contentKind?: string | null;
// }) => {
//   const conditions: any[] = [
//     inArray(uploads.status, ACTIVE_STATUSES),
//     eq(uploads.deletedFlg, false),
//   ];

//   if (opts.genreId) {
//     conditions.push(eq(uploads.genreId, opts.genreId));
//   }
//   if (opts.languageIds && opts.languageIds.length > 0) {
//     conditions.push(inArray(uploads.languageId, opts.languageIds));
//   }
//   if (opts.contentKind) {
//     conditions.push(eq(uploads.contentKind, opts.contentKind as any));
//   }

//   return and(...conditions);
// };


// // ── OPTIMIZED: getContinueWatching ──
// // Profile verify + count PARALLEL, history fetch ke baad assets PARALLEL
// export const getContinueWatching = asyncHandler(
//   async (req: Request, res: Response) => {
//     const userId = req.user.id;

//     const { profileId } = req.body;
//     if (!profileId) {
//       throw new ApiError(HTTP_STATUS.BAD_REQUEST, "profileId is required in request body");
//     }

//     // Profile verify karo
//     const profile = await db.query.profiles.findFirst({
//       where: and(eq(profiles.id, profileId), eq(profiles.userId, userId)),
//     });
//     if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const offset = (page - 1) * limit;
//     const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

//     const historyWhere = and(
//       eq(watchHistory.userId, userId),
//       eq(watchHistory.profileId, profileId),
//       eq(watchHistory.completed, false),
//       gt(watchHistory.position, 0)
//     );

//     // history rows aur total count PARALLEL
//     const [historyRows, [{ total }]] = await Promise.all([
//       db
//         .select({
//           id: watchHistory.id,
//           position: watchHistory.position,
//           duration: watchHistory.duration,
//           watchedAt: watchHistory.watchedAt,
//           videoId: watchHistory.videoId,
//           videoAssetId: watchHistory.videoAssetId,
//         })
//         .from(watchHistory)
//         .where(historyWhere)
//         .orderBy(desc(watchHistory.watchedAt))
//         .limit(limit)
//         .offset(offset),
//       db
//         .select({ total: count() })
//         .from(watchHistory)
//         .where(historyWhere),
//     ]);

//     if (!historyRows.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No continue watching data", {
//           data: [],
//           pagination: { currentPage: page, limit, total: 0, hasNextPage: false },
//         })
//       );
//     }

//     const videoIds = historyRows.map((h) => h.videoId);

//     // videos aur videoAssets PARALLEL
//     const [videosData, assetsData] = await Promise.all([
//       db.select().from(videos).where(inArray(videos.id, videoIds)),
//       db.select().from(videoAssets).where(inArray(videoAssets.videoId, videoIds)),
//     ]);

//     const uploadIds = videosData.map((v) => v.uploadId).filter(Boolean);

//     const uploadConditions: any[] = [
//       inArray(uploads.id, uploadIds as string[]),
//     ];
//     if (contentKind) {
//       uploadConditions.push(eq(uploads.contentKind, contentKind as any));
//     }

//     const uploadsData = uploadIds.length
//       ? await db.select().from(uploads).where(and(...uploadConditions))
//       : [];

//     const videoMap = new Map(videosData.map((v) => [v.id, v]));
//     const uploadMap = new Map(uploadsData.map((u) => [u.id, u]));

//     const assetMap = new Map<string, any>();
//     for (const a of assetsData) {
//       if (!assetMap.has(a.videoId) || a.assetType === "MAIN") {
//         assetMap.set(a.videoId, a);
//       }
//     }

//     const result = historyRows
//       .map((item) => {
//         const video = videoMap.get(item.videoId);
//         const upload = video ? uploadMap.get(video.uploadId) : undefined;

//         if (video?.uploadId && !upload) return null;

//         const asset = assetMap.get(item.videoId);
//         const position = item.position ?? 0;
//         const duration = item.duration ?? 0;

//         return {
//           id: upload?.id ?? null,
//           videoId: video?.id ?? null,
//           title: video?.title ?? null,
//           description: video?.description ?? null,
//           type: upload?.type ?? null,
//           contentKind: upload?.contentKind ?? null,
//           genreId: upload?.genreId ?? null,
//           languageId: upload?.languageId ?? null,
//           thumbnail: asset?.thumbnailUrl ?? asset?.posterUrl ?? null,
//           trailer: asset?.masterPlaylistUrl ?? null,
//           position,
//           duration,
//           progress: duration ? Math.round((position / duration) * 100) : 0,
//           watchedAt: item.watchedAt,
//         };
//       })
//       .filter(Boolean);

//     return res.status(200).json(
//       new ApiResponse(200, "Continue watching fetched successfully", {
//         data: result,
//         pagination: {
//           currentPage: page,
//           limit,
//           total: Number(total),
//           hasNextPage: offset + limit < Number(total),
//         },
//       })
//     );
//   }
// );


// // ── OPTIMIZED: getTop10 ──
// // videos + assets + count PARALLEL
// export const getTop10 = asyncHandler(async (req: Request, res: Response) => {
//   const profileId = Array.isArray(req.params.profileId)
//     ? req.params.profileId[0]
//     : req.params.profileId;

//   const page = Math.max(Number(req.query.page) || 1, 1);
//   const limit = Math.max(Number(req.query.limit) || 10, 1);
//   const offset = (page - 1) * limit;

//   const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;
//   const languageIds = parseLanguageIds(req.body.languageIds);

//   const profileData = await db
//     .select()
//     .from(profiles)
//     .where(eq(profiles.id, profileId))
//     .limit(1);

//   const profile = profileData[0];
//   if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//   const userId = profile.userId;

//   // topContent aur total count PARALLEL
//   const [topContent, [{ total }]] = await Promise.all([
//     db
//       .select({
//         videoId: watchHistory.videoId,
//         viewCount: count(watchHistory.id).as("viewCount"),
//       })
//       .from(watchHistory)
//       .where(eq(watchHistory.userId, userId))
//       .groupBy(watchHistory.videoId)
//       .orderBy(sql`COUNT(${watchHistory.id}) DESC`)
//       .limit(limit)
//       .offset(offset),
//     db
//       .select({ total: count(sql`DISTINCT ${watchHistory.videoId}`) })
//       .from(watchHistory)
//       .where(eq(watchHistory.userId, userId)),
//   ]);

//   if (!topContent.length) {
//     return res.status(200).json(
//       new ApiResponse(200, "No top content", {
//         data: [],
//         pagination: {
//           currentPage: page,
//           totalPages: 0,
//           totalItems: 0,
//           hasNextPage: false,
//           limit,
//         },
//       })
//     );
//   }

//   const videoIds = topContent.map((t) => t.videoId);

//   // videos aur videoAssets PARALLEL
//   const [videosData, assetsData] = await Promise.all([
//     db.select().from(videos).where(inArray(videos.id, videoIds)),
//     db.select().from(videoAssets).where(inArray(videoAssets.videoId, videoIds)),
//   ]);

//   const uploadIds = videosData.map((v) => v.uploadId).filter(Boolean);

//   let uploadsData: any[] = [];
//   if (uploadIds.length) {
//     uploadsData = await db
//       .select()
//       .from(uploads)
//       .where(inArray(uploads.id, uploadIds as string[]));
//   }

//   const filteredUploadIds = new Set(
//     uploadsData
//       .filter((u) => {
//         if (languageIds.length > 0 && !languageIds.includes(u.languageId)) return false;
//         if (contentKind && u.contentKind !== contentKind) return false;
//         return true;
//       })
//       .map((u) => u.id)
//   );

//   const assetMap = new Map<string, any>();
//   for (const a of assetsData) {
//     if (!assetMap.has(a.videoId) || a.assetType === "MAIN") {
//       assetMap.set(a.videoId, a);
//     }
//   }

//   const videoMap = new Map(videosData.map((v) => [v.id, v]));
//   const uploadMap = new Map(uploadsData.map((u) => [u.id, u]));

//   const formatted = topContent
//     .map((item, index) => {
//       const video = videoMap.get(item.videoId);
//       if (!video) return null;
//       const upload = uploadMap.get(video.uploadId);
//       if (upload && !filteredUploadIds.has(upload.id)) return null;
//       const asset = assetMap.get(item.videoId);

//       return {
//         id: upload?.id ?? null,
//         videoId: video.id,
//         title: video.title,
//         description: video.description ?? null,
//         type: upload?.type ?? null,
//         contentKind: upload?.contentKind ?? null,
//         genreId: upload?.genreId ?? null,
//         languageId: upload?.languageId ?? null,
//         createdAt: video.createdAt,
//         thumbnail: asset?.thumbnailUrl ?? asset?.posterUrl ?? null,
//         trailer: asset?.masterPlaylistUrl ?? null,
//         rank: offset + index + 1,
//         views: Number(item.viewCount || 0),
//       };
//     })
//     .filter(Boolean);

//   const totalNum = Number(total || 0);

//   return res.status(200).json(
//     new ApiResponse(200, "Top 10 fetched successfully", {
//       data: formatted,
//       pagination: {
//         currentPage: page,
//         totalPages: Math.ceil(totalNum / limit),
//         totalItems: totalNum,
//         hasNextPage: offset + limit < totalNum,
//         limit,
//       },
//     })
//   );
// });


// // ── OPTIMIZED: getNewlyAdded ──
// // Profile verify + count PARALLEL with uploads fetch
// export const getNewlyAdded = asyncHandler(
//   async (req: Request, res: Response): Promise<Response> => {
//     const profileId = Array.isArray(req.params.profileId)
//       ? req.params.profileId[0]
//       : req.params.profileId;

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const viewAll = req.query.viewAll === "true";
//     const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;
//     const languageIds = parseLanguageIds(req.body.languageIds);

//     const finalLimit = viewAll ? limit : 6;
//     const offset = (page - 1) * finalLimit;

//     // profile verify + uploads + count — tino PARALLEL
//     const whereClause = buildUploadFilters({ languageIds, contentKind });

//     const [profile, recentUploads, [{ total }]] = await Promise.all([
//       db.query.profiles.findFirst({ where: eq(profiles.id, profileId) }),
//       db
//         .select()
//         .from(uploads)
//         .where(whereClause)
//         .orderBy(desc(uploads.createdAt))
//         .limit(finalLimit)
//         .offset(offset),
//       db.select({ total: count() }).from(uploads).where(whereClause),
//     ]);

//     if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//     if (!recentUploads.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No newly added content", {
//           data: [],
//           pagination: {
//             currentPage: page,
//             totalPages: 0,
//             totalItems: 0,
//             hasNextPage: false,
//             limit: finalLimit,
//           },
//         })
//       );
//     }

//     const uploadsWithAssets = await attachAssets(recentUploads);

//     const totalNum = Number(total || 0);

//     return res.status(200).json(
//       new ApiResponse(200, "Newly added fetched successfully", {
//         data: uploadsWithAssets,
//         pagination: {
//           currentPage: page,
//           totalPages: Math.ceil(totalNum / finalLimit),
//           totalItems: totalNum,
//           hasNextPage: offset + finalLimit < totalNum,
//           limit: finalLimit,
//         },
//       })
//     );
//   }
// );


// // ── OPTIMIZED: getSelectedGenres ──
// // Profile + genreList PARALLEL, phir sab genres ke liye Promise.all (N+1 → parallel batch)
// export const getSelectedGenres = asyncHandler(
//   async (req: Request, res: Response): Promise<Response> => {
//     const profileId = Array.isArray(req.params.profileId)
//       ? req.params.profileId[0]
//       : req.params.profileId;

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const viewAll = req.query.viewAll === "true";
//     const specificGenreId = req.query.genreId ? String(req.query.genreId) : null;
//     const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;
//     const languageIds = parseLanguageIds(req.body.languageIds);

//     const finalLimit = viewAll ? limit : 6;
//     const offset = (page - 1) * finalLimit;

//     const profile = await db.query.profiles.findFirst({
//       where: eq(profiles.id, profileId),
//     });
//     if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//     const selectedGenreIds: string[] = profile.genresIds || [];

//     if (!selectedGenreIds.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No genres selected for this profile", {
//           data: [],
//           pagination: { currentPage: page, limit: finalLimit },
//         })
//       );
//     }

//     let targetGenreIds = selectedGenreIds;
//     if (specificGenreId) {
//       targetGenreIds = selectedGenreIds.includes(specificGenreId)
//         ? [specificGenreId]
//         : [];
//     }

//     if (!targetGenreIds.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No matching genre found", {
//           data: [],
//           pagination: { currentPage: page, limit: finalLimit },
//         })
//       );
//     }

//     const genreList = await db
//       .select({ id: genres.id, name: genres.name })
//       .from(genres)
//       .where(inArray(genres.id, targetGenreIds));

//     // ── N+1 hatao: sab genres ke liye parallel queries ──
//     const result: GenreSection[] = await Promise.all(
//       genreList.map(async (genre) => {
//         const whereClause = buildUploadFilters({
//           genreId: genre.id,
//           languageIds,
//           contentKind,
//         });

//         // count aur content PARALLEL per genre
//         const [[{ total }], content] = await Promise.all([
//           db.select({ total: count() }).from(uploads).where(whereClause),
//           db
//             .select()
//             .from(uploads)
//             .where(whereClause)
//             .orderBy(desc(uploads.createdAt))
//             .limit(finalLimit)
//             .offset(offset),
//         ]);

//         const contentWithAssets = await attachAssets(content);

//         return {
//           genreId: genre.id,
//           genreName: genre.name,
//           totalCount: Number(total || 0),
//           items: contentWithAssets,
//         };
//       })
//     );

//     return res.status(200).json(
//       new ApiResponse(200, "Selected genres fetched successfully", {
//         data: result,
//         pagination: {
//           currentPage: page,
//           limit: finalLimit,
//         },
//       })
//     );
//   }
// );



// import { and, desc, eq, sql, inArray, count, gt, asc } from "drizzle-orm";
// import { Request, Response } from "express";
// import { asyncHandler } from "../utils/asyncHandler.js";
// import { HTTP_STATUS } from "../constants/constant.js";
// import ApiResponse from "../utils/ApiResponse.js";
// import ApiError from "../utils/ApiError.js";
// import {
//   db,
//   uploads,
//   videos,
//   uploadAssets,
//   videoAssets,
//   watchHistory,
//   profiles,
//   genres,
// } from "@digiiplex6112/db";


// const ACTIVE_STATUSES = ["PUBLISHED"] as const;

// interface ContentItem {
//   id: string;
//   videoId: string | null; // ← added
//   title: string;
//   description: string | null;
//   type: string | null;
//   contentKind: string | null;
//   genreId: string | null;
//   languageId: string | null;
//   createdAt: Date | null;
//   thumbnail: string | null;
//   trailer: string | null;
// }

// interface GenreSection {
//   genreId: string;
//   genreName: string;
//   totalCount: number;
//   items: ContentItem[];
// }


// const attachAssets = async (uploadRows: any[]): Promise<ContentItem[]> => {
//   if (!uploadRows.length) return [];

//   const uploadIds = uploadRows.map((row) => row.id);

//   const assets = await db
//     .select()
//     .from(uploadAssets)
//     .where(
//       and(
//         inArray(uploadAssets.uploadId, uploadIds),
//         eq(uploadAssets.isLatest, true),
//         eq(uploadAssets.deletedFlg, false)
//       )
//     );

//   // ── fetch videos linked to these uploads ──
//   const videosData = await db
//     .select()
//     .from(videos)
//     .where(inArray(videos.uploadId, uploadIds));

//   const videoByUploadId = new Map(videosData.map((v) => [v.uploadId, v]));

//   const assetsByUploadId: Record<string, any[]> = assets.reduce(
//     (acc: Record<string, any[]>, asset) => {
//       if (!acc[asset.uploadId]) acc[asset.uploadId] = [];
//       acc[asset.uploadId].push(asset);
//       return acc;
//     },
//     {}
//   );

//   return uploadRows.map((upload) => ({
//     id: upload.id,
//     videoId: videoByUploadId.get(upload.id)?.id ?? null, // ← added
//     title: upload.title ?? "",
//     description: upload.description ?? null,
//     type: upload.type ?? null,
//     contentKind: upload.contentKind ?? null,
//     genreId: upload.genreId ?? null,
//     languageId: upload.languageId ?? null,
//     createdAt: upload.createdAt,
//     thumbnail:
//       assetsByUploadId[upload.id]?.find((a) => a.assetRole === "THUMBNAIL")
//         ?.masterPlaylistUrl ?? null,
//     trailer:
//       assetsByUploadId[upload.id]?.find((a) => a.assetRole === "TRAILER")
//         ?.masterPlaylistUrl ?? null,
//   }));
// };

// const buildUploadFilters = (opts: {
//   genreId?: string;
//   languageIds?: string[];       // ← string[] ab
//   contentKind?: string | null;
// }) => {
//   const conditions: any[] = [
//     inArray(uploads.status, ACTIVE_STATUSES),
//     eq(uploads.deletedFlg, false),
//   ];

//   if (opts.genreId) {
//     conditions.push(eq(uploads.genreId, opts.genreId));
//   }
//   if (opts.languageIds && opts.languageIds.length > 0) {
//     conditions.push(inArray(uploads.languageId, opts.languageIds));  // ← inArray
//   }
//   if (opts.contentKind) {
//     conditions.push(eq(uploads.contentKind, opts.contentKind as any));
//   }

//   return and(...conditions);
// }; 


// export const getContinueWatching = asyncHandler(
//   async (req: Request, res: Response) => {
//     const userId = req.user.id;

//     // ── profileId from body ──
//     const { profileId } = req.body;
//     if (!profileId) {
//       throw new ApiError(HTTP_STATUS.BAD_REQUEST, "profileId is required in request body");
//     }

//     // verify profile belongs to this user
//     const profile = await db.query.profiles.findFirst({
//       where: and(eq(profiles.id, profileId), eq(profiles.userId, userId)),
//     });
//     if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const offset = (page - 1) * limit;
//     const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

//     const historyRows = await db
//       .select({
//         id: watchHistory.id,
//         position: watchHistory.position,
//         duration: watchHistory.duration,
//         watchedAt: watchHistory.watchedAt,
//         videoId: watchHistory.videoId,
//         videoAssetId: watchHistory.videoAssetId,
//       })
//       .from(watchHistory)
//       .where(
//         and(
//           eq(watchHistory.userId, userId),
//           eq(watchHistory.profileId, profileId),   // ← filter by profileId
//           eq(watchHistory.completed, false),
//           gt(watchHistory.position, 0)
//         )
//       )
//       .orderBy(desc(watchHistory.watchedAt))
//       .limit(limit)
//       .offset(offset);

//     if (!historyRows.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No continue watching data", {
//           data: [],
//           pagination: { currentPage: page, limit, total: 0, hasNextPage: false },
//         })
//       );
//     }

//     const videoIds = historyRows.map((h) => h.videoId);

//     const videosData = await db
//       .select()
//       .from(videos)
//       .where(inArray(videos.id, videoIds));

//     const uploadIds = videosData.map((v) => v.uploadId).filter(Boolean);

//     const uploadConditions: any[] = [
//       inArray(uploads.id, uploadIds as string[]),
//     ];
//     if (contentKind) {
//       uploadConditions.push(eq(uploads.contentKind, contentKind as any));
//     }

//     const uploadsData = uploadIds.length
//       ? await db
//           .select()
//           .from(uploads)
//           .where(and(...uploadConditions))
//       : [];

//     const assetsData = await db
//       .select()
//       .from(videoAssets)
//       .where(inArray(videoAssets.videoId, videoIds));

//     const videoMap = new Map(videosData.map((v) => [v.id, v]));
//     const uploadMap = new Map(uploadsData.map((u) => [u.id, u]));

//     const assetMap = new Map<string, any>();
//     for (const a of assetsData) {
//       if (!assetMap.has(a.videoId) || a.assetType === "MAIN") {
//         assetMap.set(a.videoId, a);
//       }
//     }

//     const result = historyRows
//       .map((item) => {
//         const video = videoMap.get(item.videoId);
//         const upload = video ? uploadMap.get(video.uploadId) : undefined;

//         if (video?.uploadId && !upload) return null;

//         const asset = assetMap.get(item.videoId);
//         const position = item.position ?? 0;
//         const duration = item.duration ?? 0;

//         return {
//           id: upload?.id ?? null,
//           videoId: video?.id ?? null,
//           title: video?.title ?? null,
//           description: video?.description ?? null,
//           type: upload?.type ?? null,
//           contentKind: upload?.contentKind ?? null,
//           genreId: upload?.genreId ?? null,
//           languageId: upload?.languageId ?? null,
//           thumbnail: asset?.thumbnailUrl ?? asset?.posterUrl ?? null,
//           trailer: asset?.masterPlaylistUrl ?? null,
//           position,
//           duration,
//           progress: duration ? Math.round((position / duration) * 100) : 0,
//           watchedAt: item.watchedAt,
//         };
//       })
//       .filter(Boolean);

//     // ── total count also scoped to profileId ──
//     const [{ total }] = await db
//       .select({ total: count() })
//       .from(watchHistory)
//       .where(
//         and(
//           eq(watchHistory.userId, userId),
//           eq(watchHistory.profileId, profileId),   // ← same filter
//           eq(watchHistory.completed, false),
//           gt(watchHistory.position, 0)
//         )
//       );

//     return res.status(200).json(
//       new ApiResponse(200, "Continue watching fetched successfully", {
//         data: result,
//         pagination: {
//           currentPage: page,
//           limit,
//           total: Number(total),
//           hasNextPage: offset + limit < Number(total),
//         },
//       })
//     );
//   }
// );   

// export const getTop10 = asyncHandler(async (req: Request, res: Response) => {
//   const profileId = Array.isArray(req.params.profileId)
//     ? req.params.profileId[0]
//     : req.params.profileId;

//   const page = Math.max(Number(req.query.page) || 1, 1);
//   const limit = Math.max(Number(req.query.limit) || 10, 1);
//   const offset = (page - 1) * limit;

//   const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

//   // ← languageIds body se array mein
//   const languageIds: string[] = Array.isArray(req.body.languageIds)
//     ? req.body.languageIds
//     : req.body.languageIds
//     ? [req.body.languageIds]
//     : [];

//   const profileData = await db
//     .select()
//     .from(profiles)
//     .where(eq(profiles.id, profileId))
//     .limit(1);

//   const profile = profileData[0];
//   if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//   const userId = profile.userId;

//   const topContent = await db
//     .select({
//       videoId: watchHistory.videoId,
//       viewCount: count(watchHistory.id).as("viewCount"),
//     })
//     .from(watchHistory)
//     .where(eq(watchHistory.userId, userId))
//     .groupBy(watchHistory.videoId)
//     .orderBy(sql`COUNT(${watchHistory.id}) DESC`)
//     .limit(limit)
//     .offset(offset);

//   if (!topContent.length) {
//     return res.status(200).json(
//       new ApiResponse(200, "No top content", {
//         data: [],
//         pagination: {
//           currentPage: page,
//           totalPages: 0,
//           totalItems: 0,
//           hasNextPage: false,
//           limit,
//         },
//       })
//     );
//   }

//   const videoIds = topContent.map((t) => t.videoId);

//   const videosData = await db
//     .select()
//     .from(videos)
//     .where(inArray(videos.id, videoIds));

//   const uploadIds = videosData.map((v) => v.uploadId).filter(Boolean);

//   let uploadsData: any[] = [];
//   if (uploadIds.length) {
//     uploadsData = await db
//       .select()
//       .from(uploads)
//       .where(inArray(uploads.id, uploadIds as string[]));
//   }

//   // ← languageIds array filter
//   const filteredUploadIds = new Set(
//     uploadsData
//       .filter((u) => {
//         if (languageIds.length > 0 && !languageIds.includes(u.languageId)) return false;
//         if (contentKind && u.contentKind !== contentKind) return false;
//         return true;
//       })
//       .map((u) => u.id)
//   );

//   const assetsData = await db
//     .select()
//     .from(videoAssets)
//     .where(inArray(videoAssets.videoId, videoIds));

//   const assetMap = new Map<string, any>();
//   for (const a of assetsData) {
//     if (!assetMap.has(a.videoId) || a.assetType === "MAIN") {
//       assetMap.set(a.videoId, a);
//     }
//   }

//   const videoMap = new Map(videosData.map((v) => [v.id, v]));
//   const uploadMap = new Map(uploadsData.map((u) => [u.id, u]));

//   const formatted = topContent
//     .map((item, index) => {
//       const video = videoMap.get(item.videoId);
//       if (!video) return null;
//       const upload = uploadMap.get(video.uploadId);
//       if (upload && !filteredUploadIds.has(upload.id)) return null;
//       const asset = assetMap.get(item.videoId);

//       return {
//         id: upload?.id ?? null,
//         videoId: video.id,
//         title: video.title,
//         description: video.description ?? null,
//         type: upload?.type ?? null,
//         contentKind: upload?.contentKind ?? null,
//         genreId: upload?.genreId ?? null,
//         languageId: upload?.languageId ?? null,
//         createdAt: video.createdAt,
//         thumbnail: asset?.thumbnailUrl ?? asset?.posterUrl ?? null,
//         trailer: asset?.masterPlaylistUrl ?? null,
//         rank: offset + index + 1,
//         views: Number(item.viewCount || 0),
//       };
//     })
//     .filter(Boolean);

//   const [{ total }] = await db
//     .select({ total: count(sql`DISTINCT ${watchHistory.videoId}`) })
//     .from(watchHistory)
//     .where(eq(watchHistory.userId, userId));

//   const totalNum = Number(total || 0);

//   return res.status(200).json(
//     new ApiResponse(200, "Top 10 fetched successfully", {
//       data: formatted,
//       pagination: {
//         currentPage: page,
//         totalPages: Math.ceil(totalNum / limit),
//         totalItems: totalNum,
//         hasNextPage: offset + limit < totalNum,
//         limit,
//       },
//     })
//   );
// }); 


// export const getNewlyAdded = asyncHandler(
//   async (req: Request, res: Response): Promise<Response> => {
//     const profileId = Array.isArray(req.params.profileId)
//       ? req.params.profileId[0]
//       : req.params.profileId;

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const viewAll = req.query.viewAll === "true";
//     const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

//     // ← languageIds body se array mein
//     const languageIds: string[] = Array.isArray(req.body.languageIds)
//       ? req.body.languageIds
//       : req.body.languageIds
//       ? [req.body.languageIds]
//       : [];

//     const finalLimit = viewAll ? limit : 6;
//     const offset = (page - 1) * finalLimit;

//     const profile = await db.query.profiles.findFirst({
//       where: eq(profiles.id, profileId),
//     });
//     if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//     const whereClause = buildUploadFilters({ languageIds, contentKind });

//     const recentUploads = await db
//       .select()
//       .from(uploads)
//       .where(whereClause)
//       .orderBy(desc(uploads.createdAt))
//       .limit(finalLimit)
//       .offset(offset);

//     if (!recentUploads.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No newly added content", {
//           data: [],
//           pagination: {
//             currentPage: page,
//             totalPages: 0,
//             totalItems: 0,
//             hasNextPage: false,
//             limit: finalLimit,
//           },
//         })
//       );
//     }

//     const uploadsWithAssets = await attachAssets(recentUploads);

//     const [{ total }] = await db
//       .select({ total: count() })
//       .from(uploads)
//       .where(whereClause);

//     const totalNum = Number(total || 0);

//     return res.status(200).json(
//       new ApiResponse(200, "Newly added fetched successfully", {
//         data: uploadsWithAssets,
//         pagination: {
//           currentPage: page,
//           totalPages: Math.ceil(totalNum / finalLimit),
//           totalItems: totalNum,
//           hasNextPage: offset + finalLimit < totalNum,
//           limit: finalLimit,
//         },
//       })
//     );
//   }
// );


// export const getSelectedGenres = asyncHandler(
//   async (req: Request, res: Response): Promise<Response> => {
//     const profileId = Array.isArray(req.params.profileId)
//       ? req.params.profileId[0]
//       : req.params.profileId;

//     const page = Math.max(Number(req.query.page) || 1, 1);
//     const limit = Math.max(Number(req.query.limit) || 6, 1);
//     const viewAll = req.query.viewAll === "true";
//     const specificGenreId = req.query.genreId ? String(req.query.genreId) : null;
//     const contentKind = req.query.contentKind ? String(req.query.contentKind) : null;

//     // ← languageIds body se array mein
//     const languageIds: string[] = Array.isArray(req.body.languageIds)
//       ? req.body.languageIds
//       : req.body.languageIds
//       ? [req.body.languageIds]
//       : [];

//     const finalLimit = viewAll ? limit : 6;
//     const offset = (page - 1) * finalLimit;

//     const profile = await db.query.profiles.findFirst({
//       where: eq(profiles.id, profileId),
//     });
//     if (!profile) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Profile not found");

//     const selectedGenreIds: string[] = profile.genresIds || [];

//     if (!selectedGenreIds.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No genres selected for this profile", {
//           data: [],
//           pagination: { currentPage: page, limit: finalLimit },
//         })
//       );
//     }

//     let targetGenreIds = selectedGenreIds;
//     if (specificGenreId) {
//       targetGenreIds = selectedGenreIds.includes(specificGenreId)
//         ? [specificGenreId]
//         : [];
//     }

//     if (!targetGenreIds.length) {
//       return res.status(200).json(
//         new ApiResponse(200, "No matching genre found", {
//           data: [],
//           pagination: { currentPage: page, limit: finalLimit },
//         })
//       );
//     }

//     const genreList = await db
//       .select({ id: genres.id, name: genres.name })
//       .from(genres)
//       .where(inArray(genres.id, targetGenreIds));

//     const result: GenreSection[] = [];

//     for (const genre of genreList) {
//       const whereClause = buildUploadFilters({
//         genreId: genre.id,
//         languageIds,   // ← array
//         contentKind,
//       });

//       const [{ total }] = await db
//         .select({ total: count() })
//         .from(uploads)
//         .where(whereClause);

//       const totalCount = Number(total || 0);

//       const content = await db
//         .select()
//         .from(uploads)
//         .where(whereClause)
//         .orderBy(desc(uploads.createdAt))
//         .limit(finalLimit)
//         .offset(offset);

//       const contentWithAssets = await attachAssets(content);

//       result.push({
//         genreId: genre.id,
//         genreName: genre.name,
//         totalCount,
//         items: contentWithAssets,
//       });
//     }

//     return res.status(200).json(
//       new ApiResponse(200, "Selected genres fetched successfully", {
//         data: result,
//         pagination: {
//           currentPage: page,
//           limit: finalLimit,
//         },
//       })
//     );
//   }
// );  

