// src/components/CreatorStudio/UploadPage.jsx
import React, { useState, useRef } from 'react';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';

const UploadPage = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewData, setPreviewData] = useState(null);
  
  // Preview states
  const [videoPreview, setVideoPreview] = useState(null);
  const [thumbnailPreview, setThumbnailPreview] = useState(null);
  
  const videoInputRef = useRef(null);
  const thumbnailInputRef = useRef(null);

  // Form Data State
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    releaseYear: new Date().getFullYear(),
    duration: '',
    language: '',
    genres: [],
    videoFile: null,
    thumbnailFile: null,
    scheduleType: 'immediate',
    scheduledDate: new Date(),
    scheduledTime: new Date(),
    cast: [],
    directors: [],
    producers: [],
    writers: [],
    isFree: true,
    price: '',
    visibility: 'public',
    allowDownloads: false,
    enableComments: true,
    tags: []
  });

  const [tempCast, setTempCast] = useState('');
  const [tempDirector, setTempDirector] = useState('');
  const [tempTag, setTempTag] = useState('');
  const [showGenreDropdown, setShowGenreDropdown] = useState(false);

  const steps = ['Basic Info', 'Media', 'Cast & Crew'];

  const genres = ['Action', 'Comedy', 'Drama', 'Horror', 'Sci-Fi', 'Thriller', 'Romance', 'Documentary', 'Animation', 'Family', 'Crime', 'Mystery', 'Fantasy', 'Musical', 'War', 'Western'];
  const languages = ['English', 'Spanish', 'French', 'German', 'Italian', 'Portuguese', 'Hindi', 'Japanese', 'Korean', 'Chinese', 'Arabic', 'Russian'];

  const handleInputChange = (field) => (event) => {
    setFormData({ ...formData, [field]: event.target.value });
  };

  const handleGenreToggle = (genre) => {
    const currentGenres = [...formData.genres];
    if (currentGenres.includes(genre)) {
      setFormData({ ...formData, genres: currentGenres.filter(g => g !== genre) });
    } else {
      setFormData({ ...formData, genres: [...currentGenres, genre] });
    }
  };

  const handleFileUpload = (type) => (event) => {
    const file = event.target.files[0];
    if (file) {
      setFormData({ ...formData, [type]: file });
      
      if (type === 'videoFile') {
        const url = URL.createObjectURL(file);
        setVideoPreview(url);
      } else if (type === 'thumbnailFile') {
        const url = URL.createObjectURL(file);
        setThumbnailPreview(url);
      }
    }
  };

  const addCastMember = () => {
    if (tempCast.trim()) {
      setFormData({ ...formData, cast: [...formData.cast, tempCast.trim()] });
      setTempCast('');
    }
  };

  const removeCastMember = (index) => {
    const newCast = formData.cast.filter((_, i) => i !== index);
    setFormData({ ...formData, cast: newCast });
  };

  const addDirector = () => {
    if (tempDirector.trim()) {
      setFormData({ ...formData, directors: [...formData.directors, tempDirector.trim()] });
      setTempDirector('');
    }
  };

  const removeDirector = (index) => {
    const newDirectors = formData.directors.filter((_, i) => i !== index);
    setFormData({ ...formData, directors: newDirectors });
  };

  const addTag = () => {
    if (tempTag.trim()) {
      setFormData({ ...formData, tags: [...formData.tags, tempTag.trim()] });
      setTempTag('');
    }
  };

  const removeTag = (index) => {
    const newTags = formData.tags.filter((_, i) => i !== index);
    setFormData({ ...formData, tags: newTags });
  };

  const handlePreview = () => {
    setPreviewData({
      ...formData,
      thumbnailUrl: thumbnailPreview,
      videoUrl: videoPreview
    });
    setPreviewOpen(true);
  };

  const handleSubmit = async () => {
    setUploading(true);
    setUploadProgress(0);
    
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 300);
    
    try {
      await new Promise(resolve => setTimeout(resolve, 3000));
      console.log('Uploading content:', formData);
      
      setSnackbar({
        open: true,
        message: 'Content uploaded successfully!',
        severity: 'success'
      });
      
      setTimeout(() => {
        setActiveStep(0);
        setFormData({
          ...formData,
          videoFile: null,
          thumbnailFile: null,
          title: '',
          description: ''
        });
        setVideoPreview(null);
        setThumbnailPreview(null);
      }, 2000);
      
    } catch (error) {
      setSnackbar({
        open: true,
        message: 'Upload failed. Please try again.',
        severity: 'error'
      });
    } finally {
      clearInterval(interval);
      setUploading(false);
      setUploadProgress(0);
    }
  };

  const PreviewDialog = () => (
    <div className={`fixed inset-0 z-50 flex items-center justify-center ${previewOpen ? 'visible' : 'hidden'}`}>
      <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm" onClick={() => setPreviewOpen(false)}></div>
      <div className="bg-[#1C1616] rounded-xl max-w-2xl w-full mx-4 shadow-[0_8px_32px_rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.07)] z-10 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center p-5 border-b border-[rgba(255,255,255,0.07)] sticky top-0 bg-[#1C1616]">
          <h6 style={{margin:"13px",marginTop:"50px"}} className="text-lg font-semibold text-white">Content Preview</h6>
          <button onClick={() => setPreviewOpen(false)} className="text-gray-400 hover:text-white transition">
            <i className="fas fa-times text-xl"></i>
          </button>
        </div>
        <div className="p-7">
          {previewData && (
            <div className="space-y-4">
              {/* Video Preview */}
              {previewData.videoUrl && (
                <div>
                  <h4 className="text-white font-semibold mb-2 text-sm">Video Preview</h4>
                  <video className="w-full rounded-lg" controls>
                    <source src={previewData.videoUrl} type="video/mp4" />
                  </video>
                </div>
              )}
              
              {/* Thumbnail Preview */}
              {previewData.thumbnailUrl && (
                <div>
                  <h4 className="text-white font-semibold mb-2 text-sm">Thumbnail</h4>
                  <img src={previewData.thumbnailUrl} alt="Thumbnail" className="w-full rounded-lg max-h-48 object-cover" />
                </div>
              )}
              
              {/* Content Details */}
              <div className="bg-[#231D1D] p-4 rounded-lg">
                <h3 className="text-xl font-bold text-white mb-2">{previewData.title || 'Untitled'}</h3>
                <p className="text-[#B3B3B3] text-sm mb-3">{previewData.description || 'No description'}</p>
                {previewData.genres.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {previewData.genres.map(genre => (
                      <span key={genre} className="px-2 py-1 bg-[rgba(245,199,122,0.15)] text-[#f5c77a] rounded text-xs">{genre}</span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
        <div className="flex justify-end gap-3 p-5 border-t border-[rgba(255,255,255,0.07)] sticky bottom-0 bg-[#1C1616]">
          <button onClick={() => setPreviewOpen(false)} className="px-5 py-2 border border-[rgba(255,255,255,0.07)] rounded-lg hover:bg-[rgba(255,255,255,0.05)] text-white transition text-sm h-10">
            Close
          </button>
        </div>
      </div>
    </div>
  );

  const renderBasicInfo = () => (
    <div className="bg-[#1C1616] rounded-lg p-5 shadow-[0_8px_32px_rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.07)]">
      <h6 className="text-lg font-semibold text-white mb-4">Basic Information</h6>
      <div className="space-y-3">
        {/* Title */}
        <div>
          <input
            type="text"
            placeholder="Title"
            value={formData.title}
            onChange={handleInputChange('title')}
            className="w-full h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition"
          />
        </div>
        
        {/* Description */}
        <div>
          <textarea
            placeholder="Description"
            value={formData.description}
            onChange={handleInputChange('description')}
            rows="2"
            className="w-full px-4 py-2 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition resize-none"
          />
        </div>
        
        {/* Row 3 fields */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          <input
            type="number"
            placeholder="Release Year"
            value={formData.releaseYear}
            onChange={handleInputChange('releaseYear')}
            className="w-full h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition"
          />
          <input
            type="text"
            placeholder="Duration (minutes)"
            value={formData.duration}
            onChange={handleInputChange('duration')}
            className="w-full h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition"
          />
          <select
            value={formData.language}
            onChange={handleInputChange('language')}
            className="w-full h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white transition cursor-pointer"
          >
            <option value="" className="bg-[#1C1616]">Language</option>
            {languages.map(lang => (
              <option key={lang} value={lang} className="bg-[#1C1616]">{lang}</option>
            ))}
          </select>
        </div>
        
        {/* Genres */}
        <div>
          <div className="relative">
            <div 
              className="w-full h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg flex items-center justify-between cursor-pointer hover:border-[#f5c77a] transition"
              onClick={() => setShowGenreDropdown(!showGenreDropdown)}
            >
              <span className={formData.genres.length > 0 ? "text-white" : "text-[#6B6B6B]"}>
                {formData.genres.length > 0 ? `${formData.genres.length} genre${formData.genres.length > 1 ? 's' : ''} selected` : "Select Genres"}
              </span>
              <i className={`fas fa-chevron-${showGenreDropdown ? 'up' : 'down'} text-[#B3B3B3] text-xs transition`}></i>
            </div>
            
            {showGenreDropdown && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setShowGenreDropdown(false)}></div>
                <div className="absolute top-full left-0 right-0 mt-2 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg shadow-xl z-20 max-h-64 overflow-y-auto">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-2 p-3">
                    {genres.map((genre) => (
                      <label key={genre} className="flex items-center gap-2 p-2 hover:bg-[rgba(245,199,122,0.1)] rounded-lg cursor-pointer transition">
                        <input
                          type="checkbox"
                          checked={formData.genres.includes(genre)}
                          onChange={() => handleGenreToggle(genre)}
                          className="w-4 h-4 accent-[#f5c77a]"
                        />
                        <span className="text-[#B3B3B3] text-sm">{genre}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </>
            )}
          </div>
          
          {/* Selected Genres Chips */}
          {formData.genres.length > 0 && (
            <div className="flex flex-wrap gap-2 mt-2">
              {formData.genres.map((genre) => (
                <span key={genre} className="px-2 py-1 bg-[rgba(245,199,122,0.15)] border border-[rgba(245,199,122,0.3)] rounded-lg text-xs text-[#f5c77a] flex items-center gap-1">
                  {genre}
                  <button onClick={() => handleGenreToggle(genre)} className="hover:text-white transition">
                    <i className="fas fa-times text-xs"></i>
                  </button>
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );

  const renderMediaFiles = () => (
    <div className="bg-[#1C1616] rounded-lg p-5 shadow-[0_8px_32px_rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.07)]">
      <h6 className="text-lg font-semibold text-white mb-4">Media Files</h6>
      <div className="space-y-3">
        {/* Video Upload */}
        <div 
          onClick={() => videoInputRef.current?.click()}
          className="w-full h-12 border-2 border-dashed border-[rgba(245,199,122,0.3)] rounded-lg flex items-center justify-center gap-2 cursor-pointer hover:border-[#f5c77a] hover:bg-[rgba(245,199,122,0.05)] transition-all bg-[#231D1D] group"
        >
          <input
            ref={videoInputRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={handleFileUpload('videoFile')}
          />
          <i className="fas fa-cloud-upload-alt text-[#f5c77a] group-hover:scale-110 transition"></i>
          <span className="text-sm text-[#B3B3B3]">{formData.videoFile ? formData.videoFile.name : 'Upload Video'}</span>
        </div>
        
        {/* Thumbnail Upload */}
        <div 
          onClick={() => thumbnailInputRef.current?.click()}
          className="w-full h-12 border-2 border-dashed border-[rgba(245,199,122,0.3)] rounded-lg flex items-center justify-center gap-2 cursor-pointer hover:border-[#f5c77a] hover:bg-[rgba(245,199,122,0.05)] transition-all bg-[#231D1D] group"
        >
          <input
            ref={thumbnailInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={handleFileUpload('thumbnailFile')}
          />
          <i className="fas fa-image text-[#f5c77a]"></i>
          <span className="text-sm text-[#B3B3B3]">{formData.thumbnailFile ? 'Thumbnail ✓' : 'Thumbnail'}</span>
        </div>
        
        {/* Preview Button */}
        <button
          onClick={handlePreview}
          className="w-full h-12 border-2 border-[#f5c77a] text-[#f5c77a] rounded-lg hover:bg-[rgba(245,199,122,0.1)] transition-all flex items-center justify-center gap-2 font-semibold"
        >
          <i className="fas fa-eye"></i> Preview
        </button>
        
        {/* Tags */}
        <div>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Tags"
              value={tempTag}
              onChange={(e) => setTempTag(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addTag()}
              className="flex-1 h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition"
            />
            <button 
              onClick={addTag} 
              className="px-4 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded-lg hover:shadow-[0_6px_28px_rgba(245,199,122,0.45)] transition-all h-12 flex items-center gap-1 text-sm"
            >
              <i className="fas fa-plus"></i> Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {formData.tags.map((tag, index) => (
              <span key={index} className="px-2 py-1 bg-[rgba(245,199,122,0.15)] border border-[rgba(245,199,122,0.3)] rounded-lg text-xs text-[#f5c77a] flex items-center gap-1">
                <i className="fas fa-tag text-xs"></i>
                {tag}
                <button onClick={() => removeTag(index)} className="hover:text-white transition">
                  <i className="fas fa-times text-xs"></i>
                </button>
              </span>
            ))}
          </div>
        </div>
      </div>
    </div>
  );

  const renderCastCrew = () => (
    <div className="bg-[#1C1616] rounded-lg p-5 shadow-[0_8px_32px_rgba(0,0,0,0.5)] border border-[rgba(255,255,255,0.07)]">
      <h6 className="text-lg font-semibold text-white mb-4">Cast & Crew</h6>
      <div className="space-y-4">
        {/* Cast */}
        <div>
          <label className="text-[#B3B3B3] text-sm mb-2 block">Cast Members</label>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Enter cast member name"
              value={tempCast}
              onChange={(e) => setTempCast(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addCastMember()}
              className="flex-1 h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition"
            />
            <button 
              onClick={addCastMember} 
              className="px-4 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded-lg hover:shadow-[0_6px_28px_rgba(245,199,122,0.45)] transition-all h-12 flex items-center gap-1 text-sm"
            >
              <i className="fas fa-plus"></i> Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {formData.cast.map((member, index) => (
              <span key={index} className="px-2 py-1 bg-[rgba(245,199,122,0.15)] border border-[rgba(245,199,122,0.3)] rounded-lg text-xs text-[#f5c77a] flex items-center gap-1">
                <i className="fas fa-user"></i>
                {member}
                <button onClick={() => removeCastMember(index)} className="hover:text-white transition">
                  <i className="fas fa-times text-xs"></i>
                </button>
              </span>
            ))}
          </div>
        </div>
        
        {/* Directors */}
        <div>
          <label className="text-[#B3B3B3] text-sm mb-2 block">Directors</label>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Enter director name"
              value={tempDirector}
              onChange={(e) => setTempDirector(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && addDirector()}
              className="flex-1 h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition"
            />
            <button 
              onClick={addDirector} 
              className="px-4 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded-lg hover:shadow-[0_6px_28px_rgba(245,199,122,0.45)] transition-all h-12 flex items-center gap-1 text-sm"
            >
              <i className="fas fa-plus"></i> Add
            </button>
          </div>
          <div className="flex flex-wrap gap-2 mt-2">
            {formData.directors.map((director, index) => (
              <span key={index} className="px-2 py-1 bg-[rgba(245,199,122,0.15)] border border-[rgba(245,199,122,0.3)] rounded-lg text-xs text-[#f5c77a] flex items-center gap-1">
                <i className="fas fa-video"></i>
                {director}
                <button onClick={() => removeDirector(index)} className="hover:text-white transition">
                  <i className="fas fa-times text-xs"></i>
                </button>
              </span>
            ))}
          </div>
        </div>
        
        {/* Producers & Writers */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="text-[#B3B3B3] text-sm mb-2 block">Producers</label>
            <input
              type="text"
              placeholder="Enter producers (comma separated)"
              value={formData.producers.join(', ')}
              onChange={(e) => setFormData({...formData, producers: e.target.value.split(',').map(p => p.trim()).filter(p => p)})}
              className="w-full h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition"
            />
          </div>
          <div>
            <label className="text-[#B3B3B3] text-sm mb-2 block">Writers</label>
            <input
              type="text"
              placeholder="Enter writers (comma separated)"
              value={formData.writers.join(', ')}
              onChange={(e) => setFormData({...formData, writers: e.target.value.split(',').map(w => w.trim()).filter(w => w)})}
              className="w-full h-12 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition"
            />
          </div>
        </div>
      </div>
    </div>
  );

  const renderStepContent = (step) => {
    switch (step) {
      case 0: return renderBasicInfo();
      case 1: return renderMediaFiles();
      case 2: return renderCastCrew();
      default: return null;
    }
  };

  const isStepValid = () => {
    switch (activeStep) {
      case 0: return formData.title.trim() !== '';
      case 1: return formData.videoFile !== null;
      case 2: return true;
      default: return false;
    }
  };

  const handlePublish = () => {
    if (isStepValid()) {
      handleSubmit();
    }
  };

  return (
    <div className="min-h-screen" style={{ background: 'rgba(15, 10, 10, 0.85)' }}>
      <div className="max-w-5xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="mb-6">
          <h1 className="text-2xl font-bold text-white">Upload Content</h1>
          <p className="text-[#B3B3B3] text-sm">Share your masterpiece with the world</p>
        </div>
        
        {/* Stepper */}
        <div className="mb-6">
          <div className="flex justify-between items-center">
            {steps.map((label, index) => (
              <div key={label} className="flex-1 text-center">
                <div className={`flex items-center ${index !== steps.length - 1 ? 'flex-1' : ''}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold transition-all ${
                    index <= activeStep 
                      ? 'bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] shadow-lg' 
                      : 'bg-[#231D1D] text-[#6B6B6B] border border-[rgba(255,255,255,0.07)]'
                  }`}>
                    {index + 1}
                  </div>
                  {index !== steps.length - 1 && (
                    <div className={`flex-1 h-0.5 mx-2 transition-all ${
                      index < activeStep ? 'bg-[#f5c77a]' : 'bg-[rgba(255,255,255,0.07)]'
                    }`}></div>
                  )}
                </div>
                <div className={`text-xs mt-1 hidden md:block ${index <= activeStep ? 'text-[#f5c77a]' : 'text-[#6B6B6B]'}`}>
                  {label}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Progress Bar */}
        {uploading && (
          <div className="mb-4">
            <div className="w-full bg-[#231D1D] rounded-full h-1.5 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] h-1.5 rounded-full transition-all duration-300"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <p className="text-center text-xs text-[#B3B3B3] mt-1">Uploading... {uploadProgress}%</p>
          </div>
        )}
        
        {/* Step Content */}
        <div className="transition-all duration-300">
          {renderStepContent(activeStep)}
        </div>
        
        {/* Navigation Buttons */}
        <div className="flex justify-between mt-5 gap-3">
          <button
            onClick={() => setActiveStep(activeStep - 1)}
            disabled={activeStep === 0 || uploading}
            className="px-5 py-2 border border-[rgba(255,255,255,0.07)] rounded-lg hover:bg-[rgba(255,255,255,0.05)] disabled:opacity-50 disabled:cursor-not-allowed h-10 text-white text-sm transition"
          >
            Back
          </button>
          
          {activeStep === steps.length - 1 ? (
            <button
              onClick={handlePublish}
              disabled={!isStepValid() || uploading}
              className="px-5 py-2 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded-lg hover:shadow-[0_6px_28px_rgba(245,199,122,0.45)] disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 h-10 text-sm transition-all"
            >
              <i className="fas fa-cloud-upload-alt"></i>
              {uploading ? 'Uploading...' : 'Publish'}
            </button>
          ) : (
            <button
              onClick={() => setActiveStep(activeStep + 1)}
              disabled={!isStepValid() || uploading}
              className="px-5 py-2 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded-lg hover:shadow-[0_6px_28px_rgba(245,199,122,0.45)] disabled:opacity-50 disabled:cursor-not-allowed h-10 text-sm transition-all"
            >
              Next
            </button>
          )}
        </div>
        
        {/* Snackbar */}
        {snackbar.open && (
          <div className="fixed bottom-4 left-1/2 transform -translate-x-1/2 z-50 animate-slide-up">
            <div className={`px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 text-sm ${
              snackbar.severity === 'success' 
                ? 'bg-green-600 text-white' 
                : 'bg-red-600 text-white'
            }`}>
              <i className={`fas ${snackbar.severity === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'}`}></i>
              {snackbar.message}
            </div>
          </div>
        )}
        
        <PreviewDialog />
      </div>
      
      <style jsx>{`
        @keyframes slide-up {
          from {
            opacity: 0;
            transform: translateX(-50%) translateY(100%);
          }
          to {
            opacity: 1;
            transform: translateX(-50%) translateY(0);
          }
        }
        .animate-slide-up {
          animation: slide-up 0.3s ease-out;
        }
      `}</style>
    </div>
  );
};

export default UploadPage;


// import { useState } from "react";
// import {
//   Box, Typography, Grid, Card, CardContent, TextField,
//   Select, MenuItem, FormControl, InputLabel, Button,
//   Chip, LinearProgress, Divider
// } from "@mui/material";
// import CloudUploadRoundedIcon from "@mui/icons-material/CloudUploadRounded";
// import AddPhotoAlternateRoundedIcon from "@mui/icons-material/AddPhotoAlternateRounded";
// import PublishRoundedIcon from "@mui/icons-material/PublishRounded";
// import ScheduleRoundedIcon from "@mui/icons-material/ScheduleRounded";
// import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
// import { COLORS } from "../../theme/theme";

// function DropZone({ label, icon, accept, height = 160, onHint }) {
//   const [dragging, setDragging] = useState(false);
//   const [uploaded, setUploaded] = useState(false);

//   return (
//     <Box
//       onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
//       onDragLeave={() => setDragging(false)}
//       onDrop={(e) => { e.preventDefault(); setDragging(false); setUploaded(true); }}
//       onClick={() => setUploaded(!uploaded)}
//       sx={{
//         height,
//         borderRadius: "5px",
//         border: `2px dashed ${dragging ? COLORS.accent : uploaded ? COLORS.success : COLORS.border}`,
//         bgcolor: dragging
//           ? COLORS.accentGlow
//           : uploaded
//           ? "rgba(76,175,125,0.08)"
//           : COLORS.surfaceElevated,
//         display: "flex",
//         flexDirection: "column",
//         alignItems: "center",
//         justifyContent: "center",
//         gap: 1,
//         cursor: "pointer",
//         transition: "all 0.25s ease",
//         position: "relative",
//         overflow: "hidden",
//         "&:hover": {
//           borderColor: uploaded ? COLORS.success : COLORS.accent,
//           bgcolor: uploaded ? "rgba(76,175,125,0.1)" : COLORS.accentGlow,
//         },
//       }}
//     >
//       {uploaded ? (
//         <>
//           <CheckCircleRoundedIcon sx={{ fontSize: 36, color: COLORS.success }} />
//           <Typography sx={{ fontSize: "0.82rem", fontWeight: 600, color: COLORS.success }}>
//             File Ready
//           </Typography>
//           <Typography sx={{ fontSize: "0.7rem", color: COLORS.textMuted }}>
//             Click to change
//           </Typography>
//         </>
//       ) : (
//         <>
//           <Box
//             sx={{
//               width: 52, height: 52, borderRadius: "5px",
//               background: dragging ? `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.accentDark})` : COLORS.surface,
//               border: `1px solid ${dragging ? COLORS.accent : COLORS.border}`,
//               display: "flex", alignItems: "center", justifyContent: "center",
//               transition: "all 0.25s",
//             }}
//           >
//             {icon}
//           </Box>
//           <Typography sx={{ fontSize: "0.88rem", fontWeight: 600, color: dragging ? COLORS.accent : COLORS.text }}>
//             {dragging ? "Drop it here!" : label}
//           </Typography>
//           <Typography sx={{ fontSize: "0.72rem", color: COLORS.textMuted, textAlign: "center", px: 2 }}>
//             {accept}
//           </Typography>
//         </>
//       )}
//     </Box>
//   );
// }

// export default function CreatorStudio() {
//   const [category, setCategory] = useState("");
//   const [uploading, setUploading] = useState(false);
//   const [progress, setProgress] = useState(0);
//   const [published, setPublished] = useState(false);

//   const handlePublish = () => {
//     setUploading(true);
//     setProgress(0);
//     const interval = setInterval(() => {
//       setProgress((p) => {
//         if (p >= 100) {
//           clearInterval(interval);
//           setUploading(false);
//           setPublished(true);
//           return 100;
//         }
//         return p + 5;
//       });
//     }, 120);
//   };

//   return (
//     <Box>
//       <Box sx={{ mb: 3 }}>
//         <Typography variant="h5" sx={{ fontWeight: 700, mb: 0.5 }}>
//           Creator Studio
//         </Typography>
//         <Typography sx={{ color: COLORS.textSecondary, fontSize: "0.88rem" }}>
//           Upload and publish your content to the Digiiplex platform
//         </Typography>
//       </Box>

//       <Grid container spacing={3}>
//         {/* Left column */}
//         <Grid item xs={12} lg={7}>
//           <Card>
//             <CardContent sx={{ p: 3, "&:last-child": { pb: 3 } }}>
//               <Typography variant="h6" sx={{ fontWeight: 700, mb: 2.5, fontSize: "0.95rem", color: COLORS.accent }}>
//                 📹 Upload Video
//               </Typography>

//               <DropZone
//                 label="Drag & Drop your video here"
//                 icon={<CloudUploadRoundedIcon sx={{ fontSize: 26, color: COLORS.textSecondary }} />}
//                 accept="MP4, MOV, AVI, MKV up to 10GB"
//                 height={180}
//               />

//               <Divider sx={{ borderColor: COLORS.border, my: 3 }} />

//               <Typography variant="h6" sx={{ fontWeight: 700, mb: 2, fontSize: "0.95rem", color: COLORS.accent }}>
//                 🖼 Thumbnail
//               </Typography>

//               <DropZone
//                 label="Upload Thumbnail"
//                 icon={<AddPhotoAlternateRoundedIcon sx={{ fontSize: 26, color: COLORS.textSecondary }} />}
//                 accept="JPG, PNG, WebP · 1280×720 recommended"
//                 height={120}
//               />
//             </CardContent>
//           </Card>

//           {/* Upload progress */}
//           {(uploading || published) && (
//             <Card sx={{ mt: 2.5 }}>
//               <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
//                 <Box sx={{ display: "flex", justifyContent: "space-between", mb: 1.5 }}>
//                   <Typography sx={{ fontSize: "0.85rem", fontWeight: 600, color: COLORS.text }}>
//                     {published ? "✅ Published Successfully!" : "⬆️ Uploading..."}
//                   </Typography>
//                   <Typography sx={{ fontSize: "0.82rem", fontWeight: 700, color: COLORS.accent }}>
//                     {progress}%
//                   </Typography>
//                 </Box>
//                 <LinearProgress
//                   variant="determinate"
//                   value={progress}
//                   sx={{
//                     height: 8,
//                     "& .MuiLinearProgress-bar": {
//                       background: published
//                         ? `linear-gradient(90deg, ${COLORS.success}, #3ddc84)`
//                         : `linear-gradient(90deg, ${COLORS.accentDark}, ${COLORS.accent})`,
//                     },
//                   }}
//                 />
//                 {published && (
//                   <Typography sx={{ fontSize: "0.75rem", color: COLORS.success, mt: 1 }}>
//                     Your content is now live on Digiiplex. Share it with your audience!
//                   </Typography>
//                 )}
//               </CardContent>
//             </Card>
//           )}
//         </Grid>

//         {/* Right column */}
//         <Grid item xs={12} lg={5}>
//           <Card>
//             <CardContent sx={{ p: 3, "&:last-child": { pb: 3 } }}>
//               <Typography variant="h6" sx={{ fontWeight: 700, mb: 2.5, fontSize: "0.95rem", color: COLORS.accent }}>
//                 📝 Content Details
//               </Typography>

//               <Box sx={{ display: "flex", flexDirection: "column", gap: 2.5 }}>
//                 <TextField
//                   label="Video Title"
//                   placeholder="Enter an engaging title..."
//                   fullWidth
//                   InputLabelProps={{ sx: { color: COLORS.textSecondary, fontSize: "0.85rem" } }}
//                 />

//                 <TextField
//                   label="Description"
//                   placeholder="Describe your content in detail..."
//                   multiline
//                   rows={4}
//                   fullWidth
//                   InputLabelProps={{ sx: { color: COLORS.textSecondary, fontSize: "0.85rem" } }}
//                 />

//                 <FormControl fullWidth>
//                   <InputLabel sx={{ color: COLORS.textSecondary, fontSize: "0.85rem" }}>Category</InputLabel>
//                   <Select
//                     value={category}
//                     label="Category"
//                     onChange={(e) => setCategory(e.target.value)}
//                     sx={{
//                       bgcolor: COLORS.surfaceElevated,
//                       borderRadius: "5px",
//                       "& .MuiOutlinedInput-notchedOutline": { borderColor: COLORS.border },
//                       "&:hover .MuiOutlinedInput-notchedOutline": { borderColor: "rgba(245,199,122,0.4)" },
//                       "&.Mui-focused .MuiOutlinedInput-notchedOutline": { borderColor: COLORS.accent },
//                     }}
//                   >
//                     {["Travel", "Technology", "Food & Cooking", "Lifestyle", "Education", "Entertainment", "Music", "Sports", "Finance", "Health"].map((cat) => (
//                       <MenuItem key={cat} value={cat}>{cat}</MenuItem>
//                     ))}
//                   </Select>
//                 </FormControl>

//                 {/* Tags */}
//                 <Box>
//                   <Typography sx={{ fontSize: "0.8rem", color: COLORS.textSecondary, mb: 1 }}>Tags</Typography>
//                   <Box sx={{ display: "flex", flexWrap: "wrap", gap: 0.8 }}>
//                     {["#trending", "#creator", "#2024", "#original"].map((tag) => (
//                       <Chip
//                         key={tag}
//                         label={tag}
//                         size="small"
//                         onDelete={() => {}}
//                         sx={{
//                           bgcolor: COLORS.accentGlow,
//                           border: `1px solid rgba(245,199,122,0.25)`,
//                           color: COLORS.accent,
//                           "& .MuiChip-deleteIcon": { color: COLORS.accent, "&:hover": { color: "#fff" } },
//                         }}
//                       />
//                     ))}
//                     <Chip
//                       label="+ Add tag"
//                       size="small"
//                       sx={{
//                         bgcolor: COLORS.surface,
//                         border: `1px dashed ${COLORS.border}`,
//                         color: COLORS.textMuted,
//                         cursor: "pointer",
//                         "&:hover": { borderColor: COLORS.accent, color: COLORS.accent },
//                       }}
//                     />
//                   </Box>
//                 </Box>

//                 <Divider sx={{ borderColor: COLORS.border }} />

//                 {/* Schedule */}
//                 <Box>
//                   <Box sx={{ display: "flex", alignItems: "center", gap: 1, mb: 1.5 }}>
//                     <ScheduleRoundedIcon sx={{ fontSize: 16, color: COLORS.accent }} />
//                     <Typography sx={{ fontSize: "0.85rem", fontWeight: 600, color: COLORS.text }}>
//                       Schedule Release
//                     </Typography>
//                   </Box>
//                   <TextField
//                     type="datetime-local"
//                     fullWidth
//                     defaultValue="2024-12-15T18:00"
//                     InputLabelProps={{ shrink: true }}
//                     sx={{
//                       "& input": { colorScheme: "dark", fontSize: "0.85rem" },
//                     }}
//                   />
//                 </Box>

                

//                 <Button
//                   variant="contained"
//                   fullWidth
//                   startIcon={<PublishRoundedIcon />}
//                   onClick={handlePublish}
//                   disabled={uploading}
//                   sx={{
//                     py: 1.5,
//                     fontSize: "0.92rem",
//                     fontWeight: 700,
//                     mt: 0.5,
//                     background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.accentDark})`,
//                     color: "#0F0A0A",
//                     boxShadow: `0 6px 24px rgba(245,199,122,0.35)`,
//                     "&:hover": {
//                       boxShadow: `0 8px 32px rgba(245,199,122,0.5)`,
//                       transform: "translateY(-1px)",
//                     },
//                     transition: "all 0.2s",
//                     "&.Mui-disabled": { opacity: 0.6 },
//                   }}
//                 >
//                   {uploading ? "Publishing..." : "Publish Content"}
//                 </Button>
//               </Box>
//             </CardContent>
//           </Card>
//         </Grid>
//       </Grid>
//     </Box>
//   );
// }
