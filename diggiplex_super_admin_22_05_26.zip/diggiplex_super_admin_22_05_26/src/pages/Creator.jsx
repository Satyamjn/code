// src/pages/Creator.jsx
import React, { useState } from "react";
import { toast } from "react-toastify";
import {
  useCreateCreator,
  useGetCreators,
  useUpdateCreator,
  useDeleteCreator,
} from "../Hook/useCreator";

const Creator = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: "",
    password: "",
  });
  const [error, setError] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  
  // Modal states
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [selectedCreator, setSelectedCreator] = useState(null);
  const [editFormData, setEditFormData] = useState({
    email: "",
    password: "",
  });
  const [showEditPassword, setShowEditPassword] = useState(false);
  
  // Delete modal
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState(null);
  
  // Copy notification state
  const [copySuccess, setCopySuccess] = useState("");

  // Hooks
  const createMutation = useCreateCreator();
  const updateMutation = useUpdateCreator();
  const deleteMutation = useDeleteCreator();

  const {
    data: creatorsData,
    isLoading,
    isError,
    error: fetchError,
    refetch,
  } = useGetCreators(currentPage, itemsPerPage);

  // Get creators from response
  const creators = creatorsData?.data?.data || creatorsData?.data?.creators || [];
  const pagination = creatorsData?.data?.pagination || { 
    total: 0, 
    page: 1, 
    limit: itemsPerPage, 
    totalPages: 1 
  };
  const totalPages = pagination.totalPages || 1;

  // Handle form input change
  const handleInputChange = (field) => (event) => {
    setFormData({ ...formData, [field]: event.target.value });
    setError("");
  };

  // Handle edit input change
  const handleEditInputChange = (field) => (event) => {
    setEditFormData({ ...editFormData, [field]: event.target.value });
  };

  // Validate form before submission
  const validateForm = () => {
    if (!formData.email.trim()) {
      setError("Email address is required");
      toast.error("Email address is required");
      return false;
    }
    const emailRegex = /^[^\s@]+@([^\s@]+\.)+[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      setError("Please enter a valid email address");
      toast.error("Please enter a valid email address");
      return false;
    }
    if (!formData.password.trim()) {
      setError("Password is required");
      toast.error("Password is required");
      return false;
    }
    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters");
      toast.error("Password must be at least 6 characters");
      return false;
    }
    return true;
  };

  // Create creator
  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }

    createMutation.mutate(formData, {
      onSuccess: () => {
        setFormData({ email: "", password: "" });
        setError("");
        refetch();
      },
    });
  };

  // Open edit modal
  const handleEdit = (creator) => {
    setSelectedCreator(creator);
    setEditFormData({
      email: creator.email,
      password: "",
    });
    setIsEditModalOpen(true);
  };

  // Update creator (email and password both)
  const handleUpdate = () => {
    // Prepare update data - only include fields that have values
    const updateData = {};
    
    if (editFormData.email && editFormData.email.trim()) {
      const emailRegex = /^[^\s@]+@([^\s@]+\.)+[^\s@]+$/;
      if (!emailRegex.test(editFormData.email)) {
        toast.error("Please enter a valid email address");
        return;
      }
      updateData.email = editFormData.email.trim();
    }
    
    if (editFormData.password && editFormData.password.trim()) {
      if (editFormData.password.length < 6) {
        toast.error("Password must be at least 6 characters");
        return;
      }
      updateData.password = editFormData.password;
    }
    
    // Check if anything to update
    if (Object.keys(updateData).length === 0) {
      toast.info("No changes to update");
      setIsEditModalOpen(false);
      return;
    }

    console.log("Updating creator:", { id: selectedCreator.id, data: updateData });

    updateMutation.mutate(
      {
        id: selectedCreator.id,
        data: updateData,
      },
      {
        onSuccess: () => {
          setIsEditModalOpen(false);
          setSelectedCreator(null);
          setEditFormData({ email: "", password: "" });
          refetch();
          // toast.success("Creator updated successfully!");
        },
        onError: (error) => {
          console.error("Update error:", error);
          toast.error(error?.response?.data?.message || "Failed to update creator");
        }
      }
    );
  };

  // Delete creator
  const handleDelete = (id, email) => {
    setDeleteTarget({ id, name: email });
    setIsDeleteModalOpen(true);
  };

  const confirmDelete = () => {
    if (!deleteTarget) return;

    deleteMutation.mutate(deleteTarget.id, {
      onSuccess: () => {
        setIsDeleteModalOpen(false);
        setDeleteTarget(null);
        refetch();
      },
    });
  };

  // Open view modal
  const handleView = (creator) => {
    setSelectedCreator(creator);
    setIsViewModalOpen(true);
  };

  // Close modals
  const closeModals = () => {
    setIsViewModalOpen(false);
    setIsEditModalOpen(false);
    setSelectedCreator(null);
  };

  // Copy to clipboard
  const handleCopy = (text, type, creatorEmail) => {
    navigator.clipboard.writeText(text);
    setCopySuccess(`${creatorEmail}-${type}`);
    setTimeout(() => setCopySuccess(""), 2000);
  };

  // Generate login URL
  const getLoginUrl = () => {
    return `${window.location.origin}/login`;
  };

  return (
    <div className="min-h-screen relative" style={{ background: 'rgba(15, 10, 10, 0.85)' }}>
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-6">
          <h5 className="text-xl font-bold text-[#f5c77a]">Creator Management</h5>
        </div>

        {/* Create Creator Form Card */}
        <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.125)] p-6 mb-8">
          <h6 className="text-md font-semibold text-[#f5c77a] mb-4">Create New Creator</h6>
          <form onSubmit={handleSubmit}>
            {error && (
              <div className="mb-4 p-3 bg-[rgba(244,67,54,0.15)] border border-[rgba(244,67,54,0.3)] rounded-lg text-[#ffaa88] text-sm flex items-start gap-2">
                <i className="fas fa-exclamation-circle mt-0.5"></i>
                <span>{error}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#f5c77a]">
                  <i className="fas fa-envelope"></i>
                </div>
                <input
                  type="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={handleInputChange('email')}
                  disabled={createMutation.isPending}
                  className="w-full h-12 pl-10 pr-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition disabled:opacity-50"
                />
              </div>

              <div className="relative">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 text-[#f5c77a]">
                  <i className="fas fa-lock"></i>
                </div>
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder="Password"
                  value={formData.password}
                  onChange={handleInputChange('password')}
                  disabled={createMutation.isPending}
                  className="w-full h-12 pl-10 pr-12 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] focus:ring-1 focus:ring-[#f5c77a] text-white placeholder:text-[#6B6B6B] transition disabled:opacity-50"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#B3B3B3] hover:text-[#f5c77a] transition"
                >
                  <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="submit"
                disabled={createMutation.isPending}
                className="h-12 px-6 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded-lg hover:shadow-[0_6px_28px_rgba(245,199,122,0.45)] disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 text-sm"
              >
                {createMutation.isPending ? (
                  <>
                    <svg className="animate-spin h-4 w-4 text-[#0F0A0A]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <span>Creating...</span>
                  </>
                ) : (
                  <>
                    <i className="fas fa-user-plus"></i>
                    <span>Create Creator</span>
                  </>
                )}
              </button>
            </div>

            <p className="text-[#6B6B6B] text-xs mt-2">Password must be at least 6 characters</p>
          </form>
        </div>

        {/* Creators List Table */}
        <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.125)] overflow-hidden">
          <div className="p-4 border-b border-[rgba(255,255,255,0.07)]">
            <h6 className="text-lg font-semibold text-[#f5c77a]">Creators List</h6>
            <p className="text-[#B3B3B3] text-sm mt-1">Total Creators: {pagination.total || 0}</p>
          </div>
          
          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="flex justify-center items-center py-12">
                <svg className="animate-spin h-8 w-8 text-[#f5c77a]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              </div>
            ) : isError ? (
              <div className="text-center py-12 text-red-400">
                <i className="fas fa-exclamation-triangle text-3xl mb-2 block"></i>
                <p>{fetchError?.message || "Failed to load creators"}</p>
                <button 
                  onClick={() => refetch()}
                  className="mt-4 px-4 py-2 bg-[#f5c77a] text-[#0F0A0A] rounded text-sm"
                >
                  Try Again
                </button>
              </div>
            ) : creators?.length > 0 ? (
              <>
                <table className="w-full">
                  <thead className="bg-[#231D1D] border-b border-[rgba(255,255,255,0.07)]">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">S.No</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Email</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Role</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Created At</th>
                      <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[rgba(255,255,255,0.07)]">
                    {creators.map((creator, index) => (
                      <tr key={creator.id} className="hover:bg-[rgba(245,199,122,0.05)] transition">
                        <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                          {(currentPage - 1) * itemsPerPage + index + 1}
                        </td>
                        <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">{creator.email}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className="px-2 py-1 text-xs rounded-full bg-[rgba(245,199,122,0.15)] text-[#f5c77a] border border-[rgba(245,199,122,0.3)]">
                            <i className="fas fa-shield-alt mr-1"></i> {creator.role || "CREATOR"}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                          {creator.createdAt ? new Date(creator.createdAt).toLocaleDateString() : "N/A"}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="flex gap-2">
                            <button
                              onClick={() => handleView(creator)}
                              className="px-3 py-1 text-xs bg-[rgba(33,150,243,0.15)] text-[#2196f3] rounded hover:bg-[rgba(33,150,243,0.25)] transition flex items-center gap-1"
                            >
                              <i className="fas fa-eye"></i> View
                            </button>
                            <button
                              onClick={() => handleEdit(creator)}
                              className="px-3 py-1 text-xs bg-[rgba(245,199,122,0.15)] text-[#f5c77a] rounded hover:bg-[rgba(245,199,122,0.25)] transition flex items-center gap-1"
                            >
                              <i className="fas fa-edit"></i> Edit
                            </button>
                            <button
                              onClick={() => handleDelete(creator.id, creator.email)}
                              className="px-3 py-1 text-xs bg-[rgba(244,67,54,0.15)] text-[#f44336] rounded hover:bg-[rgba(244,67,54,0.25)] transition flex items-center gap-1"
                            >
                              <i className="fas fa-trash"></i> Delete
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center gap-2 py-4 border-t border-[rgba(255,255,255,0.07)]">
                    <button
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                    >
                      Previous
                    </button>
                    {[...Array(totalPages)].map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setCurrentPage(i + 1)}
                        className={`px-3 py-1 text-sm rounded transition ${
                          currentPage === i + 1
                            ? "bg-[#f5c77a] text-[#0F0A0A]"
                            : "bg-[#231D1D] text-[#B3B3B3] hover:bg-[rgba(245,199,122,0.1)]"
                        }`}
                      >
                        {i + 1}
                      </button>
                    ))}
                    <button
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                    >
                      Next
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-12 text-[#B3B3B3]">
                <i className="fas fa-users text-3xl mb-2 block"></i>
                <p>No Creators found</p>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* View Modal */}
      {isViewModalOpen && selectedCreator && (
        <>
          <div className="fixed inset-0 bg-black/30 z-40" onClick={closeModals} />
          <div className="fixed top-24 left-1/2 -translate-x-1/2 z-50 w-full max-w-lg px-4">
            <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.3)] shadow-2xl">
              <div className="flex justify-between items-center p-5 border-b border-[rgba(255,255,255,0.07)]">
                <h3 className="text-xl font-semibold text-[#f5c77a] flex items-center gap-2">
                  <i className="fas fa-user-circle"></i>
                  Creator Details
                </h3>
                <button onClick={closeModals} className="text-[#B3B3B3] hover:text-white text-xl">
                  <i className="fas fa-times"></i>
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div className="bg-[#231D1D] rounded-lg p-3">
                  <p className="text-xs text-[#B3B3B3] mb-1">Email Address</p>
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-white break-all flex-1">{selectedCreator.email}</p>
                    <button
                      onClick={() => handleCopy(selectedCreator.email, "email", selectedCreator.email)}
                      className="px-3 py-1 text-xs bg-[rgba(245,199,122,0.15)] text-[#f5c77a] rounded"
                    >
                      {copySuccess === `${selectedCreator.email}-email` ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>

                <div className="bg-[#231D1D] rounded-lg p-3">
                  <p className="text-xs text-[#B3B3B3] mb-1">Role</p>
                  <p className="text-white">
                    <span className="px-2 py-1 text-xs rounded-full bg-[rgba(245,199,122,0.15)] text-[#f5c77a]">
                      {selectedCreator.role || "CREATOR"}
                    </span>
                  </p>
                </div>

                <div className="bg-[#231D1D] rounded-lg p-3">
                  <p className="text-xs text-[#B3B3B3] mb-1">Creator ID</p>
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-white text-xs break-all flex-1">{selectedCreator.id}</p>
                    <button
                      onClick={() => handleCopy(selectedCreator.id, "id", selectedCreator.email)}
                      className="px-3 py-1 text-xs bg-[rgba(245,199,122,0.15)] text-[#f5c77a] rounded"
                    >
                      {copySuccess === `${selectedCreator.email}-id` ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>

                {selectedCreator.createdAt && (
                  <div className="bg-[#231D1D] rounded-lg p-3">
                    <p className="text-xs text-[#B3B3B3] mb-1">Created At</p>
                    <p className="text-white text-sm">
                      {new Date(selectedCreator.createdAt).toLocaleString()}
                    </p>
                  </div>
                )}

                <div className="bg-[#231D1D] rounded-lg p-3">
                  <p className="text-xs text-[#B3B3B3] mb-1">Login URL</p>
                  <div className="flex items-center justify-between gap-2">
                    <p className="text-white text-xs break-all flex-1">{getLoginUrl()}</p>
                    <button
                      onClick={() => handleCopy(getLoginUrl(), "url", selectedCreator.email)}
                      className="px-3 py-1 text-xs bg-[rgba(245,199,122,0.15)] text-[#f5c77a] rounded"
                    >
                      {copySuccess === `${selectedCreator.email}-url` ? "Copied!" : "Copy"}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex justify-end gap-3 p-5 border-t border-[rgba(255,255,255,0.07)]">
                <button onClick={closeModals} className="px-5 py-2 bg-[#231D1D] text-white rounded">
                  Close
                </button>
                <button
                  onClick={() => {
                    closeModals();
                    handleEdit(selectedCreator);
                  }}
                  className="px-5 py-2 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded"
                >
                  Edit Creator
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Edit Modal - Update both Email & Password */}
      {isEditModalOpen && selectedCreator && (
        <>
          <div className="fixed inset-0 bg-black/70 z-40" onClick={() => setIsEditModalOpen(false)} />
          <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md mx-4">
            <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.3)] shadow-2xl">
              <div className="flex justify-between items-center p-5 border-b border-[rgba(255,255,255,0.07)]">
                <h3 className="text-xl font-semibold text-[#f5c77a]">
                  <i className="fas fa-edit mr-2"></i>
                  Edit Creator
                </h3>
                <button onClick={() => setIsEditModalOpen(false)} className="text-[#B3B3B3] hover:text-white text-xl transition">
                  <i className="fas fa-times"></i>
                </button>
              </div>
              
              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm text-[#B3B3B3] mb-2">Email Address</label>
                  <input
                    type="email"
                    value={editFormData.email}
                    onChange={handleEditInputChange('email')}
                    className="w-full h-11 px-4 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] text-white"
                    placeholder="Enter email address (leave empty to keep current)"
                  />
                  <p className="text-xs text-[#6B6B6B] mt-1">Leave empty to keep current email</p>
                </div>

                <div>
                  <label className="block text-sm text-[#B3B3B3] mb-2">New Password</label>
                  <div className="relative">
                    <input
                      type={showEditPassword ? "text" : "password"}
                      value={editFormData.password}
                      onChange={handleEditInputChange('password')}
                      className="w-full h-11 px-4 pr-10 bg-[#231D1D] border border-[rgba(255,255,255,0.07)] rounded-lg focus:outline-none focus:border-[#f5c77a] text-white"
                      placeholder="Enter new password (leave empty to keep current)"
                    />
                    <button
                      type="button"
                      onClick={() => setShowEditPassword(!showEditPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-[#B3B3B3] hover:text-[#f5c77a]"
                    >
                      <i className={`fas ${showEditPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                    </button>
                  </div>
                  <p className="text-xs text-[#6B6B6B] mt-1">Password must be at least 6 characters. Leave empty to keep current password.</p>
                </div>
              </div>
              
              <div className="flex justify-end gap-3 p-5 border-t border-[rgba(255,255,255,0.07)]">
                <button
                  onClick={() => setIsEditModalOpen(false)}
                  className="px-5 py-2 bg-[#231D1D] text-white rounded-lg hover:bg-[rgba(255,255,255,0.1)] transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleUpdate}
                  disabled={updateMutation.isPending}
                  className="px-5 py-2 bg-gradient-to-r from-[#f5c77a] to-[#c49a4e] text-[#0F0A0A] font-semibold rounded-lg hover:shadow-lg disabled:opacity-50 transition flex items-center gap-2"
                >
                  {updateMutation.isPending ? (
                    <>
                      <svg className="animate-spin h-4 w-4" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      <span>Updating...</span>
                    </>
                  ) : (
                    <>
                      <i className="fas fa-save"></i>
                      <span>Update Creator</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </>
      )}

      {/* Delete Modal */}
      {isDeleteModalOpen && deleteTarget && (
        <>
          <div className="fixed inset-0 bg-black/40 z-40" onClick={() => setIsDeleteModalOpen(false)} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-50 w-full max-w-md px-4">
            <div className="bg-[#1C1616] rounded-lg border border-red-400/30 shadow-2xl">
              <div className="flex justify-between items-center p-5 border-b border-[rgba(255,255,255,0.07)]">
                <h3 className="text-lg font-semibold text-red-400 flex items-center gap-2">
                  <i className="fas fa-exclamation-triangle"></i>
                  Confirm Delete
                </h3>
                <button onClick={() => setIsDeleteModalOpen(false)} className="text-[#B3B3B3] hover:text-white">
                  <i className="fas fa-times"></i>
                </button>
              </div>
              <div className="p-6 text-center">
                <p className="text-[#B3B3B3]">Are you sure you want to delete</p>
                <p className="text-white font-semibold mt-2">{deleteTarget.name} ?</p>
                <p className="text-red-400 text-xs mt-3">This action cannot be undone!</p>
              </div>
              <div className="flex justify-end gap-3 p-5 border-t border-[rgba(255,255,255,0.07)]">
                <button onClick={() => setIsDeleteModalOpen(false)} className="px-5 py-2 bg-[#231D1D] text-white rounded-lg">
                  Cancel
                </button>
                <button
                  onClick={confirmDelete}
                  disabled={deleteMutation.isPending}
                  className="px-5 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 flex items-center gap-2"
                >
                  {deleteMutation.isPending ? "Deleting..." : "Delete"}
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
};

export default Creator;