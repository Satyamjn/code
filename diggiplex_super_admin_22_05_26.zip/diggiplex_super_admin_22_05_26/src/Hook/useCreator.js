import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  addCreatorApi,
  getAllCreatorApi,
  updateCreatorById,
  deleteCreatorById,
} from "../Api/api";
import { toast } from "react-toastify";

// GET
export const useGetCreators = (page, limit) => {
  return useQuery({
    queryKey: ["creators", page],
    queryFn: () => getAllCreatorApi({ page, limit }),
  });
};

// CREATE
export const useCreateCreator = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: addCreatorApi,
    onSuccess: () => {
      toast.success("Creator created successfully!");
      queryClient.invalidateQueries(["creators"]);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to create creator");
    },
  });
};

// UPDATE
export const useUpdateCreator = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, data }) => updateCreatorById(id, data),
    onSuccess: () => {
      toast.success("Creator updated successfully!");
      queryClient.invalidateQueries(["creators"]);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to update creator");
    },
  });
};

// DELETE
export const useDeleteCreator = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: deleteCreatorById,
    onSuccess: () => {
      toast.success("Creator deleted successfully!");
      queryClient.invalidateQueries(["creators"]);
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to delete creator");
    },
  });
};