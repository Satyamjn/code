import {
  Box, Typography, Grid, Card, CardContent, LinearProgress,
  Chip, Divider
} from "@mui/material";
import TrendingUpRoundedIcon from "@mui/icons-material/TrendingUpRounded";
import { COLORS } from "../../theme/theme";

function ChartCard({ title, subtitle, height = 200, children, badge }) {
  return (
    <Card>
      <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 2 }}>
          <Box>
            <Typography sx={{ fontSize: "0.92rem", fontWeight: 700, color: COLORS.text }}>{title}</Typography>
            <Typography sx={{ fontSize: "0.72rem", color: COLORS.textSecondary, mt: 0.3 }}>{subtitle}</Typography>
          </Box>
          {badge && (
            <Chip
              label={badge}
              size="small"
              icon={<TrendingUpRoundedIcon style={{ fontSize: 12 }} />}
              sx={{
                bgcolor: "rgba(76,175,125,0.12)",
                border: "1px solid rgba(76,175,125,0.3)",
                color: COLORS.success,
                fontWeight: 700,
                fontSize: "0.7rem",
              }}
            />
          )}
        </Box>
        <Box sx={{ height, position: "relative" }}>{children}</Box>
      </CardContent>
    </Card>
  );
}

function BarChart({ data }) {
  const max = Math.max(...data.map((d) => d.value));
  return (
    <Box sx={{ display: "flex", alignItems: "flex-end", gap: 1, height: "100%", px: 1 }}>
      {data.map(({ label, value, highlight }, i) => (
        <Box key={i} sx={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 0.5, height: "100%" }}>
          <Typography sx={{ fontSize: "0.6rem", color: COLORS.textMuted, fontWeight: 600 }}>
            {value > 100 ? `${(value / 1000).toFixed(0)}K` : value}
          </Typography>
          <Box
            sx={{
              flex: 1, width: "100%", display: "flex", flexDirection: "column", justifyContent: "flex-end",
            }}
          >
            <Box
              sx={{
                width: "100%",
                height: `${(value / max) * 100}%`,
                borderRadius: "6px 6px 4px 4px",
                background: highlight
                  ? `linear-gradient(to top, ${COLORS.accentDark}, ${COLORS.accent})`
                  : `linear-gradient(to top, rgba(245,199,122,0.15), rgba(245,199,122,0.3))`,
                boxShadow: highlight ? `0 0 16px rgba(245,199,122,0.3)` : "none",
                transition: "height 0.3s ease",
                minHeight: 4,
              }}
            />
          </Box>
          <Typography sx={{ fontSize: "0.58rem", color: COLORS.textMuted }}>{label}</Typography>
        </Box>
      ))}
    </Box>
  );
}

function LineChartSVG({ data, color = COLORS.accent }) {
  const w = 400, h = 120;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const pts = data.map((v, i) => ({
    x: (i / (data.length - 1)) * w,
    y: h - ((v - min) / (max - min || 1)) * (h - 20) - 10,
  }));
  const path = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");
  const area = `${path} L ${pts[pts.length - 1].x} ${h} L 0 ${h} Z`;

  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" style={{ width: "100%", height: "100%" }}>
      <defs>
        <linearGradient id={`grad-${color.replace("#", "")}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0.02" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#grad-${color.replace("#", "")})`} />
      <path d={path} fill="none" stroke={color} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
      {pts.map((p, i) => (
        <circle key={i} cx={p.x} cy={p.y} r="3" fill={color} />
      ))}
    </svg>
  );
}

const WATCH_TIME = [
  { label: "Jun", value: 8200 }, { label: "Jul", value: 11400 }, { label: "Aug", value: 9600 },
  { label: "Sep", value: 14200 }, { label: "Oct", value: 16800 }, { label: "Nov", value: 13900 },
  { label: "Dec", value: 18600, highlight: true },
];

const GROWTH_DATA = [1200, 1800, 2400, 2100, 3200, 4100, 3800, 5200, 6100, 7400, 8200, 9800];
const COMPLETION_DATA = [72, 78, 68, 82, 75, 85, 80, 88, 76, 83, 79, 91];

const DEVICES = [
  { name: "Mobile", pct: 52, color: COLORS.accent },
  { name: "Desktop", pct: 28, color: "#7B61FF" },
  { name: "Smart TV", pct: 14, color: "#FF6B6B" },
  { name: "Tablet", pct: 6, color: COLORS.success },
];

const TOP_CONTENT = [
  { title: "Cinematic Travel Vlog — Bali", views: "284K", growth: "+32%" },
  { title: "Complete React TypeScript Course", views: "156K", growth: "+18%" },
  { title: "Street Food Tour Mumbai", views: "98K", growth: "+41%" },
  { title: "Productivity System for Creators", views: "62K", growth: "+12%" },
  { title: "Startup Funding Masterclass", views: "72K", growth: "+28%" },
];

export default function AnalyticsPage() {
  return (
    <Box>
      <Box sx={{ mb: 3 }}>
        <Typography variant="h5" sx={{ fontWeight: 700, mb: 0.5 }}>Analytics</Typography>
        <Typography sx={{ color: COLORS.textSecondary, fontSize: "0.88rem" }}>
          Performance insights for your content
        </Typography>
      </Box>

      {/* Summary strip */}
      <Box
        sx={{
          display: "flex", gap: 2, mb: 3,
          bgcolor: COLORS.surface,
          border: `1px solid ${COLORS.border}`,
          borderRadius: "5px",
          p: 2.5,
          flexWrap: "wrap",
        }}
      >
        {[
          { label: "Avg Watch Duration", value: "14m 28s", color: COLORS.accent },
          { label: "Avg Completion Rate", value: "79.4%", color: "#7B61FF" },
          { label: "New Subscribers", value: "+4,280", color: COLORS.success },
          { label: "Impressions", value: "8.6M", color: "#FF6B6B" },
        ].map(({ label, value, color }) => (
          <Box key={label} sx={{ flex: "1 1 120px", textAlign: "center" }}>
            <Typography sx={{ fontSize: "1.4rem", fontWeight: 800, color, letterSpacing: "-0.02em" }}>
              {value}
            </Typography>
            <Typography sx={{ fontSize: "0.72rem", color: COLORS.textSecondary }}>{label}</Typography>
          </Box>
        ))}
      </Box>

      <Grid container spacing={2.5}>
        {/* Watch Time Chart */}
        <Grid item xs={12} md={7}>
          <ChartCard title="Watch Time" subtitle="Monthly hours watched" badge="+19% this month" height={160}>
            <BarChart data={WATCH_TIME} />
          </ChartCard>
        </Grid>

        {/* Audience Growth */}
        <Grid item xs={12} md={5}>
          <ChartCard title="Audience Growth" subtitle="Subscribers over 12 months" badge="+28%" height={160}>
            <LineChartSVG data={GROWTH_DATA} color={COLORS.success} />
          </ChartCard>
        </Grid>

        {/* Completion Rate */}
        <Grid item xs={12} md={5}>
          <ChartCard title="Completion Rate" subtitle="% viewers who watch to end" badge="+6% avg" height={160}>
            <LineChartSVG data={COMPLETION_DATA} color="#7B61FF" />
          </ChartCard>
        </Grid>

        {/* Device Distribution */}
        <Grid item xs={12} md={4}>
          <Card>
            <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
              <Typography sx={{ fontSize: "0.92rem", fontWeight: 700, mb: 0.5 }}>Device Distribution</Typography>
              <Typography sx={{ fontSize: "0.72rem", color: COLORS.textSecondary, mb: 2.5 }}>Where your audience watches</Typography>

              <Box sx={{ display: "flex", flexDirection: "column", gap: 2 }}>
                {DEVICES.map(({ name, pct, color }) => (
                  <Box key={name}>
                    <Box sx={{ display: "flex", justifyContent: "space-between", mb: 0.6 }}>
                      <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                        <Box sx={{ width: 8, height: 8, borderRadius: "50%", bgcolor: color }} />
                        <Typography sx={{ fontSize: "0.8rem", color: COLORS.textSecondary }}>{name}</Typography>
                      </Box>
                      <Typography sx={{ fontSize: "0.8rem", fontWeight: 700, color }}>{pct}%</Typography>
                    </Box>
                    <LinearProgress
                      variant="determinate"
                      value={pct}
                      sx={{
                        height: 6,
                        "& .MuiLinearProgress-bar": { background: color },
                      }}
                    />
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>

        {/* Top performing */}
        <Grid item xs={12} md={3}>
          <Card sx={{ height: "100%" }}>
            <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
              <Typography sx={{ fontSize: "0.92rem", fontWeight: 700, mb: 0.5 }}>Top Content</Typography>
              <Typography sx={{ fontSize: "0.72rem", color: COLORS.textSecondary, mb: 2 }}>Best performing videos</Typography>
              <Box sx={{ display: "flex", flexDirection: "column", gap: 0 }}>
                {TOP_CONTENT.map(({ title, views, growth }, i) => (
                  <Box key={i}>
                    <Box sx={{ py: 1.5, display: "flex", alignItems: "center", gap: 1.5 }}>
                      <Typography sx={{ fontSize: "0.75rem", fontWeight: 800, color: COLORS.textMuted, minWidth: 16 }}>
                        {i + 1}
                      </Typography>
                      <Box sx={{ flex: 1, minWidth: 0 }}>
                        <Typography sx={{ fontSize: "0.78rem", fontWeight: 600, color: COLORS.text, noWrap: true, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {title}
                        </Typography>
                        <Typography sx={{ fontSize: "0.68rem", color: COLORS.textSecondary }}>
                          {views} views
                        </Typography>
                      </Box>
                      <Typography sx={{ fontSize: "0.7rem", fontWeight: 700, color: COLORS.success }}>
                        {growth}
                      </Typography>
                    </Box>
                    {i < TOP_CONTENT.length - 1 && <Divider sx={{ borderColor: COLORS.border }} />}
                  </Box>
                ))}
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );
}
