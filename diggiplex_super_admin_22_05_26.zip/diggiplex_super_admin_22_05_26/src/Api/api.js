import axios from "axios";

const BASE_URL = import.meta.env.VITE_API_URL;

// ================= BASE AXIOS =================
const api = axios.create({
  baseURL: BASE_URL,
  withCredentials: true,
});

// ================= REFRESH CONTROL (IMPORTANT) =================
let isRefreshing = false;
let failedQueue = [];

const processQueue = (error) => {
  failedQueue.forEach((prom) => {
    if (error) {
      prom.reject(error);
    } else {
      prom.resolve();
    }
  });

  failedQueue = [];
};

// ================= REFRESH TOKEN =================
const refreshToken = async () => {
  return axios.post(`${BASE_URL}/refreshToken`, {}, { withCredentials: true });
};



// ================= REQUEST INTERCEPTOR ✅ NEW =================
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("accessToken");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);



// ================= RESPONSE INTERCEPTOR =================
api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const originalRequest = error.config;

    if (
      error.response?.status === 401 &&
      !originalRequest._retry &&
      !originalRequest.url.includes("/super-admins/login") // ✅ login skip
    ) {
      originalRequest._retry = true;

      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then(() => api(originalRequest));
      }

      isRefreshing = true;

      try {
        await refreshToken();
        processQueue(null);
        return api(originalRequest);
      } catch (err) {
        processQueue(err);
        // ✅ Tokens clear karo
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        localStorage.removeItem("user");
        window.location.href = "/";
        return Promise.reject(err);
      } finally {
        isRefreshing = false;
      }
    }

    return Promise.reject(error);
  }
);


// ================= AUTH =================
export const loginApi = async (data) => {
  const res = await api.post(`/super-admins/login`, data);
  return res.data;
};
export const logoutApi = async (data) => {
  const res = await api.post(`/logout`, data);
  return res.data;
};

export const refreshTokenApi = refreshToken;

// ================= ADMIN =================
export const adminList = async (params) => {
  const res = await api.get("/admins", { params });
  return res.data;
};

export const adminDetails = async (id) => {
  const res = await api.get(`/admins/${id}`);
  return res.data;
};

export const createAdmin = async (data) => {
  const res = await api.post("/admins", data);
  return res.data;
};

export const updateAdmin = async ({ id, data }) => {
  const res = await api.patch(`/admins/${id}`, data);
  return res.data;
};

// Delete admin - URL sahi karo
export const deleteAdmin = async (id) => {
  const res = await api.delete(`/admins/${id}`);
  return res.data;
};

// ================= CREATOR =================
export const addCreatorApi = async (data) => {
  const res = await api.post(`/creators`, data);
  return res.data;
};

export const getAllCreatorApi = async (params) => {
  const res = await api.get(`/creators`, { params });
  return res.data;
};

// export const verifyEmail = async (token) => {
//   const res = await api.get(`/creators/login`, {
//     params: { token },
//   });
//   return res.data;
// };

export const updateCreatorById = async (id, data) => {
  const res = await api.patch(`/creators/${id}`, data);
  return res.data;
};

export const deleteCreatorById = async (id) => {
  const res = await api.delete(`/creators/${id}`);
  return res.data;
};

// ================= GENRE =================
export const addGenreApi = async (data) => {
  const res = await api.post(`/genres`, data, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return res.data;
};

export const updateGenreApi = async ({ id, data }) => {
  const res = await api.patch(`/genres/${id}`, data, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return res.data;
};

export const deleteGenreApi = async (id) => {
  const res = await api.delete(`/genres/${id}`);
  return res.data;
};

export const getAllGenreApi = async ({ page, limit }) => {
  const res = await api.get(`/genres`, {
    params: { page, limit },
  });
  return res.data;
};

// ================= LANGUAGE =================
export const addLanguageApi = async (data) => {
  const res = await api.post(`/languages`, data, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return res.data;
};

export const getAllLanguagesApi = async ({ page, limit }) => {
  const res = await api.get(`/languages`, {
    params: { page, limit },
  });
  return res.data;
};

export const updateLanguageApi = async ({ id, data }) => {
  const res = await api.patch(`/languages/${id}`, data, {
    headers: { "Content-Type": "multipart/form-data" },
  });
  return res.data;
};

export const deleteLanguageApi = async (id) => {
  const res = await api.delete(`/languages/${id}`);
  return res.data;
};
// =====================>user====================>
export const getAllUserApi = async ({ page, limit }) => {
  const res = await api.get(`/users`, {
    params: { page, limit },
  });
  return res.data;
};

export const userDetailsApi = async (id) => {
  const res = await api.get(`/users/${id}`);
  return res.data;
};

// upload apis
export const getAllUploadApi = async ({ page, limit, status }) => {
  const res = await api.get("/uploads", {
    params: { 
      page, 
      limit, 
      ...(status && { status }) // 🔥 dynamic
    },
  });
  return res.data;
};


export const getUploadDetails = async (id) => {
  const res = await api.get(`/uploads/${id}`);
  return res.data;
};


export const videoApproveApi = async (id) => {
  const res = await api.patch(`/uploads/${id}/approve`);
  return res.data;
};

export const videoPublish = async (id) => {
  const res = await api.patch(`/uploads/${id}/publish`);
  return res.data;
};

export const videoReject = async (id) => {
  const res = await api.patch(`/uploads/${id}/reject`);
  return res.data;
};



// ================= USER ACTIONS =================
// ✅ FIXED
export const banUserApi = async (id, reason) => {
  const res = await api.patch(`/users/${id}/ban`, { reason });
  return res.data;
};

export const unbanUserApi = async (id, reason) => {
  const res = await api.patch(`/users/${id}/unban`, { reason });
  return res.data;
};

export const forceLogoutUserApi = async (id) => {
  const res = await api.post(
    `/users/${id}/logout-all-devices`,
    {}
  );

  return res.data;
};

