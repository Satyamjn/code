// types/homepage.types.ts
export interface HomepageItem {
  id: string;
  title: string;
  type: "MOVIE" | "WEB_SERIES";
  contentKind: "MOVIE" | "EPISODE" | "PODCAST_EP" | "MUSIC_TRACK" | "SHORT" | "STANDUP";
  genreId: string | null;
  thumbnailUrl: string | null;
  posterUrl: string | null;
  rating?: number;
  releaseYear?: number;
  duration?: number;
  status: string;
}

export interface PaginatedResponse {
  items: HomepageItem[];
  totalCount: number;
  hasMore: boolean;
  nextOffset?: number;
}

// helper/homepage.helper.ts

// Statuses that should be shown on homepage (PUBLISHED is the final state)
export const HOMEPAGE_STATUSES = [
  "PUBLISHED",  // Final published state for streaming
  "READY",      // Ready but not yet published (admin preview)
  "APPROVED",   // Approved content
] as const;

// Transform upload + assets to lightweight homepage item
export const transformToHomepageItem = (upload: any): HomepageItem => {
  // Find THUMBNAIL and POSTER assets
  const thumbnailAsset = upload.assets?.find(
    (asset: any) => asset.assetType === "IMAGE" && asset.assetRole === "THUMBNAIL"
  );
  
  const posterAsset = upload.assets?.find(
    (asset: any) => asset.assetType === "IMAGE" && asset.assetRole === "POSTER"
  );

  return {
    id: upload.id,
    title: upload.title,
    type: upload.type === "MOVIE" ? "MOVIE" : "WEB_SERIES",
    contentKind: upload.contentKind || (upload.type === "MOVIE" ? "MOVIE" : "EPISODE"),
    genreId: upload.genreId,
    thumbnailUrl: thumbnailAsset?.masterPlaylistUrl || thumbnailAsset?.fileKey || null,
    posterUrl: posterAsset?.masterPlaylistUrl || posterAsset?.fileKey || null,
    rating: upload.metadata?.rating,
    releaseYear: upload.metadata?.releaseYear,
    duration: upload.metadata?.duration,
    status: upload.status,
  };
};