import {
  Drawer,
  Box,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
  Divider,
} from "@mui/material";

import DashboardRoundedIcon from "@mui/icons-material/DashboardRounded";
import VideoCallRoundedIcon from "@mui/icons-material/VideoCallRounded";
import VideoLibraryRoundedIcon from "@mui/icons-material/VideoLibraryRounded";
import BarChartRoundedIcon from "@mui/icons-material/BarChartRounded";
import AttachMoneyRoundedIcon from "@mui/icons-material/AttachMoneyRounded";
import PlayCircleFilledRoundedIcon from "@mui/icons-material/PlayCircleFilledRounded";
import ContentPasteRoundedIcon from "@mui/icons-material/ContentPasteRounded"; // Add this import
import PersonAddAlt1Icon from "@mui/icons-material/PersonAddAlt1";
import { COLORS } from "../../theme/theme";
import CategoryRoundedIcon from '@mui/icons-material/CategoryRounded';
import LanguageRoundedIcon from '@mui/icons-material/LanguageRounded';
import AdminPanelSettingsIcon from '@mui/icons-material/AdminPanelSettings';
import PeopleIcon from "@mui/icons-material/People";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";

import { useNavigate, useLocation } from "react-router-dom";
import { useState } from "react";
import { Collapse } from "@mui/material";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";

const NAV_ITEMS = [
  {
    id: "dashboard",
    label: "Dashboard",
    icon: <DashboardRoundedIcon />,
    path: "/dashboard",
  },
  {
    id: "Admin ",
    label: "Admin Management",
    icon: <AdminPanelSettingsIcon />,
    path: "/createAdmin",
    children: [
      { id: "upload", label: "Create Admin", path: "/createAdmin" }
      // { id: "live", label: "Creator List", path: "/creator/creatorlist" }
 
    ],
  },
  {
    id: "User ",
    label: "User Management",
    icon: <PeopleIcon />,
    path: "/user",
    children: [
      { id: "upload", label: "User", path: "/user" }
      // { id: "live", label: "Creator List", path: "/creator/creatorlist" }
 
    ],
  },

  {
    id: "Upload ",
    label: "Upload Management",
    icon: <CloudUploadIcon />,
    path: "/uploadlist",
    children: [
      { id: "upload", label: "Pending List", path: "/uploadpendinglist" } ,
      { id: "upload", label: "Approved List", path: "/uploadapprovelist" } ,
      { id: "upload", label: "Published List", path: "/uploadpublishlist" } 
    ],
  },
   {
    id: "Creator ",
    label: "Creator Management",
    icon: <PersonAddAlt1Icon />,
    path: "/creator",
    children: [
      { id: "upload", label: "Creator Account", path: "/creator" }
      // { id: "live", label: "Creator List", path: "/creator/creatorlist" }
 
    ],
  },
 
  {
    id: "Genre",
    label: "Genre ",
    icon: <CategoryRoundedIcon />,
    path: "/",
    children: [
      { id: "upload", label: "Create Genre", path: "/createGenre" }
  
    ],
  },
    {
    id: "Language",
    label: "Language ",
    icon: <LanguageRoundedIcon />,
    path: "/",
    children: [
      { id: "upload", label: "Language Create", path: "/createLanguage" }
  
    ],
  },
  {
    id: "library",
    label: "Content Library",
    icon: <VideoLibraryRoundedIcon />,
    path: "/library",
  },
  {
    id: "analytics",
    label: "Analytics",
    icon: <BarChartRoundedIcon />,
    path: "/analytics",
  },
  {
    id: "revenue",
    label: "Revenue",
    icon: <AttachMoneyRoundedIcon />,
    path: "/revenue",
  },
];

function NavItem({ item, active, onClick, isOpen }) {
  return (
    <ListItem disablePadding sx={{ mb: 0.5 }}>
      <ListItemButton
        onClick={onClick}
        sx={{
          borderRadius: "5px",
          mx: 1.5,
          px: 2,
          py: 1.3,
          position: "relative",
          transition: "all 0.2s ease",
          bgcolor: active ? COLORS.accentGlow : "transparent",
          "&:hover": {
            bgcolor: active ? COLORS.accentGlow : "rgba(255,255,255,0.04)",
          },
        }}
      >
        <ListItemIcon
          sx={{
            minWidth: 38,
            color: active ? COLORS.accent : COLORS.textMuted,
          }}
        >
          {item.icon}
        </ListItemIcon>

        <ListItemText
          primary={item.label}
          primaryTypographyProps={{
            fontSize: "0.88rem",
            fontWeight: active ? 600 : 400,
            color: active ? COLORS.accent : COLORS.textSecondary,
          }}
        />

        {/* Expand Icon */}
        {item.children &&
          (isOpen ? (
            <ExpandLessIcon sx={{ color: COLORS.textMuted }} />
          ) : (
            <ExpandMoreIcon sx={{ color: COLORS.textMuted }} />
          ))}
      </ListItemButton>
    </ListItem>
  );
}

function SidebarContent({ setMobileOpen }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [openMenu, setOpenMenu] = useState(null);

  const handleNavigation = (path) => {
    navigate(path);
    if (setMobileOpen) setMobileOpen(false);
  };

  return (
    <Box
      sx={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        bgcolor: "#130E0E",
        borderRight: `1px solid ${COLORS.border}`,
      }}
    >
      {/* Logo */}
      <Box sx={{ px: 3, pt: 3, pb: 2.5 }}>
        <Box sx={{ display: "flex", alignItems: "center", gap: 1.5 }}>
          <Box
            sx={{
              width: 38,
              height: 38,
              borderRadius: "5px",
              background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.accentDark})`,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <PlayCircleFilledRoundedIcon
              sx={{ color: "#0F0A0A", fontSize: 22 }}
            />
          </Box>

          <Typography
            variant="h6"
            sx={{
              fontWeight: 800,
              fontSize: "1.2rem",
              background: `linear-gradient(90deg, ${COLORS.accent}, #fff)`,
              WebkitBackgroundClip: "text",
              WebkitTextFillColor: "transparent",
            }}
          >
            Digiiplex
          </Typography>
        </Box>
      </Box>

      <Divider sx={{ borderColor: COLORS.border, mx: 2 }} />

      <Typography
        sx={{
          px: 3,
          fontSize: "0.65rem",
          color: COLORS.textMuted,
          letterSpacing: "0.1em",
          textTransform: "uppercase",
          mb: 1,
          fontWeight: 600,
        }}
      >
        Main Menu
      </Typography>

      <List disablePadding sx={{ flex: 1 }}>
        {NAV_ITEMS.map((item) => {
          // Check if current route matches this item or its children
          const isParentActive = location.pathname === item.path || 
            (item.children && item.children.some(child => location.pathname === child.path));

          return (
            <Box key={item.id}>
              <NavItem
                item={item}
                active={isParentActive}
                isOpen={openMenu === item.id}
                onClick={() => {
                  if (item.children) {
                    setOpenMenu(openMenu === item.id ? null : item.id);
                  } else {
                    handleNavigation(item.path);
                  }
                }}
              />

              {item.children && (
                <Collapse
                  in={openMenu === item.id}
                  timeout="auto"
                  unmountOnExit
                >
                  <List disablePadding sx={{ pl: 4 }}>
                    {item.children.map((child) => {
                      const activeChild = location.pathname === child.path;

                      return (
                        <ListItemButton
                          key={child.id}
                          onClick={() => handleNavigation(child.path)}
                          sx={{
                            py: 0.8,
                            borderRadius: "4px",
                            mb: 0.5,
                            color: activeChild
                              ? COLORS.accent
                              : COLORS.textSecondary,
                            bgcolor: activeChild
                              ? COLORS.accentGlow
                              : "transparent",
                            "&:hover": {
                              bgcolor: activeChild
                                ? COLORS.accentGlow
                                : "rgba(255,255,255,0.04)",
                            },
                          }}
                        >
                          <ListItemText
                            primary={child.label}
                            primaryTypographyProps={{
                              fontSize: "0.8rem",
                              fontWeight: activeChild ? 600 : 400,
                            }}
                          />
                        </ListItemButton>
                      );
                    })}
                  </List>
                </Collapse>
              )}
            </Box>
          );
        })}
      </List>
    </Box>
  );
}

export default function Sidebar({ drawerWidth, mobileOpen, setMobileOpen }) {
  return (
    <>
      <Drawer
        variant="temporary"
        open={mobileOpen}
        onClose={() => setMobileOpen(false)}
        ModalProps={{ keepMounted: true }}
        sx={{
          display: { xs: "block", sm: "none" },
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            bgcolor: "transparent",
            border: "none",
          },
        }}
      >
        <SidebarContent setMobileOpen={setMobileOpen} />
      </Drawer>

      <Drawer
        variant="permanent"
        sx={{
          display: { xs: "none", sm: "block" },
          width: drawerWidth,
          flexShrink: 0,
          "& .MuiDrawer-paper": {
            width: drawerWidth,
            bgcolor: "transparent",
            border: "none",
          },
        }}
      >
        <SidebarContent setMobileOpen={() => {}} />
      </Drawer>
    </>
  );
}