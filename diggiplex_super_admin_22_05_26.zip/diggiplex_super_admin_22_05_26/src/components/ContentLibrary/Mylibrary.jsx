import React, { useState } from "react";
import { Box, Grid, Paper, Typography, Button, IconButton, LinearProgress } from "@mui/material";
import { PlayArrow, Download, Delete, Folder } from "@mui/icons-material";
import { COLORS } from "../../theme/theme";

const Mylibrary = () => {
  const [folders] = useState([
    { id: 1, name: "Tutorials", count: 12, size: "2.4 GB" },
    { id: 2, name: "Vlogs", count: 8, size: "1.8 GB" },
    { id: 3, name: "Podcasts", count: 5, size: "950 MB" },
    { id: 4, name: "Shorts", count: 15, size: "3.2 GB" },
  ]);

  return (
    <Box>
      <Grid container spacing={3}>
        {folders.map((folder) => (
          <Grid item xs={12} sm={6} md={3} key={folder.id}>
            <Paper sx={{ background: COLORS.background, border: `1px solid ${COLORS.primary}20`, p: 2, textAlign: "center", "&:hover": { transform: "translateY(-4px)", transition: "transform 0.2s" } }}>
              <Folder sx={{ fontSize: 48, color: COLORS.primary, mb: 1 }} />
              <Typography variant="h6" sx={{ color: COLORS.primary }}>{folder.name}</Typography>
              <Typography variant="caption" sx={{ color: COLORS.textMuted, display: "block" }}>{folder.count} items • {folder.size}</Typography>
              <LinearProgress variant="determinate" value={Math.random() * 100} sx={{ mt: 2, backgroundColor: `${COLORS.primary}20`, "& .MuiLinearProgress-bar": { backgroundColor: COLORS.primary } }} />
              <Box sx={{ display: "flex", justifyContent: "center", gap: 1, mt: 2 }}>
                <IconButton size="small" sx={{ color: COLORS.primary }}><PlayArrow fontSize="small" /></IconButton>
                <IconButton size="small" sx={{ color: COLORS.primary }}><Download fontSize="small" /></IconButton>
                <IconButton size="small" sx={{ color: COLORS.error }}><Delete fontSize="small" /></IconButton>
              </Box>
            </Paper>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default Mylibrary;