import { Grid, Card, CardContent, Box, Typography } from "@mui/material";
import TrendingUpRoundedIcon from "@mui/icons-material/TrendingUpRounded";
import TrendingDownRoundedIcon from "@mui/icons-material/TrendingDownRounded";
import { COLORS } from "../../theme/theme";

function StatCard({ icon, label, value, change, changeType, gradient, description }) {
  const isPositive = changeType === "up";

  return (
    <Card
      sx={{
        position: "relative",
        overflow: "hidden",
        "&::before": {
          content: '""',
          position: "absolute",
          top: 0, left: 0, right: 0,
          height: "2px",
          background: gradient,
        },
      }}
    >
      <CardContent sx={{ p: 2.5, "&:last-child": { pb: 2.5 } }}>
        {/* Icon row */}
        <Box sx={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", mb: 2 }}>
          <Box
            sx={{
              width: 46, height: 46, borderRadius: "5px",
              background: gradient,
              display: "flex", alignItems: "center", justifyContent: "center",
              boxShadow: "0 4px 16px rgba(0,0,0,0.3)",
              "& svg": { fontSize: 22, color: "#0F0A0A" },
            }}
          >
            {icon}
          </Box>
          <Box
            sx={{
              display: "flex", alignItems: "center", gap: 0.4,
              bgcolor: isPositive ? "rgba(76,175,125,0.12)" : "rgba(244,67,54,0.12)",
              border: `1px solid ${isPositive ? "rgba(76,175,125,0.3)" : "rgba(244,67,54,0.3)"}`,
              borderRadius: "5px",
              px: 1, py: 0.4,
            }}
          >
            {isPositive
              ? <TrendingUpRoundedIcon sx={{ fontSize: 13, color: COLORS.success }} />
              : <TrendingDownRoundedIcon sx={{ fontSize: 13, color: COLORS.error }} />
            }
            <Typography sx={{ fontSize: "0.72rem", fontWeight: 700, color: isPositive ? COLORS.success : COLORS.error }}>
              {change}
            </Typography>
          </Box>
        </Box>

        {/* Value */}
        <Typography
          sx={{
            fontSize: "1.9rem", fontWeight: 800, color: COLORS.text,
            letterSpacing: "-0.02em", lineHeight: 1, mb: 0.5,
          }}
        >
          {value}
        </Typography>

        {/* Label */}
        <Typography sx={{ fontSize: "0.8rem", color: COLORS.textSecondary, fontWeight: 500 }}>
          {label}
        </Typography>

        {/* Description */}
        <Typography sx={{ fontSize: "0.7rem", color: COLORS.textMuted, mt: 0.5 }}>
          {description}
        </Typography>
      </CardContent>
    </Card>
  );
}

const STATS = [
  {
    label: "Total Content Uploaded",
    value: "248",
    change: "+12%",
    changeType: "up",
    description: "vs last month",
    gradient: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.accentDark})`,
    icon: <span style={{ fontSize: 20 }}>🎬</span>,
  },
  {
    label: "Total Views",
    value: "4.2M",
    change: "+28%",
    changeType: "up",
    description: "across all content",
    gradient: "linear-gradient(135deg, #7B61FF, #5B41DF)",
    icon: <span style={{ fontSize: 20 }}>👁</span>,
  },
  {
    label: "Watch Time",
    value: "18.6K hrs",
    change: "+19%",
    changeType: "up",
    description: "total hours watched",
    gradient: "linear-gradient(135deg, #FF6B6B, #CC4444)",
    icon: <span style={{ fontSize: 20 }}>⏱</span>,
  },
  {
    label: "Total Earnings",
    value: "₹2.48L",
    change: "-3%",
    changeType: "down",
    description: "revenue this quarter",
    gradient: `linear-gradient(135deg, #4CAF7D, #2E7D52)`,
    icon: <span style={{ fontSize: 20 }}>💰</span>,
  },
];

export default function DashboardCards() {
  return (
    <Grid container spacing={2.5}>
      {STATS.map((stat) => (
        <Grid item xs={12} sm={6} lg={3} key={stat.label}>
          <StatCard {...stat} />
        </Grid>
      ))}
    </Grid>
  );
}
