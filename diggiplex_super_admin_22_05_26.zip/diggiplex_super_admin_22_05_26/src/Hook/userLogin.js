import { useMutation } from "@tanstack/react-query";
import { loginApi,logoutApi } from "../Api/api";

export const useLogin = () => {
    return useMutation({
        mutationFn: loginApi
    })
}
export const useLogout = () => {
    return useMutation({
        mutationFn: logoutApi
    })
}





