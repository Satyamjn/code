// src/pages/UploadList.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  useGetUploads
} from "../Hook/useUpload";

const UploadList = () => {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  // Hooks - list API
  const {
    data: uploadsData,
    isLoading,
    isError,
    error: fetchError,
    refetch,
  } = useGetAllUploads(currentPage, itemsPerPage);

  // Mutation hooks - only archive for published videos (no publish button)
  // const archiveVideo = useArchiveVideo();

  // Get all videos from response
  const allVideos = uploadsData?.data?.videos || [];
  
  // Filter videos where video.status === "PUBLISHED"
  const videos = allVideos.filter(video => video.status === "PUBLISHED");
  
  // Get pagination data (original pagination from API)
  const pagination = uploadsData?.data?.pagination || { 
    total: 0, 
    page: 1, 
    limit: itemsPerPage, 
    totalPages: 1 
  };
  const totalPages = pagination.totalPages || 1;

  // Navigate to details page
  const handleViewDetails = (videoId) => {
   navigate(`/upload_details/${videoId}`, {
  state: { from: "/uploadlist" }
});
  };

  // Handle archive
  // const handleArchive = (id, event) => {
  //   event.stopPropagation();
  //   archiveVideo.mutate(id);
  // };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleString();
  };

  // Get thumbnail URL from assets
  const getThumbnailUrl = (video) => {
    if (video.assets && video.assets.length > 0 && video.assets[0].thumbnailUrl) {
      return video.assets[0].thumbnailUrl;
    }
    return null;
  };

  // Get status badge based on video status
  const getStatusBadge = (video) => {
    const status = video.status || "PUBLISHED";
    
    switch(status) {
      case "PUBLISHED":
        return {
          text: "Published",
          color: "text-[#4caf7d]",
          bg: "bg-[rgba(76,175,80,0.15)]",
          border: "border-[rgba(76,175,80,0.3)]",
          icon: "fa-globe"
        };
      case "APPROVED":
        return {
          text: "Approved",
          color: "text-[#2196f3]",
          bg: "bg-[rgba(33,150,243,0.15)]",
          border: "border-[rgba(33,150,243,0.3)]",
          icon: "fa-check-circle"
        };
      case "ARCHIVED":
        return {
          text: "Archived",
          color: "text-[#ff9800]",
          bg: "bg-[rgba(255,152,0,0.15)]",
          border: "border-[rgba(255,152,0,0.3)]",
          icon: "fa-archive"
        };
      case "DRAFT":
      default:
        return {
          text: "Draft",
          color: "text-[#ff9800]",
          bg: "bg-[rgba(255,152,0,0.15)]",
          border: "border-[rgba(255,152,0,0.3)]",
          icon: "fa-pencil-alt"
        };
    }
  };

  // Get upload type badge
  const getUploadTypeBadge = (type) => {
    const types = {
      "WEBSERIES": { text: "Web Series", color: "text-[#ce93d8]" },
      "MOVIE": { text: "Movie", color: "text-[#64b5f6]" },
      "TRAILER": { text: "Trailer", color: "text-[#ffb74d]" }
    };
    return types[type] || { text: type || "Unknown", color: "text-[#B3B3B3]" };
  };

  // Get upload status badge
  const getUploadStatusBadge = (status) => {
    switch(status?.toUpperCase()) {
      case "READY":
        return {
          text: "Ready",
          color: "text-[#4caf7d]",
          bg: "bg-[rgba(76,175,80,0.15)]",
          border: "border-[rgba(76,175,80,0.3)]",
          icon: "fa-check-circle"
        };
      case "PROCESSING":
        return {
          text: "Processing",
          color: "text-[#ff9800]",
          bg: "bg-[rgba(255,152,0,0.15)]",
          border: "border-[rgba(255,152,0,0.3)]",
          icon: "fa-spinner"
        };
      case "FAILED":
        return {
          text: "Failed",
          color: "text-[#f44336]",
          bg: "bg-[rgba(244,67,54,0.15)]",
          border: "border-[rgba(244,67,54,0.3)]",
          icon: "fa-times-circle"
        };
      default:
        return {
          text: status || "Unknown",
          color: "text-[#B3B3B3]",
          bg: "bg-[rgba(156,39,176,0.15)]",
          border: "border-[rgba(156,39,176,0.3)]",
          icon: "fa-question-circle"
        };
    }
  };

  return (
    <div className="h-screen flex overflow-hidden" style={{ background: 'rgba(15, 10, 10, 0.85)' }}>
      <div className="flex-1 overflow-auto px-4 py-6">
        <div className="w-full max-w-full">
          {/* Header */}
          <div className="mb-6">
            <h5 className="text-xl font-bold text-[#f5c77a]">Published Videos</h5>
            <p className="text-[#B3B3B3] text-sm mt-1">View and manage published videos</p>
          </div>

          {/* Videos List Table */}
          <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.125)] overflow-hidden">
            <div className="p-4 border-b border-[rgba(255,255,255,0.07)]">
              <h6 className="text-lg font-semibold text-[#f5c77a]">Published List</h6>
              <p className="text-[#B3B3B3] text-sm mt-1">Total Published Videos: {videos.length}</p>
            </div>
            
            <div className="w-full overflow-x-auto">
              {isLoading ? (
                <div className="flex justify-center items-center py-12">
                  <svg className="animate-spin h-8 w-8 text-[#f5c77a]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                </div>
              ) : isError ? (
                <div className="text-center py-12 text-red-400">
                  <i className="fas fa-exclamation-triangle text-3xl mb-2 block"></i>
                  <p>{fetchError?.message || "Failed to load videos"}</p>
                  <button 
                    onClick={() => refetch()}
                    className="mt-4 px-4 py-2 bg-[#f5c77a] text-[#0F0A0A] rounded text-sm"
                  >
                    Try Again
                  </button>
                </div>
              ) : videos?.length > 0 ? (
                <>
                  <table className="w-full">
                    <thead className="bg-[#231D1D] border-b border-[rgba(255,255,255,0.07)]">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">S.No</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Thumbnail</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Title</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Type</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Upload Status</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Creator</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Created At</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[rgba(255,255,255,0.07)]">
                      {videos.map((video, index) => {
                        const status = getStatusBadge(video);
                        const uploadStatus = getUploadStatusBadge(video.upload?.status);
                        const uploadType = getUploadTypeBadge(video.upload?.type);
                        const thumbnailUrl = getThumbnailUrl(video);
                        
                        return (
                          <tr 
                            key={video.id} 
                            onClick={() => handleViewDetails(video.id)}
                            className="hover:bg-[rgba(245,199,122,0.05)] transition cursor-pointer"
                          >
                            <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                              {index + 1}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {thumbnailUrl ? (
                                <img 
                                  src={thumbnailUrl} 
                                  alt={video.title}
                                  className="w-16 h-12 object-cover rounded"
                                  onError={(e) => {
                                    e.target.onerror = null;
                                    e.target.src = "https://via.placeholder.com/160x120?text=No+Image";
                                  }}
                                />
                              ) : (
                                <div className="w-16 h-12 bg-[#231D1D] rounded flex items-center justify-center">
                                  <i className="fas fa-video text-2xl text-[#B3B3B3]"></i>
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4 text-sm text-white">
                              <div className="max-w-xs">
                                <p className="font-medium truncate">{video.title}</p>
                                {video.description && (
                                  <p className="text-xs text-[#B3B3B3] truncate mt-1">{video.description.substring(0, 60)}</p>
                                )}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className="px-2 py-1 text-xs rounded-full bg-[rgba(156,39,176,0.15)] text-[#ce93d8] border border-[rgba(156,39,176,0.3)]">
                                <i className="fas fa-tag mr-1"></i> {uploadType.text}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs rounded-full ${status.bg} ${status.color} border ${status.border}`}>
                                <i className={`fas ${status.icon} mr-1`}></i> {status.text}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs rounded-full ${uploadStatus.bg} ${uploadStatus.color} border ${uploadStatus.border}`}>
                                <i className={`fas ${uploadStatus.icon} mr-1`}></i> {uploadStatus.text}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                              {video.upload?.creatorId ? (
                                <span className="text-xs font-mono">{video.upload.creatorId.substring(0, 8)}...</span>
                              ) : "Unknown"}
                            </td>
                            <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                              {formatDate(video.createdAt)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                              <div className="flex gap-2">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleViewDetails(video.id);
                                  }}
                                  className="px-3 py-1 text-xs bg-[rgba(33,150,243,0.15)] text-[#2196f3] rounded hover:bg-[rgba(33,150,243,0.25)] transition flex items-center gap-1"
                                >
                                  <i className="fas fa-eye"></i> View Details
                                </button>
                                <button
                                  onClick={(e) => handleArchive(video.id, e)}
                                  disabled={archiveVideo.isLoading}
                                  className="px-3 py-1 text-xs bg-[rgba(255,152,0,0.15)] text-[#ff9800] rounded hover:bg-[rgba(255,152,0,0.25)] transition flex items-center gap-1"
                                >
                                  <i className="fas fa-archive"></i> Archive
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>

                  {/* Pagination */}
                  {totalPages > 1 && (
                    <div className="flex justify-center gap-2 py-4 border-t border-[rgba(255,255,255,0.07)]">
                      <button
                        onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                        disabled={currentPage === 1}
                        className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                      >
                        Previous
                      </button>
                      {[...Array(Math.min(totalPages, 10))].map((_, i) => (
                        <button
                          key={i}
                          onClick={() => setCurrentPage(i + 1)}
                          className={`px-3 py-1 text-sm rounded transition ${
                            currentPage === i + 1
                              ? "bg-[#f5c77a] text-[#0F0A0A]"
                              : "bg-[#231D1D] text-[#B3B3B3] hover:bg-[rgba(245,199,122,0.1)]"
                          }`}
                        >
                          {i + 1}
                        </button>
                      ))}
                      {totalPages > 10 && (
                        <span className="px-3 py-1 text-sm text-[#B3B3B3]">...</span>
                      )}
                      <button
                        onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                        disabled={currentPage === totalPages}
                        className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                      >
                        Next
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-12 text-[#B3B3B3]">
                  <i className="fas fa-globe text-3xl mb-2 block"></i>
                  <p>No Published Videos found</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default UploadList;