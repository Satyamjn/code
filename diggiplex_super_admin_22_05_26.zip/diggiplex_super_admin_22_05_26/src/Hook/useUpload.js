// src/Hook/useUpload.js
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "react-toastify";
import {
  getAllUploadApi,
  getUploadDetails,
  videoApproveApi,
  videoPublish,
  videoReject,
} from "../Api/api";


//  1. Dynamic uploads (ALL / PENDING / APPROVED / PUBLISHED)
export const useGetUploads = (page, limit, status) => {
  return useQuery({
    queryKey: ["uploads", page, limit, status], 
    queryFn: () => getAllUploadApi({ page, limit, status }),
    
    //  direct usable data
    select: (res) => res?.data?.uploads || [],

    keepPreviousData: true,

    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Failed to fetch uploads"
      );
    },
  });
};


//  2. Upload Details
export const useUploadDetails = (id) => {
  return useQuery({
    queryKey: ["uploadDetails", id],
    queryFn: () => getUploadDetails(id),
    enabled: !!id,
    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Failed to fetch details"
      );
    },
  });
};


//  3. Approve
export const useApproveVideo = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: videoApproveApi,
    onSuccess: (data) => {
      toast.success(data?.message || "Approved Successfully");

      //  refresh all uploads
      queryClient.invalidateQueries({ queryKey: ["uploads"] });
      queryClient.invalidateQueries({ queryKey: ["uploadDetails"] });
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Approve failed"
      );
    },
  });
};


//  4. Publish
export const usePublishVideo = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: videoPublish,
    onSuccess: (data) => {
      toast.success(data?.message || "Published Successfully 🚀");

      queryClient.invalidateQueries({ queryKey: ["uploads"] });
      queryClient.invalidateQueries({ queryKey: ["uploadDetails"] });
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Publish failed"
      );
    },
  });
};


//  5. Reject
export const useRejectVideo = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: videoReject,
    onSuccess: (data) => {
      toast.success(data?.message || "Rejected Successfully");

      queryClient.invalidateQueries({ queryKey: ["uploads"] });
      queryClient.invalidateQueries({ queryKey: ["uploadDetails"] });
    },
    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Reject failed"
      );
    },
  });
};
