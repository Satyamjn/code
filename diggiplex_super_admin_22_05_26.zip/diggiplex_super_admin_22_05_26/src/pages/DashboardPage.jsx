// src/pages/Dashboard/DashboardPage.jsx
import React, { useState, useEffect } from "react";
import {
  TrendingUp,
  TrendingDown,
  Visibility,
  Subscriptions,
  PlayArrow,
  Movie,
  Schedule,
  Whatshot,
  Star,
  People,
  ArrowUpward,
  ArrowDownward,
  AccessTime,
  Favorite,
  Comment,
  Share,
} from "@mui/icons-material";
import { motion } from "framer-motion";
import WarningAmber from "@mui/icons-material/WarningAmber";
import WorkspacePremium from "@mui/icons-material/WorkspacePremium";
import AttachMoney from "@mui/icons-material/AttachMoney";
import Dns from "@mui/icons-material/Dns";
import LocalFireDepartment from "@mui/icons-material/LocalFireDepartment";
// Color scheme as Tailwind config - Add these to your tailwind.config.js
const COLORS = {
  primary: "#f5c77a",
  primaryDark: "#c49a4e",
  background: "rgba(15, 10, 10, 0.85)",
  cardBg: "#1C1616",
  cardLight: "#231D1D",
  text: "#FFFFFF",
  textSecondary: "#B3B3B3",
  textMuted: "#6B6B6B",
  success: "#4caf7d",
  error: "#f44336",
  warning: "#ff9800",
  info: "#2196f3",
  border: "rgba(245,199,122,0.125)",
  borderLight: "rgba(255,255,255,0.07)",
};

// Quick Stats Component
const QuickStatMini = ({ label, value, sub, color, icon, trend, trendValue }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="group"
    >
      <div className="bg-[#1C1616] rounded-xl border border-[rgba(245,199,122,0.125)] p-5 transition-all duration-300 hover:-translate-y-1 hover:border-[#f5c77a] hover:shadow-[0_6px_28px_rgba(245,199,122,0.15)]">
        <div className="flex justify-between items-center mb-3">
          <div
            className="w-10 h-10 rounded-full flex items-center justify-center"
            style={{ backgroundColor: `${color}15` }}
          >
            <div style={{ color: color }}>{icon}</div>
          </div>
          {trend && (
            <span
              className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-semibold ${trend === "up"
                ? "bg-green-500/15 text-green-500 border border-green-500/30"
                : "bg-red-500/15 text-red-500 border border-red-500/30"
                }`}
            >
              {trend === "up" ? <ArrowUpward className="w-3 h-3" /> : <ArrowDownward className="w-3 h-3" />}
              {trendValue}%
            </span>
          )}
        </div>
        <div className="text-[1.8rem] font-bold mb-1" style={{ color: color }}>
          {value}
        </div>
        <div className="text-sm font-medium text-white mb-0.5">
          {label}
        </div>
        <div className="text-xs text-[#6B6B6B]">
          {sub}
        </div>
      </div>
    </motion.div>
  );
};

// Main Dashboard Component
export default function DashboardPage() {
  const [loading, setLoading] = useState(false);
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  // Mock data - replace with actual API calls
  const stats = {
    // totalViews: "2.4M",
    // totalRevenue: "$124,567",
    // activeUsers: "12,345",
    // totalContent: "456",
    // avgWatchTime: "24m 32s",
    // completionRate: "78",


    // new points 


    totalUsers: "50,234",
    activeSubscriptions: "8,920",
    revenueAnalytics: "$89,450",
    watchTimeStatistics: "1,240 hrs",

  };

  const trendingContent = [
    {
      id: 1,
      title: "Stranger Things",
      genre: "Sci-Fi Horror",
      views: "1.2M",
      rating: 4.8,
      trend: "+28%",
      image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=400&h=200&fit=crop",
    },
    {
      id: 2,
      title: "The Crown",
      genre: "Drama",
      views: "892K",
      rating: 4.7,
      trend: "+15%",
      image: "https://images.unsplash.com/photo-1485846234645-a62644f84728?w=400&h=200&fit=crop",
    },
    {
      id: 3,
      title: "Squid Game",
      genre: "Thriller",
      views: "2.1M",
      rating: 4.9,
      trend: "+45%",
      image: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=400&h=200&fit=crop",
    },
  ];

  const recentActivities = [
    { id: 1, user: "John Doe", action: "watched", content: "Stranger Things S4", time: "2 mins ago", type: "watch", icon: <PlayArrow className="w-4 h-4" /> },
    { id: 2, user: "Jane Smith", action: "rated", content: "The Crown", rating: 5, time: "15 mins ago", type: "rating", icon: <Star className="w-4 h-4" /> },
    { id: 3, user: "Mike Johnson", action: "subscribed", content: "Premium Plan", time: "1 hour ago", type: "subscription", icon: <Subscriptions className="w-4 h-4" /> },
    { id: 4, user: "Sarah Wilson", action: "commented", content: "Squid Game", time: "3 hours ago", type: "comment", icon: <Comment className="w-4 h-4" /> },
    { id: 5, user: "Emma Brown", action: "shared", content: "The Crown", time: "5 hours ago", type: "share", icon: <Share className="w-4 h-4" /> },
  ];

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: COLORS.background }}>
      {/* Header Section */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-3 flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-1" style={{ color: COLORS.primary }}>
              {greeting}, Admin 👋
            </h1>
            <p className="text-sm" style={{ color: COLORS.textSecondary }}>
              Here's what's happening with your content today
            </p>
          </div>
          <span
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm border"
            style={{
              backgroundColor: COLORS.cardLight,
              color: COLORS.textSecondary,
              borderColor: COLORS.borderLight
            }}
          >
            <AccessTime className="w-4 h-4" style={{ color: COLORS.primary }} />
            Last 30 days
          </span>
        </div>
      </div>

 

      {/* new points  */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 mb-8">
        <QuickStatMini
          label="Total Users"
          value={stats.totalUsers}
          sub="+1,240 this month"
          color={COLORS.primary}
          icon={<People className="w-5 h-5" />}
          trend="up"
          trendValue="14.2"
        />

        <QuickStatMini
          label="Active Subscriptions"
          value={stats.activeSubscriptions}
          sub="+320 new plans"
          color={COLORS.success}
          icon={<WorkspacePremium className="w-5 h-5" />}
          trend="up"
          trendValue="9.8"
        />

        <QuickStatMini
          label="Revenue Analytics"
          value={stats.revenueAnalytics}
          sub="+22% growth"
          color={COLORS.warning}
          icon={<AttachMoney className="w-5 h-5" />}
          trend="up"
          trendValue="22"
        />

        <QuickStatMini
          label="Watch Time Stats"
          value={stats.watchTimeStatistics}
          sub="+180 hrs this week"
          color={COLORS.info}
          icon={<AccessTime className="w-5 h-5" />}
          trend="up"
          trendValue="11.4"
        />


      </div>





      {/* Main Stats Cards */}
<div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 items-start">
          {/* Watch Time Analytics Card */}
       <div
          className="rounded-2xl overflow-hidden relative group transition-all duration-300 hover:scale-[1.01] hover:shadow-[0_10px_40px_rgba(245,199,122,0.18)]"
          style={{
            backgroundColor: COLORS.cardBg,
            border: `1px solid ${COLORS.border}`,
          }}
        >
          {/* Background Image */}
          <div className="relative h-[240px] overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1524985069026-dd778a71c7b4?w=1200"
              alt="Most Viewed"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
            />

            {/* Overlay */}
            <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-transparent" />

            {/* Top Badge */}
            <div className="absolute top-4 left-4 flex items-center gap-2 px-3 py-1 rounded-full bg-[#f5c77a] text-black text-xs font-bold shadow-lg">
              <LocalFireDepartment className="w-4 h-4" />
              #1 TRENDING
            </div>

            {/* Views */}
            <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-black/60 backdrop-blur-md text-white text-xs flex items-center gap-1 border border-white/10">
              <Visibility className="w-4 h-4" />
              2.4M Views
            </div>

            {/* Bottom Content */}
            <div className="absolute bottom-0 left-0 w-full p-5">
              <div className="flex items-center gap-2 mb-2">
                <span className="px-2 py-0.5 rounded bg-red-600 text-white text-[10px] font-bold">
                  NEW EPISODE
                </span>

                <span className="px-2 py-0.5 rounded bg-white/10 backdrop-blur text-white text-[10px]">
                  SCI-FI
                </span>
              </div>

              <h2 className="text-2xl font-bold text-white mb-1">
                Stranger Things Season 5
              </h2>

              <p className="text-sm text-gray-300 mb-4 line-clamp-2">
                The most watched series this week with explosive engagement and record-breaking streaming hours.
              </p>

              {/* Stats */}
              <div className="flex items-center gap-6 flex-wrap">
                <div className="flex items-center gap-1 text-sm text-white">
                  <Star className="w-4 h-4 text-yellow-400" />
                  4.9 Rating
                </div>

                <div className="flex items-center gap-1 text-sm text-white">
                  <AccessTime className="w-4 h-4" />
                  48m Avg Watch
                </div>

                <div className="flex items-center gap-1 text-sm text-green-400 font-semibold">
                  <TrendingUp className="w-4 h-4" />
                  +45% Growth
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Server health status  Card */}
<div
  className="rounded-2xl p-5 relative overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_40px_rgba(33,150,243,0.18)]"
  style={{
    backgroundColor: COLORS.cardBg,
    border: "1px solid rgba(33,150,243,0.18)",
  }}
>
  {/* Background Glow */}
  <div className="absolute -top-10 -right-10 w-40 h-40 bg-blue-500/10 blur-3xl rounded-full" />

  {/* Header */}
  <div className="flex items-center justify-between mb-5 relative z-10">
    <div>
      <h3
        className="text-lg font-semibold flex items-center gap-2"
        style={{ color: COLORS.text }}
      >
        <Dns className="text-blue-400" />
        Server Health Status
      </h3>

      <p
        className="text-xs mt-1"
        style={{ color: COLORS.textSecondary }}
      >
        Live infrastructure & uptime monitoring
      </p>
    </div>

    {/* Live Badge */}
    <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20">
      <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
      <span className="text-xs font-medium text-green-400">
        HEALTHY
      </span>
    </div>
  </div>

  {/* Server Stats */}
  <div className="grid grid-cols-3 gap-3 mb-5 relative z-10">
    <div className="rounded-xl p-3 bg-[#231D1D] border border-white/5">
      <p className="text-xs text-gray-400 mb-1">CPU Usage</p>
      <h2 className="text-xl font-bold text-blue-400">
        42%
      </h2>

      {/* Progress */}
      <div className="w-full h-1.5 bg-white/5 rounded-full mt-2 overflow-hidden">
        <div
          className="h-full bg-blue-400 rounded-full"
          style={{ width: "42%" }}
        />
      </div>
    </div>

    <div className="rounded-xl p-3 bg-[#231D1D] border border-white/5">
      <p className="text-xs text-gray-400 mb-1">Memory</p>
      <h2 className="text-xl font-bold text-cyan-400">
        68%
      </h2>

      <div className="w-full h-1.5 bg-white/5 rounded-full mt-2 overflow-hidden">
        <div
          className="h-full bg-cyan-400 rounded-full"
          style={{ width: "68%" }}
        />
      </div>
    </div>

    <div className="rounded-xl p-3 bg-[#231D1D] border border-white/5">
      <p className="text-xs text-gray-400 mb-1">Disk Space</p>
      <h2 className="text-xl font-bold text-green-400">
        81%
      </h2>

      <div className="w-full h-1.5 bg-white/5 rounded-full mt-2 overflow-hidden">
        <div
          className="h-full bg-green-400 rounded-full"
          style={{ width: "81%" }}
        />
      </div>
    </div>
  </div>

 

  {/* Footer */}
  <div className="flex items-center justify-between relative z-10">
    <div>
      <p className="text-xs text-gray-400">
        Uptime
      </p>

      <h3 className="text-lg font-bold text-white">
        99.98%
      </h3>
    </div>

  </div>
</div>
      </div>



      {/* Failed Payments Monitoring Card */}
      <div
        className="rounded-2xl p-5 relative overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_10px_40px_rgba(244,67,54,0.18)]"
        style={{
          backgroundColor: COLORS.cardBg,
          border: "1px solid rgba(244,67,54,0.18)",
        }}
      >
        {/* Background Glow */}
        <div className="absolute -top-10 -right-10 w-40 h-40 bg-red-500/10 blur-3xl rounded-full" />

        {/* Header */}
        <div className="flex items-center justify-between mb-5 relative z-10">
          <div>
            <h3
              className="text-lg font-semibold flex items-center gap-2"
              style={{ color: COLORS.text }}
            >
              <WarningAmber className="text-red-400" />
              Failed Payments Monitoring
            </h3>

            <p
              className="text-xs mt-1"
              style={{ color: COLORS.textSecondary }}
            >
              Real-time payment failure tracking
            </p>
          </div>

          {/* Live Badge */}
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/20">
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-xs font-medium text-red-400">
              LIVE
            </span>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-3 mb-5 relative z-10">
          <div className="rounded-xl p-3 bg-[#231D1D] border border-white/5">
            <p className="text-xs text-gray-400 mb-1">Failed Txns</p>
            <h2 className="text-xl font-bold text-red-400">128</h2>
            <span className="text-[11px] text-red-300">
              +12% today
            </span>
          </div>

          <div className="rounded-xl p-3 bg-[#231D1D] border border-white/5">
            <p className="text-xs text-gray-400 mb-1">Revenue Risk</p>
            <h2 className="text-xl font-bold text-orange-400">
              $12.4K
            </h2>
            <span className="text-[11px] text-orange-300">
              Pending recovery
            </span>
          </div>

          <div className="rounded-xl p-3 bg-[#231D1D] border border-white/5">
            <p className="text-xs text-gray-400 mb-1">Retry Success</p>
            <h2 className="text-xl font-bold text-green-400">
              68%
            </h2>
            <span className="text-[11px] text-green-300">
              Auto recovered
            </span>
          </div>
        </div>

        {/* Mini Graph */}
        <div className="mb-5 relative z-10">
          <div className="flex items-end gap-1 h-16">
            {[25, 40, 18, 60, 45, 80, 52, 70, 30].map((v, i) => (
              <div
                key={i}
                className="flex-1 rounded-t-md bg-gradient-to-t from-red-500 to-orange-400 opacity-90 hover:opacity-100 transition-all"
                style={{ height: `${v}%` }}
              />
            ))}
          </div>

          <div className="flex justify-between mt-2 text-[10px] text-gray-500">
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
            <span>Sun</span>
          </div>
        </div>

        {/* Recent Failures */}
        <div className="space-y-3 relative z-10">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white font-medium">
                John Doe
              </p>
              <p className="text-xs text-gray-400">
                Card Declined
              </p>
            </div>

            <span className="text-xs text-red-400 font-medium">
              $120
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white font-medium">
                Emma Watson
              </p>
              <p className="text-xs text-gray-400">
                Gateway Timeout
              </p>
            </div>

            <span className="text-xs text-orange-400 font-medium">
              $85
            </span>
          </div>

          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-white font-medium">
                Alex Morgan
              </p>
              <p className="text-xs text-gray-400">
                Insufficient Balance
              </p>
            </div>

            <span className="text-xs text-yellow-400 font-medium">
              $42
            </span>
          </div>
        </div>

        {/* Footer Button */}
        <button
          className="mt-5 w-full py-2 rounded-xl text-sm font-medium transition-all duration-300 hover:scale-[1.02]"
          style={{
            background:
              "linear-gradient(135deg, rgba(244,67,54,0.18), rgba(255,152,0,0.15))",
            border: "1px solid rgba(244,67,54,0.25)",
            color: "#fff",
          }}
        >
          View Detailed Report →
        </button>
      </div>

      {/* Bottom Spacing */}
      <div className="h-8" />
    </div>
  );
}