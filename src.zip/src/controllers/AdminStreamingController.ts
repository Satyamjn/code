import { and, desc, eq, ilike, ne, or, sql } from "drizzle-orm";
import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler.js";
import { HTTP_STATUS } from "../constants/constant.js";
import ApiResponse from "../utils/ApiResponse.js";
import ApiError from "../utils/ApiError.js";
import { deleteFromS3 } from "../utils/s3Delete.js";
import {
  db,
  Users,
  genres,
  languages,
  profiles,
  uploads,
  uploadAssets,
  videos,
  videoAssets,
} from "@digiiplex6112/db";
import { generateTokenPair, verifyRefreshToken } from "../utils/jwt.js";
import { sendEmail } from "../config/sendEmail.js";
import {
  clearAuthCookies,
  REFRESH_TOKEN_COOKIE,
  setAuthCookies,
} from "../utils/authCookies.js";




