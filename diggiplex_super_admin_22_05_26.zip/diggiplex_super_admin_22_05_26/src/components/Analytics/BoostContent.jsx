import React, { useState } from "react";
import { Paper, Typography, Box, Button, Slider, TextField, Grid, Alert, Chip } from "@mui/material";
import { TrendingUp, Campaign } from "@mui/icons-material";
import { COLORS } from "../../theme/theme";

const BoostContent = () => {
  const [budget, setBudget] = useState(100);
  const [duration, setDuration] = useState(7);
  const [boosted, setBoosted] = useState(false);
  const [selectedContent, setSelectedContent] = useState("");

  const contents = [
    { id: 1, title: "React Tutorial", views: "12.5K" },
    { id: 2, title: "MUI Crash Course", views: "8.2K" },
    { id: 3, title: "JavaScript Tips", views: "15.3K" },
  ];

  const handleBoost = () => {
    setBoosted(true);
    setTimeout(() => setBoosted(false), 5000);
  };

  const estimatedReach = Math.floor(budget * 50);
  const estimatedViews = Math.floor(budget * 25);

  return (
    <Paper sx={{ background: COLORS.background, p: 3 }}>
      <Typography variant="h6" sx={{ color: COLORS.primary, mb: 2 }}>🚀 Boost Your Content</Typography>
      
      {boosted && (
        <Alert severity="success" sx={{ mb: 2, backgroundColor: `${COLORS.success}10`, color: COLORS.success }}>
          Content boosted successfully! Your content will reach approximately {estimatedReach.toLocaleString()} users.
        </Alert>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12}>
          <Typography sx={{ color: COLORS.textMuted, mb: 1 }}>Select Content to Boost</Typography>
          <Box sx={{ display: "flex", gap: 1, flexWrap: "wrap" }}>
            {contents.map((content) => (
              <Chip
                key={content.id}
                label={`${content.title} (${content.views} views)`}
                onClick={() => setSelectedContent(content.title)}
                color={selectedContent === content.title ? "primary" : "default"}
                sx={{
                  backgroundColor: selectedContent === content.title ? COLORS.primary : `${COLORS.primary}10`,
                  color: selectedContent === content.title ? COLORS.background : COLORS.primary,
                  border: `1px solid ${COLORS.primary}`,
                  "&:hover": { backgroundColor: COLORS.primary, color: COLORS.background }
                }}
              />
            ))}
          </Box>
        </Grid>
        
        <Grid item xs={12}>
          <Typography sx={{ color: COLORS.textMuted, mb: 1 }}>Budget: ${budget}</Typography>
          <Slider
            value={budget}
            onChange={(e, v) => setBudget(v)}
            min={50}
            max={1000}
            step={50}
            valueLabelDisplay="auto"
            sx={{ color: COLORS.primary }}
          />
        </Grid>
        
        <Grid item xs={12}>
          <Typography sx={{ color: COLORS.textMuted, mb: 1 }}>Duration: {duration} days</Typography>
          <Slider
            value={duration}
            onChange={(e, v) => setDuration(v)}
            min={1}
            max={30}
            valueLabelDisplay="auto"
            sx={{ color: COLORS.primary }}
          />
        </Grid>
        
        <Grid item xs={12}>
          <Box sx={{ p: 2, backgroundColor: `${COLORS.primary}10`, borderRadius: "12px", mb: 2 }}>
            <Typography variant="body2" sx={{ color: COLORS.textMuted }}>Estimated Reach:</Typography>
            <Typography variant="h6" sx={{ color: COLORS.primary }}>{estimatedReach.toLocaleString()} users</Typography>
            <Typography variant="body2" sx={{ color: COLORS.textMuted, mt: 1 }}>Estimated Views:</Typography>
            <Typography variant="h6" sx={{ color: COLORS.primary }}>{estimatedViews.toLocaleString()} views</Typography>
          </Box>
        </Grid>
        
        <Grid item xs={12}>
          <Button
            fullWidth
            variant="contained"
            startIcon={<Campaign />}
            onClick={handleBoost}
            disabled={!selectedContent}
            sx={{
              backgroundColor: COLORS.primary,
              color: COLORS.background,
              py: 1.5,
              "&:hover": { backgroundColor: "#ffda96" },
              "&.Mui-disabled": { backgroundColor: `${COLORS.primary}50` }
            }}
          >
            Boost Content (${budget}) - {duration} Days
          </Button>
        </Grid>
      </Grid>
    </Paper>
  );
};

export default BoostContent;