import React from 'react'

const ThumbnailsEdit = () => {
  return (
    <div>
      ThumbnailsEdit
    </div>
  )
}

export default ThumbnailsEdit
