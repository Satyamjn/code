// src/pages/ContentLibrary/ContentLibraryPage.jsx
import React, { useState, useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Search,
  FilterList,
  Add,
  CloudUpload,
  Download,
  Delete,
  Edit,
  Visibility,
  MoreVert,
  CheckCircle,
  Cancel,
  AccessTime,
  Warning,
  Refresh,
  GridView,
  ViewList,
  TrendingUp,
  Star,
  People,
  Event,
  VideoLibrary,
  Folder,
  Image,
  Close
} from "@mui/icons-material";
import ContentLibrary from "../components/ContentLibrary/ContentLibrary";
import Mylibrary from "../components/ContentLibrary/Mylibrary";
import ThumbnailsEdit from "../components/ContentLibrary/ThumbnailsEdit";

// Color scheme
const COLORS = {
  primary: "#f5c77a",
  primaryDark: "#c49a4e",
  background: "rgba(15, 10, 10, 0.85)",
  cardBg: "#1C1616",
  cardLight: "#231D1D",
  text: "#FFFFFF",
  textSecondary: "#B3B3B3",
  textMuted: "#6B6B6B",
  success: "#4caf7d",
  error: "#f44336",
  warning: "#ff9800",
  info: "#2196f3",
  border: "rgba(245,199,122,0.125)",
  borderLight: "rgba(255,255,255,0.07)",
};

// Custom Tab Component
const TabButton = ({ label, isActive, onClick, icon }) => {
  return (
    <button
      onClick={onClick}
      className={`px-6 py-3 text-sm font-medium transition-all duration-300 relative ${
        isActive 
          ? "text-[#f5c77a]" 
          : "text-[#6B6B6B] hover:text-[#B3B3B3]"
      }`}
    >
      <span className="flex items-center gap-2">
        <span className="text-lg">{icon}</span>
        {label}
      </span>
      {isActive && (
        <motion.div
          layoutId="activeTab"
          className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#f5c77a]"
          transition={{ type: "spring", stiffness: 500, damping: 30 }}
        />
      )}
    </button>
  );
};

// Stats Card Component
const StatsCard = ({ title, value, change, icon, color }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-[#1C1616] rounded-xl border border-[rgba(245,199,122,0.125)] p-5 hover:border-[#f5c77a] transition-all duration-300"
    >
      <div className="flex justify-between items-start mb-3">
        <div className="p-2 rounded-lg" style={{ backgroundColor: `${color}15` }}>
          {icon}
        </div>
        <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
          change >= 0 ? "bg-green-500/15 text-green-500" : "bg-red-500/15 text-red-500"
        }`}>
          {change >= 0 ? "+" : ""}{change}%
        </span>
      </div>
      <h3 className="text-2xl font-bold text-white mb-1">{value}</h3>
      <p className="text-xs text-[#B3B3B3]">{title}</p>
    </motion.div>
  );
};

// Quick Action Button
const QuickAction = ({ icon, label, onClick, color = COLORS.primary }) => {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-2 p-3 rounded-xl transition-all duration-300 hover:scale-105 group"
      style={{ backgroundColor: `${color}10` }}
    >
      <div className="p-2 rounded-lg transition-all duration-300 group-hover:scale-110" style={{ color }}>
        {icon}
      </div>
      <span className="text-xs font-medium" style={{ color: COLORS.textSecondary }}>{label}</span>
    </button>
  );
};

// Notification Component
const Notification = ({ message, type, onClose }) => {
  const icons = {
    success: <CheckCircle className="w-4 h-4" style={{ fontSize: 16 }} />,
    error: <Cancel className="w-4 h-4" style={{ fontSize: 16 }} />,
    warning: <Warning className="w-4 h-4" style={{ fontSize: 16 }} />,
    info: <AccessTime className="w-4 h-4" style={{ fontSize: 16 }} />
  };
  
  const colors = {
    success: "text-green-500 bg-green-500/10 border-green-500/20",
    error: "text-red-500 bg-red-500/10 border-red-500/20",
    warning: "text-yellow-500 bg-yellow-500/10 border-yellow-500/20",
    info: "text-blue-500 bg-blue-500/10 border-blue-500/20"
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 100 }}
      className={`fixed top-4 right-4 z-50 flex items-center gap-3 px-4 py-3 rounded-lg border ${colors[type]} backdrop-blur-sm`}
      style={{ backgroundColor: "rgba(28, 22, 22, 0.95)" }}
    >
      {icons[type]}
      <span className="text-sm">{message}</span>
      <button onClick={onClose} className="ml-2 hover:opacity-70">
        <Close className="w-4 h-4" style={{ fontSize: 16 }} />
      </button>
    </motion.div>
  );
};

const ContentLibraryPage = () => {
  const [tabValue, setTabValue] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");
  const [viewMode, setViewMode] = useState("grid");
  const [isLoading, setIsLoading] = useState(false);
  const [notifications, setNotifications] = useState([]);
  const [stats, setStats] = useState({
    totalContent: 0,
    totalViews: 0,
    avgRating: 0,
    totalUsers: 0
  });
  const [recentUploads, setRecentUploads] = useState([]);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Mock data - replace with real API calls
  const fetchDashboardStats = useCallback(async () => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 800));
      setStats({
        totalContent: 1256,
        totalViews: "2.4M",
        avgRating: 4.6,
        totalUsers: 12345
      });
      setRecentUploads([
        { id: 1, title: "Stranger Things S4", time: "2 mins ago", status: "published", type: "video" },
        { id: 2, title: "The Crown S5", time: "15 mins ago", status: "processing", type: "video" },
        { id: 3, title: "Squid Game S2", time: "1 hour ago", status: "published", type: "video" }
      ]);
    } catch (error) {
      addNotification("Failed to load stats", "error");
    } finally {
      setIsLoading(false);
    }
  }, []);

  const addNotification = (message, type = "info") => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 5000);
  };

  const handleRefresh = async () => {
    setIsRefreshing(true);
    await fetchDashboardStats();
    setIsRefreshing(false);
    addNotification("Dashboard refreshed successfully", "success");
  };

  const handleUpload = () => {
    addNotification("Upload feature coming soon", "info");
  };

  const handleExport = () => {
    addNotification("Exporting data...", "info");
    setTimeout(() => {
      addNotification("Export completed successfully", "success");
    }, 2000);
  };

  useEffect(() => {
    fetchDashboardStats();
    
    // Simulate real-time updates
    const interval = setInterval(() => {
      // You can add real-time WebSocket updates here
      console.log("Checking for updates...");
    }, 30000);
    
    return () => clearInterval(interval);
  }, [fetchDashboardStats]);

  const tabs = [
    { label: "All Content", icon: "📚", component: ContentLibrary },
    { label: "My Library", icon: "📁", component: Mylibrary },
    { label: "Edit Thumbnails", icon: "🎨", component: ThumbnailsEdit }
  ];

  const CurrentComponent = tabs[tabValue].component;

  // Function to get icon based on content type
  const getContentIcon = (type) => {
    switch(type) {
      case "video":
        return <VideoLibrary className="w-5 h-5" style={{ color: COLORS.primary, fontSize: 20 }} />;
      case "folder":
        return <Folder className="w-5 h-5" style={{ color: COLORS.primary, fontSize: 20 }} />;
      case "image":
        return <Image className="w-5 h-5" style={{ color: COLORS.primary, fontSize: 20 }} />;
      default:
        return <VideoLibrary className="w-5 h-5" style={{ color: COLORS.primary, fontSize: 20 }} />;
    }
  };

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: COLORS.background }}>
      {/* Notifications */}
      <AnimatePresence>
        {notifications.map(notification => (
          <Notification
            key={notification.id}
            message={notification.message}
            type={notification.type}
            onClose={() => setNotifications(prev => prev.filter(n => n.id !== notification.id))}
          />
        ))}
      </AnimatePresence>

      {/* Header Section */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4 flex-wrap gap-4">
          <div>
            <h1 className="text-3xl font-bold mb-1" style={{ color: COLORS.primary }}>
              Content Library
            </h1>
            <p className="text-sm" style={{ color: COLORS.textSecondary }}>
              Manage and organize your content library
            </p>
          </div>
          
          <div className="flex gap-3">
            <button
              onClick={handleRefresh}
              className="p-2 rounded-lg transition-all duration-300 hover:scale-105"
              style={{ backgroundColor: `${COLORS.primary}15`, color: COLORS.primary }}
              disabled={isRefreshing}
            >
              <Refresh className={`w-5 h-5 ${isRefreshing ? "animate-spin" : ""}`} style={{ fontSize: 20 }} />
            </button>
            <button
              onClick={handleUpload}
              className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all duration-300 hover:scale-105"
              style={{ backgroundColor: COLORS.primary, color: COLORS.background }}
            >
              <Add className="w-4 h-4" style={{ fontSize: 16 }} />
              Upload Content
            </button>
            <button
              onClick={handleExport}
              className="flex items-center gap-2 px-4 py-2 rounded-lg transition-all duration-300 hover:scale-105"
              style={{ backgroundColor: `${COLORS.primary}15`, color: COLORS.primary }}
            >
              <Download className="w-4 h-4" style={{ fontSize: 16 }} />
              Export
            </button>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatsCard
          title="Total Content"
          value={stats.totalContent}
          change={12.5}
          icon={<VideoLibrary className="w-5 h-5" style={{ color: COLORS.primary, fontSize: 20 }} />}
          color={COLORS.primary}
        />
        <StatsCard
          title="Total Views"
          value={stats.totalViews}
          change={18.3}
          icon={<Visibility className="w-5 h-5" style={{ color: COLORS.success, fontSize: 20 }} />}
          color={COLORS.success}
        />
        <StatsCard
          title="Avg Rating"
          value={stats.avgRating}
          change={5.2}
          icon={<Star className="w-5 h-5" style={{ color: COLORS.warning, fontSize: 20 }} />}
          color={COLORS.warning}
        />
        <StatsCard
          title="Active Users"
          value={stats.totalUsers}
          change={8.7}
          icon={<People className="w-5 h-5" style={{ color: COLORS.info, fontSize: 20 }} />}
          color={COLORS.info}
        />
      </div>

      {/* Quick Actions */}
      <div className="mb-6">
        <div className="flex gap-3 flex-wrap">
          <QuickAction
            icon={<CloudUpload className="w-5 h-5" style={{ fontSize: 20 }} />}
            label="Quick Upload"
            onClick={handleUpload}
          />
          <QuickAction
            icon={<FilterList className="w-5 h-5" style={{ fontSize: 20 }} />}
            label="Advanced Filter"
            onClick={() => addNotification("Filter feature coming soon", "info")}
          />
          <QuickAction
            icon={<TrendingUp className="w-5 h-5" style={{ fontSize: 20 }} />}
            label="Analytics"
            onClick={() => addNotification("Analytics dashboard coming soon", "info")}
          />
          <QuickAction
            icon={<Event className="w-5 h-5" style={{ fontSize: 20 }} />}
            label="Schedule"
            onClick={() => addNotification("Scheduling feature coming soon", "info")}
          />
        </div>
      </div>

      {/* Search and View Controls */}
      <div className="mb-6">
        <div className="flex justify-between items-center gap-4 flex-wrap">
          <div className="flex-1 max-w-md relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4" style={{ color: COLORS.textMuted, fontSize: 16 }} />
            <input
              type="text"
              placeholder="Search content..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2 rounded-lg border outline-none transition-all duration-300 focus:border-[#f5c77a]"
              style={{
                backgroundColor: COLORS.cardBg,
                borderColor: COLORS.border,
                color: COLORS.text
              }}
            />
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={() => setViewMode("grid")}
              className={`p-2 rounded-lg transition-all duration-300 ${
                viewMode === "grid" ? "bg-[#f5c77a] text-[#1C1616]" : "text-[#B3B3B3] hover:text-white"
              }`}
              style={{ backgroundColor: viewMode === "grid" ? COLORS.primary : "transparent" }}
            >
              <GridView className="w-4 h-4" style={{ fontSize: 16 }} />
            </button>
            <button
              onClick={() => setViewMode("list")}
              className={`p-2 rounded-lg transition-all duration-300 ${
                viewMode === "list" ? "bg-[#f5c77a] text-[#1C1616]" : "text-[#B3B3B3] hover:text-white"
              }`}
              style={{ backgroundColor: viewMode === "list" ? COLORS.primary : "transparent" }}
            >
              <ViewList className="w-4 h-4" style={{ fontSize: 16 }} />
            </button>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      <div 
        className="rounded-2xl overflow-hidden"
        style={{ 
          backgroundColor: COLORS.cardBg,
          border: `1px solid ${COLORS.border}` 
        }}
      >
        {/* Tabs */}
        <div className="border-b" style={{ borderColor: COLORS.border }}>
          <div className="flex gap-1 px-2">
            {tabs.map((tab, index) => (
              <TabButton
                key={index}
                label={tab.label}
                icon={tab.icon}
                isActive={tabValue === index}
                onClick={() => setTabValue(index)}
              />
            ))}
          </div>
        </div>

        {/* Tab Content */}
        <div className="p-6">
          <AnimatePresence mode="wait">
            <motion.div
              key={tabValue}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2 }}
            >
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-2 border-[#f5c77a] border-t-transparent" />
                </div>
              ) : (
                <CurrentComponent 
                  searchQuery={searchQuery}
                  viewMode={viewMode}
                  onNotification={addNotification}
                />
              )}
            </motion.div>
          </AnimatePresence>
        </div>
      </div>

      {/* Recent Uploads Section */}
      <div className="mt-6">
        <h3 className="text-sm font-semibold mb-3" style={{ color: COLORS.primary }}>
          Recent Uploads
        </h3>
        <div className="space-y-2">
          {recentUploads.map(upload => (
            <div
              key={upload.id}
              className="flex items-center justify-between p-3 rounded-lg transition-all duration-300 hover:bg-[rgba(245,199,122,0.05)]"
              style={{ backgroundColor: `${COLORS.cardLight}` }}
            >
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-lg bg-[#231D1D] flex items-center justify-center">
                  {getContentIcon(upload.type)}
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{upload.title}</p>
                  <p className="text-xs" style={{ color: COLORS.textMuted }}>{upload.time}</p>
                </div>
              </div>
              <span 
                className={`text-xs px-2 py-1 rounded-full ${
                  upload.status === "published" 
                    ? "bg-green-500/15 text-green-500" 
                    : "bg-yellow-500/15 text-yellow-500"
                }`}
              >
                {upload.status}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ContentLibraryPage;