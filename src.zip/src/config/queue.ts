import "dotenv/config";
import { Queue } from "bullmq";
import { Redis } from "ioredis";

const redisUrl =
  process.env.REDIS_QUEUE_URL ||
  process.env.REDIS_WRITE_URL ||
  process.env.REDIS_URL;
const redisHost = process.env.REDIS_HOST || "127.0.0.1";
const redisPort = Number(process.env.REDIS_PORT || 6379);
const redisPassword = process.env.REDIS_PASSWORD;

export const connection = redisUrl
  ? new Redis(redisUrl, {
      maxRetriesPerRequest: null,
    })
  : new Redis({
      host: redisHost,
      port: redisPort,
      ...(redisPassword ? { password: redisPassword } : {}),
      maxRetriesPerRequest: null,
    });

connection.on("ready", async () => {
  try {
    const roleResult = await connection.call("ROLE");
    const role = Array.isArray(roleResult) ? String(roleResult[0]) : "unknown";

    if (role !== "master") {
      console.warn(
        `[queue] Redis connection is using a non-writable role: ${role}. ` +
          "BullMQ writes will fail unless REDIS_QUEUE_URL/REDIS_WRITE_URL points to the primary node.",
      );
      return;
    }

    console.info("[queue] Redis connection is writable.");
  } catch (error) {
    console.warn("[queue] Unable to determine Redis ROLE during startup.", error);
  }
});

export const videoQueue = new Queue("video-processing", {
  connection,
});

export const publishQueue = new Queue("publish-queue", { connection });
