import { Box } from "@mui/material";
import { Routes, Route, useLocation } from "react-router-dom";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Sidebar from "./components/Sidebar/Sidebar";
import Header from "./components/Header/Header";

import DashboardPage from "./pages/DashboardPage";
import CreatorStudioPage from "./pages/CreatorStudioPage";
import ContentLibraryPage from "./pages/ContentLibraryPage";
import AnalyticsPage from "./pages/AnalyticsPage";
import RevenuePage from "./pages/RevenuePage";

import { useState } from "react";
import ContentType from "./pages/ContentType";
import Login from "./pages/Login";
import Creator from "./pages/Creator";
import CreateGenre from "./pages/CreateGenre";
import CreateLanguage from "./pages/CreateLanguage";
import CreateAdmin from "./pages/CreateAdmin";
import User from "./pages/User";
import UploadList from "./pages/UploadList";
import UploadDetails from "./pages/UploadDetails";
import UploadPendingList from "./pages/UploadPendingList";
import UploadApproveList from "./pages/UploadApproveList";
import UploadPublishList from "./pages/UploadPublishList";
import ProtectedRoute from "./ProtectedRoute";
import UserDetails from "./pages/UserDetails";

const DRAWER_WIDTH = 260;

export default function App() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();

  const isLoginPage = location.pathname === "/";

  return (
    <Box sx={{ display: "flex", minHeight: "100vh", bgcolor: "#0F0A0A", overflow: "hidden" }}>
      <ToastContainer position="top-right" autoClose={2000} />

      {!isLoginPage && (
        <Sidebar
          drawerWidth={DRAWER_WIDTH}
          mobileOpen={mobileOpen}
          setMobileOpen={setMobileOpen}
        />
      )}

      <Box
        component="main"
        sx={{
          flexGrow: 1,
          display: "flex",
          flexDirection: "column",
          minHeight: "100vh",
          width: isLoginPage ? "100%" : `calc(100% - ${DRAWER_WIDTH}px)`,
          maxWidth: isLoginPage ? "100%" : `calc(100% - ${DRAWER_WIDTH}px)`,
          overflow: "hidden", 
          ...(isLoginPage && {
            ml: 0,
          }),
        }}
      >
        {!isLoginPage && <Header setMobileOpen={setMobileOpen} />}

        <Box
          sx={{
            flexGrow: 1,
            p: { xs: 2, md: 3 },
            mt: isLoginPage ? 0 : "72px",
            overflowX: "hidden",  
            overflowY: "auto",    
            width: "100%",
            boxSizing: "border-box",
          }}
        >
          <Routes>
            <Route path="/" element={<Login />} />

            <Route path="/dashboard" element={  <ProtectedRoute><DashboardPage /></ProtectedRoute>} />
            <Route path="/contentType" element={<ProtectedRoute><ContentType /></ProtectedRoute>} />
            <Route path="/studio" element={<ProtectedRoute><CreatorStudioPage /></ProtectedRoute>} />
            <Route path="/studio/upload" element={<ProtectedRoute><CreatorStudioPage /></ProtectedRoute>} />
            <Route path="/studio/live" element={<ProtectedRoute><CreatorStudioPage /></ProtectedRoute>} />
            <Route path="/studio/podcast" element={<ProtectedRoute><CreatorStudioPage /></ProtectedRoute>} />
            <Route path="/studio/shorts" element={<ProtectedRoute><CreatorStudioPage /></ProtectedRoute>} />

            <Route path="/library" element={<ProtectedRoute><ContentLibraryPage /></ProtectedRoute>} />
            <Route path="/analytics" element={<ProtectedRoute><AnalyticsPage /></ProtectedRoute>} />
            <Route path="/revenue" element={<ProtectedRoute><RevenuePage /></ProtectedRoute>} />
            <Route path="/creator" element={<ProtectedRoute><Creator /></ProtectedRoute>} />
            <Route path="/createAdmin" element={<ProtectedRoute><CreateAdmin /></ProtectedRoute>} />
            <Route path="/user" element={<ProtectedRoute><User /></ProtectedRoute>} />
            <Route path="/createGenre" element={<ProtectedRoute><CreateGenre /></ProtectedRoute>} />
            <Route path="/createLanguage" element={<ProtectedRoute><CreateLanguage /></ProtectedRoute>} />
            <Route path="/uploadlist" element={<ProtectedRoute><UploadList /></ProtectedRoute>} />
            <Route path="/uploadpendinglist" element={<ProtectedRoute><UploadPendingList /></ProtectedRoute>} />
            <Route path="/uploadapprovelist" element={<ProtectedRoute><UploadApproveList /></ProtectedRoute>} />
            <Route path="/uploadpublishlist" element={<ProtectedRoute><UploadPublishList /></ProtectedRoute>} />
            <Route path="/upload_details/:id" element={<ProtectedRoute><UploadDetails /></ProtectedRoute>} />

            <Route path="/user_details/:id" element={<ProtectedRoute><UserDetails /></ProtectedRoute>} />

          </Routes>
        </Box>
      </Box>
    </Box>
  );
}




