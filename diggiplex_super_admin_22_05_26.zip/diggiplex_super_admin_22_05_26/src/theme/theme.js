import { createTheme } from "@mui/material/styles";

export const COLORS = {
  bg: "#0F0A0A",
  surface: "#1C1616",
  surfaceElevated: "#231D1D",
  accent: "#f5c77a",
  accentDark: "#c49a4e",
  accentGlow: "rgba(245, 199, 122, 0.15)",
  text: "#FFFFFF",
  textSecondary: "#B3B3B3",
  textMuted: "#6B6B6B",
  success: "#4CAF7D",
  warning: "#FF9800",
  error: "#F44336",
  border: "rgba(255,255,255,0.07)",
  cardShadow: "0 8px 32px rgba(0,0,0,0.5)",
};

export const theme = createTheme({
  palette: {
    mode: "dark",
    primary: { main: COLORS.accent, dark: COLORS.accentDark },
    background: { default: COLORS.bg, paper: COLORS.surface },
    text: { primary: COLORS.text, secondary: COLORS.textSecondary },
    success: { main: COLORS.success },
    warning: { main: COLORS.warning },
    error: { main: COLORS.error },
  },
  typography: {
    fontFamily: '"Outfit", "DM Sans", sans-serif',
    h1: { fontWeight: 700, letterSpacing: "-0.02em" },
    h2: { fontWeight: 700, letterSpacing: "-0.01em" },
    h3: { fontWeight: 600 },
    h4: { fontWeight: 600 },
    h5: { fontWeight: 600 },
    h6: { fontWeight: 600 },
    body1: { fontSize: "0.95rem" },
    button: { textTransform: "none", fontWeight: 600, letterSpacing: "0.02em" },
  },
  shape: { borderRadius: "5px" },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundColor: COLORS.surface,
          backgroundImage: "none",
          border: `1px solid ${COLORS.border}`,
          boxShadow: COLORS.cardShadow,
          borderRadius: "5px",
          transition: "transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease",
          "&:hover": {
            transform: "translateY(-2px)",
            boxShadow: "0 16px 48px rgba(0,0,0,0.6)",
            borderColor: "rgba(245,199,122,0.2)",
          },
        },
      },
    },
    MuiButton: {
      styleOverrides: {
        root: { borderRadius: "5px", padding: "8px 20px", fontWeight: 600 },
        containedPrimary: {
          background: `linear-gradient(135deg, ${COLORS.accent} 0%, ${COLORS.accentDark} 100%)`,
          color: "#0F0A0A",
          boxShadow: `0 4px 20px rgba(245,199,122,0.3)`,
          "&:hover": {
            boxShadow: `0 6px 28px rgba(245,199,122,0.45)`,
            background: `linear-gradient(135deg, #ffd98e 0%, ${COLORS.accent} 100%)`,
          },
        },
      },
    },
    MuiTextField: {
      styleOverrides: {
        root: {
          "& .MuiOutlinedInput-root": {
            backgroundColor: COLORS.surfaceElevated,
            borderRadius: "5px",
            "& fieldset": { borderColor: COLORS.border },
            "&:hover fieldset": { borderColor: "rgba(245,199,122,0.4)" },
            "&.Mui-focused fieldset": { borderColor: COLORS.accent },
          },
        },
      },
    },
    MuiSelect: {
      styleOverrides: {
        root: {
          backgroundColor: COLORS.surfaceElevated,
          borderRadius: "5px",
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: { borderRadius: "5px", fontWeight: 600, fontSize: "0.72rem" },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: {
          borderBottom: `1px solid ${COLORS.border}`,
          color: COLORS.text,
        },
        head: { color: COLORS.textSecondary, fontWeight: 600, fontSize: "0.78rem", textTransform: "uppercase", letterSpacing: "0.08em" },
      },
    },
    MuiLinearProgress: {
      styleOverrides: {
        root: { borderRadius: "5px", backgroundColor: "rgba(255,255,255,0.08)" },
        bar: { borderRadius: "5px" },
      },
    },
    MuiCssBaseline: {
      styleOverrides: `
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@300;400;500;600;700;800&display=swap');
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #0F0A0A; }
        ::-webkit-scrollbar-thumb { background: #2a2222; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #3a3030; }
        * { box-sizing: border-box; }
      `,
    },
  },
});
