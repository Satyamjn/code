import { Request, Response } from "express";

// import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import { and, desc, eq, inArray, sql } from "drizzle-orm";
import { HTTP_STATUS, S3_CREDENTIAL } from "../constants/constant.js";
import { videoQueue, publishQueue } from "../config/queue.js";
import ApiError from "../utils/ApiError.js";
import ApiResponse from "../utils/ApiResponse.js";
import { asyncHandler } from "../utils/asyncHandler.js";

import {
  db,
  uploads,
  uploadAssets,
  videos,
  genres,
  Users,
  languages,
} from "@digiiplex6112/db";

type UploadMeta = {
  duration?: number;
  rating?: number;
  releaseYear?: number;
  director?: string;
  ageRating?: string;
};

type AssetDTO = {
  id: string;
  type: string;
  role: string;
  url: string | null;
};

type EpisodeAssetStatus = typeof uploadAssets.$inferSelect & {
  jobId: string | null;
  state: string | null;
  progress: Record<string, unknown> | null;
  failedReason?: string;
};

// export const getUploadById = asyncHandler(
//   async (req: Request, res: Response) => {
//     const uploadId = req.params.id;
//     const user = (req as any).user;
//     const creatorId = user?.id;

//     if (!uploadId) {
//       throw new ApiError(HTTP_STATUS.BAD_REQUEST, "uploadId is required");
//     }

//     const filters = [
//       eq(uploads.id, uploadId as string),
//       eq(uploads.deletedFlg, false),
//     ];

//     const upload = await db.query.uploads.findFirst({
//       where: and(...filters),
//     });

//     if (!upload) {
//       throw new ApiError(HTTP_STATUS.NOT_FOUND, "Upload not found");
//     }

//     const assets = await db
//       .select()
//       .from(uploadAssets)
//       .where(
//         and(
//           eq(uploadAssets.uploadId, uploadId as string),
//           eq(uploadAssets.deletedFlg, false),
//         ),
//       );

//     return res.status(HTTP_STATUS.OK).json(
//       new ApiResponse(HTTP_STATUS.OK, "Upload fetched", {
//         upload: { ...upload, assets },
//       }),
//     );
//   },
// );

export const getUploadById = asyncHandler(
  async (req: Request, res: Response) => {
    const uploadId = req.params.id as string;

    if (!uploadId) {
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "uploadId is required");
    }

    const [upload] = await db
      .select({
        id: uploads.id,
        creatorId: uploads.creatorId,
        title: uploads.title,
        description: uploads.description,
        type: uploads.type,
        genreId: uploads.genreId,
        languageId: uploads.languageId,
        defaultLanguage: uploads.defaultLanguage,
        status: uploads.status,
        metadata: uploads.metadata,
        errorMessage: uploads.errorMessage,
        deletedFlg: uploads.deletedFlg,
        createdAt: uploads.createdAt,
        updatedAt: uploads.updatedAt,
        showId: uploads.showId,
        seasonNumber: uploads.seasonNumber,
        episodeNumber: uploads.episodeNumber,
        contentKind: uploads.contentKind,

        genreName: genres.name,

        languageName: languages.name,

        creatorEmail: Users.email,
        creatorPhone: Users.phone,
      })
      .from(uploads)
      .leftJoin(genres, eq(uploads.genreId, genres.id))
      .leftJoin(languages, eq(uploads.languageId, languages.id))
      .leftJoin(Users, eq(uploads.creatorId, Users.id))
      .where(
        and(
          eq(uploads.id, uploadId),
          eq(uploads.deletedFlg, false),
        ),
      )
      .limit(1);

    if (!upload) {
      throw new ApiError(HTTP_STATUS.NOT_FOUND, "Upload not found");
    }

    const assets = await db
      .select()
      .from(uploadAssets)
      .where(
        and(
          eq(uploadAssets.uploadId, uploadId),
          eq(uploadAssets.deletedFlg, false),
        ),
      );

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Upload fetched", {
        upload: {
          ...upload,   
          assets,
        },
      }),
    );
  },
);

export const getAllUploadsAdmin = asyncHandler(
  async (req: Request, res: Response) => {
    const { contentKind, status, creatorId } = req.query;

    const validKinds = [
      "MOVIE",
      "EPISODE",
      "SHORT",
      "STANDUP",
      "PODCAST_EP",
      "MUSIC_TRACK",
    ] as const;

    type ContentKind = (typeof validKinds)[number];

    const filters = [eq(uploads.deletedFlg, false)];

    if (creatorId && typeof creatorId === "string") {
      filters.push(eq(uploads.creatorId, creatorId));
    }

    if (contentKind) {
      if (!validKinds.includes(contentKind as ContentKind)) {
        throw new ApiError(
          HTTP_STATUS.BAD_REQUEST,
          `Invalid contentKind. Must be one of: ${validKinds.join(", ")}`,
        );
      }
      filters.push(eq(uploads.contentKind, contentKind as ContentKind));
    }

    if (typeof status === "string") {
      if (status === "READY") {
        filters.push(inArray(uploads.status, ["READY", "INITIATED"]));
      } else {
        filters.push(eq(uploads.status, status as any));
      }
    }

    const uploadRows = await db
      .select({
        id: uploads.id,
        creatorId: uploads.creatorId,
        title: uploads.title,
        description: uploads.description,
        type: uploads.type,
        genreId: uploads.genreId,
        languageId: uploads.languageId,
        defaultLanguage: uploads.defaultLanguage,
        status: uploads.status,
        metadata: uploads.metadata,
        errorMessage: uploads.errorMessage,
        deletedFlg: uploads.deletedFlg,
        createdAt: uploads.createdAt,
        updatedAt: uploads.updatedAt,
        showId: uploads.showId,
        seasonNumber: uploads.seasonNumber,
        episodeNumber: uploads.episodeNumber,
        contentKind: uploads.contentKind,
        genreName: genres.name,
        languageName: languages.name,
        creatorEmail: Users.email,
        creatorPhone: Users.phone,
      })
      .from(uploads)
      .leftJoin(genres, eq(uploads.genreId, genres.id))
      .leftJoin(languages, eq(uploads.languageId, languages.id))
      .leftJoin(Users, eq(uploads.creatorId, Users.id))
      .where(and(...filters))
      .orderBy(desc(uploads.createdAt));

    const uploadIds = uploadRows.map((u) => u.id);

    const allAssets = uploadIds.length
      ? await db
          .select()
          .from(uploadAssets)
          .where(
            and(
              inArray(uploadAssets.uploadId, uploadIds),
              eq(uploadAssets.deletedFlg, false),
            ),
          )
      : [];

    const assetsByUploadId = allAssets.reduce<
      Record<string, (typeof uploadAssets.$inferSelect)[]>
    >((acc, asset) => {
      (acc[asset.uploadId] ??= []).push(asset);
      return acc;
    }, {});

    const result = uploadRows.map((upload) => ({
      ...upload,
      assets: assetsByUploadId[upload.id] ?? [],
    }));

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "All uploads (admin)", {
        uploads: result,
        total: result.length,
      }),
    );
  },
);
// export const getAllUploadsAdmin = asyncHandler(
//   async (req: Request, res: Response) => {
//     const { contentKind, status, creatorId } = req.query;

//     const validKinds = [
//       "MOVIE",
//       "EPISODE",
//       "SHORT",
//       "STANDUP",
//       "PODCAST_EP",
//       "MUSIC_TRACK",
//     ] as const;

//     type ContentKind = (typeof validKinds)[number];

//     const filters = [
//       eq(uploads.deletedFlg, false),
//     ];

//     // 👉 optional filter (admin can filter by creator if needed)
//     if (creatorId && typeof creatorId === "string") {
//       filters.push(eq(uploads.creatorId, creatorId));
//     }

//     if (contentKind) {
//       if (!validKinds.includes(contentKind as ContentKind)) {
//         throw new ApiError(
//           HTTP_STATUS.BAD_REQUEST,
//           `Invalid contentKind. Must be one of: ${validKinds.join(", ")}`,
//         );
//       }
//       filters.push(eq(uploads.contentKind, contentKind as ContentKind));
//     }

//     if (typeof status === "string") {
//       if (status === "READY") {
//         filters.push(inArray(uploads.status, ["READY", "INITIATED"]));
//       } else {
//         filters.push(eq(uploads.status, status as any));
//       }
//     }

//     const uploadRows = await db
//       .select()
//       .from(uploads)
//       .where(and(...filters))
//       .orderBy(desc(uploads.createdAt));

//     const uploadIds = uploadRows.map((u) => u.id);

//     const allAssets = uploadIds.length
//       ? await db
//           .select()
//           .from(uploadAssets)
//           .where(
//             and(
//               inArray(uploadAssets.uploadId, uploadIds),
//               eq(uploadAssets.deletedFlg, false),
//             ),
//           )
//       : [];

//     const assetsByUploadId = allAssets.reduce<
//       Record<string, typeof uploadAssets.$inferSelect[]>
//     >((acc, asset) => {
//       (acc[asset.uploadId] ??= []).push(asset);
//       return acc;
//     }, {});

//     const result = uploadRows.map((upload) => ({
//       ...upload,
//       assets: assetsByUploadId[upload.id] ?? [],
//     }));

//     return res.status(HTTP_STATUS.OK).json(
//       new ApiResponse(HTTP_STATUS.OK, "All uploads (admin)", {
//         uploads: result,
//         total: result.length,
//       }),
//     );
//   },
// );

export const getReadyUploads = asyncHandler(
  async (req: Request, res: Response) => {
    const creatorId = (req as any).user?.id;

    const { contentKind, page = "1", limit = "10" } = req.query;

    const validKinds = [
      "MOVIE",
      "EPISODE",
      "SHORT",
      "STANDUP",
      "PODCAST_EP",
      "MUSIC_TRACK",
    ] as const;

    type ContentKind = (typeof validKinds)[number];

    const pageNumber = Math.max(parseInt(page as string, 10), 1);
    const limitNumber = Math.min(
      Math.max(parseInt(limit as string, 10), 1),
      50,
    );
    const offset = (pageNumber - 1) * limitNumber;

    const filters = [
      eq(uploads.deletedFlg, false),
      eq(uploads.creatorId, creatorId),
      eq(uploads.status, "READY"),
    ];

    if (contentKind) {
      if (!validKinds.includes(contentKind as ContentKind)) {
        throw new ApiError(400, "Invalid contentKind");
      }
      filters.push(eq(uploads.contentKind, contentKind as ContentKind));
    }

    const totalResult = await db
      .select({ count: sql<number>`count(*)` })
      .from(uploads)
      .where(and(...filters));

    const totalCount = totalResult[0]?.count ?? 0;

    const uploadRows = await db
      .select({
        id: uploads.id,
        title: uploads.title,
        description: uploads.description,
        contentKind: uploads.contentKind,
        createdAt: uploads.createdAt,
        metadata: uploads.metadata,
        showId: uploads.showId,
        seasonNumber: uploads.seasonNumber,
        episodeNumber: uploads.episodeNumber,
      })
      .from(uploads)
      .where(and(...filters))
      .orderBy(desc(uploads.createdAt))
      .limit(limitNumber)
      .offset(offset);

    if (!uploadRows.length) {
      return res.status(200).json(
        new ApiResponse(200, "Ready uploads fetched", {
          uploads: [],
          pagination: {
            total: totalCount,
            page: pageNumber,
            limit: limitNumber,
            totalPages: Math.ceil(totalCount / limitNumber),
          },
        }),
      );
    }

    const uploadIds = uploadRows.map((u) => u.id);

    const allAssets = await db
      .select({
        id: uploadAssets.id,
        uploadId: uploadAssets.uploadId,
        type: uploadAssets.assetType,
        role: uploadAssets.assetRole,
        url: uploadAssets.masterPlaylistUrl,
      })
      .from(uploadAssets)
      .where(
        and(
          inArray(uploadAssets.uploadId, uploadIds),
          eq(uploadAssets.deletedFlg, false),
          eq(uploadAssets.isLatest, true),
        ),
      );

    const assetsMap = allAssets.reduce<Record<string, typeof allAssets>>(
      (acc, asset) => {
        (acc[asset.uploadId] ??= []).push(asset);
        return acc;
      },
      {},
    );

    const result = uploadRows.map((u) => {
      const meta = (u.metadata || {}) as UploadMeta;

      return {
        id: u.id,
        title: u.title,
        description: u.description,
        type: u.contentKind,
        createdAt: u.createdAt,

        meta: {
          duration: meta.duration,
          rating: meta.rating,
          releaseYear: meta.releaseYear,
          director: meta.director,
          ageRating: meta.ageRating,
        },

        assets: (assetsMap[u.id] ?? []).map<AssetDTO>((a) => ({
          id: a.id,
          type: a.type,
          role: a.role,
          url: a.url,
        })),

        ...(u.contentKind === "EPISODE" && {
          showId: u.showId,
          seasonNumber: u.seasonNumber,
          episodeNumber: u.episodeNumber,
        }),
      };
    });

    return res.status(200).json(
      new ApiResponse(200, "Ready uploads fetched", {
        uploads: result,
        pagination: {
          total: totalCount,
          page: pageNumber,
          limit: limitNumber,
          totalPages: Math.ceil(totalCount / limitNumber),
        },
      }),
    );
  },
);

export const approveUpload = asyncHandler(
  async (req: Request, res: Response) => {
    const uploadId = req.params.id;

    const upload = await db.query.uploads.findFirst({
      where: and(
        eq(uploads.id, uploadId as string),
        eq(uploads.deletedFlg, false),
      ),
    });

    if (!upload) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Upload not found");

    if (upload.status !== "IN_REVIEW") {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Only uploads in review can be approved",
      );
    }

    await db.transaction(async (tx) => {
      await tx
        .update(uploads)
        .set({
          status: "APPROVED" as any,
          errorMessage: null,
          updatedAt: new Date(),
        })
        .where(eq(uploads.id, uploadId as string));

      await tx
        .update(uploadAssets)
        .set({
          status: "APPROVED",
          updatedAt: new Date(),
        })
        .where(eq(uploadAssets.uploadId, uploadId as string));
    });

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Upload approved", {
        uploadId,
        status: "APPROVED",
      }),
    );
  },
);

export const publishUpload = asyncHandler(
  async (req: Request, res: Response) => {
    const uploadId = req.params.id;

    const upload = await db.query.uploads.findFirst({
      where: and(
        eq(uploads.id, uploadId as string),
        eq(uploads.deletedFlg, false),
      ),
    });

    if (!upload) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Upload not found");

    if (upload.status !== "APPROVED") {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Only approved uploads can be published",
      );
    }

    const now = new Date();

    await db.transaction(async (tx) => {
      const assets = await tx.query.uploadAssets.findMany({
        where: eq(uploadAssets.uploadId, uploadId as string),
      });

      const hasInvalidAsset = assets.some((a) => a.status !== "APPROVED");

      if (hasInvalidAsset) {
        throw new ApiError(
          HTTP_STATUS.BAD_REQUEST,
          "All assets must be APPROVED before publishing",
        );
      }

      await tx
        .update(uploads)
        .set({
          status: "PUBLISHED" as any,
          errorMessage: null,
          updatedAt: now,
        })
        .where(eq(uploads.id, uploadId as string));

      await tx
        .update(videos)
        .set({
          status: "PUBLISHED",
          publishedAt: now,
          updatedAt: now,
        })
        .where(eq(videos.uploadId, uploadId as string));
    });

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Upload published", {
        uploadId,
        status: "PUBLISHED",
        publishedAt: now,
      }),
    );
  },
);

export const rejectUpload = asyncHandler(
  async (req: Request, res: Response) => {
    const uploadId = req.params.id;
    const reason =
      typeof req.body?.reason === "string" && req.body.reason.trim()
        ? req.body.reason.trim()
        : "Rejected by admin";

    const upload = await db.query.uploads.findFirst({
      where: and(
        eq(uploads.id, uploadId as string),
        eq(uploads.deletedFlg, false),
      ),
    });
    if (!upload) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Upload not found");

    if (upload.status !== "IN_REVIEW") {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Only uploads in review can be rejected",
      );
    }

    await db
      .update(uploads)
      .set({ status: "REJECTED", errorMessage: reason, updatedAt: new Date() })
      .where(eq(uploads.id, uploadId as string));

    await db
      .update(videos)
      .set({ status: "DRAFT", publishedAt: null, updatedAt: new Date() })
      .where(eq(videos.uploadId, uploadId as string));

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Upload rejected", {
        uploadId,
        status: "REJECTED",
        reason,
      }),
    );
  },
);

export const schedulePublish = asyncHandler(
  async (req: Request, res: Response) => {
    const uploadId = req.params.id;
    const { publishAt } = req.body;

    if (!publishAt) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "publishAt (ISO date string) is required",
      );
    }

    const publishDate = new Date(publishAt);
    if (isNaN(publishDate.getTime())) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "publishAt must be a valid ISO date string",
      );
    }

    const delayMs = publishDate.getTime() - Date.now();
    if (delayMs <= 0) {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "publishAt must be a future date/time. Use instant publish for immediate publishing.",
      );
    }

    const upload = await db.query.uploads.findFirst({
      where: and(
        eq(uploads.id, uploadId as string),
        eq(uploads.deletedFlg, false),
      ),
    });
    if (!upload) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Upload not found");

    if (upload.status !== "APPROVED") {
      throw new ApiError(
        HTTP_STATUS.BAD_REQUEST,
        "Only approved uploads can be scheduled",
      );
    }

    const existingJobId = `scheduled-publish:${uploadId}`;
    const existingJob = await publishQueue.getJob(existingJobId);
    if (existingJob) {
      await existingJob.remove();
    }

    const job = await publishQueue.add(
      "publish-upload",
      { uploadId },
      {
        jobId: existingJobId,
        delay: delayMs,
      },
    );

    const currentMeta = (upload.metadata as Record<string, unknown>) ?? {};
    await db
      .update(uploads)
      .set({
        metadata: {
          ...currentMeta,
          scheduledPublishAt: publishDate.toISOString(),
          scheduledJobId: job.id,
        },
        updatedAt: new Date(),
      })
      .where(eq(uploads.id, uploadId as string));

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Publish scheduled", {
        uploadId,
        scheduledPublishAt: publishDate.toISOString(),
        jobId: job.id,
        delayMs,
      }),
    );
  },
);

export const cancelScheduledPublish = asyncHandler(
  async (req: Request, res: Response) => {
    const uploadId = req.params.id;

    const upload = await db.query.uploads.findFirst({
      where: and(
        eq(uploads.id, uploadId as string),
        eq(uploads.deletedFlg, false),
      ),
    });
    if (!upload) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Upload not found");

    const jobId = `scheduled-publish:${uploadId}`;
    const job = await publishQueue.getJob(jobId);

    if (!job) {
      throw new ApiError(
        HTTP_STATUS.NOT_FOUND,
        "No scheduled publish job found for this upload",
      );
    }

    await job.remove();

    // Clear scheduled metadata
    const currentMeta = (upload.metadata as Record<string, unknown>) ?? {};
    delete currentMeta.scheduledPublishAt;
    delete currentMeta.scheduledJobId;

    await db
      .update(uploads)
      .set({ metadata: currentMeta, updatedAt: new Date() })
      .where(eq(uploads.id, uploadId as string));

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Scheduled publish cancelled", {
        uploadId,
      }),
    );
  },
);
