// src/Hook/useUser.js
import { useQuery } from "@tanstack/react-query";
import { getAllUserApi, userDetailsApi, banUserApi,        
  unbanUserApi,      
  forceLogoutUserApi  } from "../Api/api";
import { toast } from "react-toastify";
// useUser.js - top import line update karo
import {  useMutation, useQueryClient } from "@tanstack/react-query";
// ================= GET ALL USERS =================
export const useGetUsers = (page, limit) => {
  return useQuery({
    queryKey: ["users", page, limit],
    queryFn: () => getAllUserApi({ page, limit }),
    keepPreviousData: true,
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to fetch users");
    },
  });
};

// ================= GET USER DETAILS =================
export const useGetUserDetails = (id) => {
  return useQuery({
    queryKey: ["user", id],
    queryFn: () => userDetailsApi(id),
    enabled: !!id,
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Failed to fetch user details");
    },
  });
};



// ================= BAN USER =================
// ✅ FIXED
export const useBanUser = (id) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (reason) => banUserApi(id, reason), // reason accept karo
    onSuccess: () => {
      queryClient.invalidateQueries(["user", id]);
      toast.success("User banned successfully");
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Ban failed");
    },
  });
};

export const useUnbanUser = (id) => {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: (reason) => unbanUserApi(id, reason), // reason accept karo
    onSuccess: () => {
      queryClient.invalidateQueries(["user", id]);
      toast.success("User unbanned successfully");
    },
    onError: (error) => {
      toast.error(error?.response?.data?.message || "Unban failed");
    },
  });
}; 

// ================= FORCE LOGOUT =================
export const useForceLogoutUser = (id) => {
  return useMutation({
    mutationFn: (data) => forceLogoutUserApi(id, data),

    onSuccess: (data) => {
      toast.success(
        data?.message || "All devices logged out successfully"
      );
    },

    onError: (error) => {
      toast.error(
        error?.response?.data?.message || "Force logout failed"
      );
    },
  });
}; 