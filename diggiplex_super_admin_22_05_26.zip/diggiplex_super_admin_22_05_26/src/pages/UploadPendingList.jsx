// src/pages/UploadPendingList.jsx
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  useGetUploads,
  useApproveVideo,
  useRejectVideo
} from "../Hook/useUpload";

const UploadPendingList = () => {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);
  const [isRejectModalOpen, setIsRejectModalOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [selectedVideoId, setSelectedVideoId] = useState(null);

  // Hooks - pending list API
  const {
    data: videos, // Now this is directly the uploads array because of select
    isLoading,
    isError,
    error: fetchError,
    refetch,
  } = useGetUploads(currentPage, itemsPerPage, "IN_REVIEW");

  // We need to get total from somewhere - but it's lost due to select
  // So we need to fetch it separately or modify the hook
  const [total, setTotal] = useState(0);
  
  // Alternative: Use a separate query for total or modify the hook

  const approveVideo = useApproveVideo();
    const rejectVideo = useRejectVideo();

  const handleViewDetails = (videoId) => {
    navigate(`/upload_details/${videoId}`, {
      state: { from: "/uploadpendinglist" }
    });
  };

  // Handle approve
  const handleApprove = (id, event) => {
    event.stopPropagation();
    approveVideo.mutate(id);
  };

    const handleRejectClick = (id, event) => {
    event.stopPropagation();
    setSelectedVideoId(id);
    setRejectReason("");
    setIsRejectModalOpen(true);
  };


   const handleRejectConfirm = () => {
    if (!selectedVideoId) return;
    rejectVideo.mutate(
      { id: selectedVideoId, reason: rejectReason },
      {
        onSuccess: () => {
          setIsRejectModalOpen(false);
          setSelectedVideoId(null);
          setRejectReason("");
        },
      }
    );
  };
 
   const closeRejectModal = () => {
    setIsRejectModalOpen(false);
    setSelectedVideoId(null);
    setRejectReason("");
  };

  // Format date
  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleString();
  };

  // Get thumbnail URL from assets
  const getThumbnailUrl = (video) => {
    const thumbnailAsset = video.assets?.find(asset => asset.assetRole === "THUMBNAIL");
    return thumbnailAsset?.masterPlaylistUrl || null;
  };

  // Get status badge based on video status
  const getStatusBadge = (video) => {
    const status = video.status || "DRAFT";
    
    switch(status) {
      case "PUBLISHED":
        return {
          text: "Published",
          color: "text-[#4caf7d]",
          bg: "bg-[rgba(76,175,80,0.15)]",
          border: "border-[rgba(76,175,80,0.3)]",
          icon: "fa-globe"
        };
      case "APPROVED":
        return {
          text: "Approved",
          color: "text-[#2196f3]",
          bg: "bg-[rgba(33,150,243,0.15)]",
          border: "border-[rgba(33,150,243,0.3)]",
          icon: "fa-check-circle"
        };
      case "IN_REVIEW":
        return {
          text: "In Review",
          color: "text-[#ff9800]",
          bg: "bg-[rgba(255,152,0,0.15)]",
          border: "border-[rgba(255,152,0,0.3)]",
          icon: "fa-clock"
        };
      case "ARCHIVED":
        return {
          text: "Archived",
          color: "text-[#ff9800]",
          bg: "bg-[rgba(255,152,0,0.15)]",
          border: "border-[rgba(255,152,0,0.3)]",
          icon: "fa-archive"
        };
      case "DRAFT":
      default:
        return {
          text: "Draft",
          color: "text-[#ff9800]",
          bg: "bg-[rgba(255,152,0,0.15)]",
          border: "border-[rgba(255,152,0,0.3)]",
          icon: "fa-pencil-alt"
        };
    }
  };

  // Get upload type badge
  const getUploadTypeBadge = (type) => {
    const types = {
      "WEBSERIES": { text: "Web Series", color: "text-[#ce93d8]" },
      "MOVIE": { text: "Movie", color: "text-[#64b5f6]" },
      "TRAILER": { text: "Trailer", color: "text-[#ffb74d]" }
    };
    return types[type] || { text: type || "Movie", color: "text-[#64b5f6]" };
  };

  // Debug: Log the data structure
  console.log("Videos from hook:", videos);
  console.log("Is Loading:", isLoading);
  console.log("Is Error:", isError);

  return (
    <div className="h-screen flex overflow-hidden" style={{ background: 'rgba(15, 10, 10, 0.85)' }}>
      <div className="flex-1 overflow-auto px-4 py-6">
        <div className="w-full max-w-full">
          {/* Header */}
          <div className="mb-6">
            <h5 className="text-xl font-bold text-[#f5c77a]">Upload Management</h5>
            <p className="text-[#B3B3B3] text-sm mt-1">View and manage pending videos</p>
          </div>

          {/* Videos List Table */}
          <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.125)] overflow-hidden">
            <div className="p-4 border-b border-[rgba(255,255,255,0.07)]">
              <h6 className="text-lg font-semibold text-[#f5c77a]">Pending List</h6>
              <p className="text-[#B3B3B3] text-sm mt-1">Total Videos: {videos?.length || 0}</p>
            </div>
            
            <div className="w-full overflow-x-auto">
              {isLoading ? (
                <div className="flex justify-center items-center py-12">
                  <svg className="animate-spin h-8 w-8 text-[#f5c77a]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                </div>
              ) : isError ? (
                <div className="text-center py-12 text-red-400">
                  <i className="fas fa-exclamation-triangle text-3xl mb-2 block"></i>
                  <p>{fetchError?.message || "Failed to load videos"}</p>
                  <button 
                    onClick={() => refetch()}
                    className="mt-4 px-4 py-2 bg-[#f5c77a] text-[#0F0A0A] rounded text-sm"
                  >
                    Try Again
                  </button>
                </div>
              ) : videos?.length > 0 ? (
                <>
                  <table className="w-full">
                    <thead className="bg-[#231D1D] border-b border-[rgba(255,255,255,0.07)]">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">S.No</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Thumbnail</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Title</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Type</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Status</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Creator</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Created At</th>
                        <th className="px-6 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[rgba(255,255,255,0.07)]">
                      {videos.map((video, index) => {
                        const status = getStatusBadge(video);
                        const uploadType = getUploadTypeBadge(video.type);
                        const thumbnailUrl = getThumbnailUrl(video);
                        
                        return (
                          <tr 
                            key={video.id} 
                            onClick={() => handleViewDetails(video.id)}
                            className="hover:bg-[rgba(245,199,122,0.05)] transition cursor-pointer"
                          >
                            <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                              {(currentPage - 1) * itemsPerPage + index + 1}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              {thumbnailUrl ? (
                                <img 
                                  src={thumbnailUrl} 
                                  alt={video.title}
                                  className="w-16 h-12 object-cover rounded"
                                  onError={(e) => {
                                    e.target.onerror = null;
                                    e.target.src = "https://via.placeholder.com/160x120?text=No+Image";
                                  }}
                                />
                              ) : (
                                <div className="w-16 h-12 bg-[#231D1D] rounded flex items-center justify-center">
                                  <i className="fas fa-video text-2xl text-[#B3B3B3]"></i>
                                </div>
                              )}
                            </td>
                            <td className="px-6 py-4 text-sm text-white">
                              <div className="max-w-xs">
                                <p className="font-medium truncate">{video.title}</p>
                                {video.description && (
                                  <p className="text-xs text-[#B3B3B3] truncate mt-1">{video.description.substring(0, 60)}</p>
                                )}
                              </div>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs rounded-full bg-[rgba(156,39,176,0.15)] ${uploadType.color} border border-[rgba(156,39,176,0.3)]`}>
                                <i className="fas fa-tag mr-1"></i> {uploadType.text}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`px-2 py-1 text-xs rounded-full ${status.bg} ${status.color} border ${status.border}`}>
                                <i className={`fas ${status.icon} mr-1`}></i> {status.text}
                              </span>
                            </td>
                            <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                              {video.creatorId ? (
                                <span className="text-xs font-mono">{video.creatorEmail.substring(0, 8)}...</span>
                              ) : "Unknown"}
                            </td>
                            <td className="px-6 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                              {formatDate(video.createdAt)}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap" onClick={(e) => e.stopPropagation()}>
                              <div className="flex gap-2">
                                <button
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleViewDetails(video.id);
                                  }}
                                  className="px-3 py-1 text-xs bg-[rgba(33,150,243,0.15)] text-[#2196f3] rounded hover:bg-[rgba(33,150,243,0.25)] transition flex items-center gap-1"
                                >
                                  <i className="fas fa-eye"></i> View Details
                                </button>
                                <button
                                  onClick={(e) => handleApprove(video.id, e)}
                                  disabled={approveVideo.isLoading}
                                  className="px-3 py-1 text-xs bg-[rgba(76,175,80,0.15)] text-[#4caf7d] rounded hover:bg-[rgba(76,175,80,0.25)] transition flex items-center gap-1"
                                >
                                  <i className="fas fa-check"></i> Approve
                                </button>
                                 <button
                                  onClick={(e) => handleRejectClick(video.id, e)}
                                  disabled={rejectVideo.isPending}
                                  className="px-3 py-1 text-xs bg-[rgba(244,67,54,0.15)] text-[#f44336] rounded hover:bg-[rgba(244,67,54,0.25)] transition flex items-center gap-1 disabled:opacity-50"
                                >
                                  <i className="fas fa-times"></i> Reject
                                </button>
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>

                  {/* Pagination */}
                  {videos.length >= itemsPerPage && (
                    <div className="flex justify-center gap-2 py-4 border-t border-[rgba(255,255,255,0.07)]">
                      <button
                        onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                        disabled={currentPage === 1}
                        className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                      >
                        Previous
                      </button>
                      <span className="px-3 py-1 text-sm text-[#B3B3B3]">
                        Page {currentPage}
                      </span>
                      <button
                        onClick={() => setCurrentPage(prev => prev + 1)}
                        disabled={videos.length < itemsPerPage}
                        className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                      >
                        Next
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-12 text-[#B3B3B3]">
                  <i className="fas fa-video text-3xl mb-2 block"></i>
                  <p>No Pending Videos found</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
  {isRejectModalOpen && (
        <>
          <div className="fixed inset-0 bg-black/60 z-[9999]" onClick={closeRejectModal} />
          <div className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[10000] w-full max-w-md px-4">
            <div className="bg-[#1C1616] rounded-lg border border-[rgba(244,67,54,0.3)] shadow-2xl">
              {/* Header */}
              <div className="flex justify-between items-center p-5 border-b border-[rgba(255,255,255,0.07)]">
                <h3 className="text-lg font-semibold text-[#f44336] flex items-center gap-2">
                  <i className="fas fa-times-circle"></i> Reject Video
                </h3>
                <button onClick={closeRejectModal} className="text-[#B3B3B3] hover:text-white text-xl transition-colors">
                  <i className="fas fa-times"></i>
                </button>
              </div>
 
              {/* Body */}
              <div className="p-5 space-y-4">
                <p className="text-[#B3B3B3] text-sm">
                  Please provide a reason for rejecting this video. This will be visible to the creator.
                </p>
                <div>
                  <label className="text-xs text-[#B3B3B3] mb-2 block">Rejection Reason <span className="text-[#f44336]">(optional)</span></label>
                  <textarea
                    value={rejectReason}
                    onChange={(e) => setRejectReason(e.target.value)}
                    placeholder="e.g. Content violates community guidelines..."
                    rows={4}
                    className="w-full bg-[#231D1D] border border-[rgba(255,255,255,0.1)] rounded-lg px-3 py-2 text-white text-sm placeholder-[#B3B3B3] focus:outline-none focus:border-[rgba(244,67,54,0.5)] resize-none"
                  />
                </div>
              </div>
 
              {/* Footer */}
              <div className="flex justify-end gap-3 p-5 border-t border-[rgba(255,255,255,0.07)]">
                <button
                  onClick={closeRejectModal}
                  className="px-4 py-2 text-sm bg-[#231D1D] text-[#B3B3B3] rounded hover:bg-[rgba(255,255,255,0.1)] transition"
                >
                  Cancel
                </button>
                <button
                  onClick={handleRejectConfirm}
                  disabled={rejectVideo.isPending}
                  className="px-4 py-2 text-sm bg-[rgba(244,67,54,0.2)] text-[#f44336] border border-[rgba(244,67,54,0.4)] rounded hover:bg-[rgba(244,67,54,0.3)] transition flex items-center gap-2 disabled:opacity-50"
                >
                  {rejectVideo.isPending ? (
                    <>
                      <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                      </svg>
                      Rejecting...
                    </>
                  ) : (
                    <>
                      <i className="fas fa-times-circle"></i> Confirm Reject
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
    
  );
};

export default UploadPendingList;