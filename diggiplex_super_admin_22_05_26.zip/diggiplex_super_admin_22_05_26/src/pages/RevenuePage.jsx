// src/pages/Revenue/RevenuePage.jsx
import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend 
} from "recharts";

// Color scheme
const COLORS = {
  primary: "#f5c77a",
  primaryDark: "#c49a4e",
  background: "rgba(15, 10, 10, 0.85)",
  surface: "#1C1616",
  surfaceLight: "#231D1D",
  text: "#FFFFFF",
  textSecondary: "#B3B3B3",
  textMuted: "#6B6B6B",
  success: "#4caf7d",
  error: "#f44336",
  warning: "#ff9800",
  info: "#2196f3",
  border: "rgba(245,199,122,0.125)",
};

const RevenuePage = () => {
  const [revenueData, setRevenueData] = useState([
    { month: "Jan", revenue: 1240 },
    { month: "Feb", revenue: 1580 },
    { month: "Mar", revenue: 1820 },
    { month: "Apr", revenue: 2100 },
    { month: "May", revenue: 2450 },
    { month: "Jun", revenue: 2890 },
  ]);

  const [sourceData] = useState([
    { name: "Ad Revenue", value: 12450, color: COLORS.primary },
    { name: "Subscriptions", value: 8450, color: "#4caf50" },
    { name: "Sponsorships", value: 5600, color: "#ff9800" },
    { name: "Merchandise", value: 3200, color: "#2196f3" },
  ]);

  const [transactions] = useState([
    { id: 1, date: "2024-03-20", source: "Ad Revenue", amount: 124.50, status: "Completed" },
    { id: 2, date: "2024-03-19", source: "Subscription", amount: 49.99, status: "Pending" },
    { id: 3, date: "2024-03-18", source: "Sponsorship", amount: 500.00, status: "Completed" },
    { id: 4, date: "2024-03-17", source: "Merchandise", amount: 89.99, status: "Completed" },
    { id: 5, date: "2024-03-16", source: "Ad Revenue", amount: 210.50, status: "Completed" },
    { id: 6, date: "2024-03-15", source: "Subscription", amount: 99.99, status: "Pending" },
  ]);

  useEffect(() => {
    const interval = setInterval(() => {
      setRevenueData(prev => prev.map(item => ({
        ...item,
        revenue: item.revenue + Math.floor(Math.random() * 50) - 20,
      })));
    }, 10000);
    return () => clearInterval(interval);
  }, []);

  const totalRevenue = sourceData.reduce((sum, item) => sum + item.value, 0);
  const projectedRevenue = Math.floor(totalRevenue * 1.25);
  const pendingPayout = transactions
    .filter(t => t.status === "Pending")
    .reduce((sum, t) => sum + t.amount, 0);

  const handleExport = () => {
    console.log("Exporting report...");
  };

  const statsCards = [
    {
      title: "Total Revenue (YTD)",
      value: `$${totalRevenue.toLocaleString()}`,
      icon: "💰",
      trend: "+32% vs last year",
      trendUp: true,
      color: COLORS.primary
    },
    {
      title: "Projected Annual Revenue",
      value: `$${projectedRevenue.toLocaleString()}`,
      icon: "📈",
      trend: "+25% growth",
      trendUp: true,
      color: COLORS.primary
    },
    {
      title: "Pending Payout",
      value: `$${pendingPayout.toLocaleString()}`,
      icon: "💳",
      trend: "Next payout: Apr 1",
      trendUp: false,
      color: COLORS.warning
    }
  ];

  return (
    <div className="min-h-screen p-6" style={{ backgroundColor: COLORS.background }}>
      {/* Header */}
      <div className="flex justify-between items-center mb-6 flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold mb-1" style={{ color: COLORS.primary }}>
            Revenue & Monetization
          </h1>
          <p className="text-sm" style={{ color: COLORS.textSecondary }}>
            Track your earnings and financial performance
          </p>
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={handleExport}
          className="flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all"
          style={{ 
            backgroundColor: `${COLORS.primary}15`,
            color: COLORS.primary,
            border: `1px solid ${COLORS.primary}30`
          }}
        >
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
          </svg>
          Export Report
        </motion.button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {statsCards.map((stat, idx) => (
          <motion.div
            key={idx}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.1 }}
            whileHover={{ y: -2 }}
            className="rounded-xl p-5 transition-all duration-300"
            style={{ 
              backgroundColor: COLORS.surface,
              border: `1px solid ${COLORS.border}`,
            }}
          >
            <div className="flex justify-between items-start mb-3">
              <div className="text-3xl">{stat.icon}</div>
              <span className={`text-xs font-semibold px-2 py-1 rounded-full ${
                stat.trendUp ? "text-green-500 bg-green-500/10" : "text-yellow-500 bg-yellow-500/10"
              }`}>
                {stat.trend}
              </span>
            </div>
            <h3 className="text-2xl font-bold mb-1" style={{ color: COLORS.text }}>
              {stat.value}
            </h3>
            <p className="text-xs" style={{ color: COLORS.textMuted }}>
              {stat.title}
            </p>
          </motion.div>
        ))}
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        {/* Revenue Trend Chart */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-2 rounded-xl p-4"
          style={{ 
            backgroundColor: COLORS.surface,
            border: `1px solid ${COLORS.border}`,
          }}
        >
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-lg font-semibold" style={{ color: COLORS.primary }}>
              Revenue Trend
            </h2>
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full animate-pulse" style={{ backgroundColor: COLORS.success }} />
              <span className="text-xs" style={{ color: COLORS.textMuted }}>Live Updates</span>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={revenueData}>
              <defs>
                <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={COLORS.primary} stopOpacity={0.8}/>
                  <stop offset="95%" stopColor={COLORS.primary} stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis dataKey="month" stroke={COLORS.textMuted} tick={{ fill: COLORS.textMuted, fontSize: 12 }} />
              <YAxis stroke={COLORS.textMuted} tick={{ fill: COLORS.textMuted, fontSize: 12 }} />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: COLORS.surface, 
                  borderColor: COLORS.primary,
                  borderRadius: "8px",
                  color: COLORS.text
                }} 
              />
              <Area 
                type="monotone" 
                dataKey="revenue" 
                stroke={COLORS.primary} 
                strokeWidth={2}
                fillOpacity={1} 
                fill="url(#colorRevenue)" 
              />
            </AreaChart>
          </ResponsiveContainer>
        </motion.div>

        {/* Revenue Source Pie Chart */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="rounded-xl p-4"
          style={{ 
            backgroundColor: COLORS.surface,
            border: `1px solid ${COLORS.border}`,
          }}
        >
          <h2 className="text-lg font-semibold mb-4" style={{ color: COLORS.primary }}>
            Revenue by Source
          </h2>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={sourceData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
              >
                {sourceData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: COLORS.surface, 
                  borderColor: COLORS.primary,
                  borderRadius: "8px",
                  color: COLORS.text
                }} 
              />
              <Legend 
                wrapperStyle={{ color: COLORS.textMuted, fontSize: "12px" }}
                formatter={(value) => <span style={{ color: COLORS.textSecondary }}>{value}</span>}
              />
            </PieChart>
          </ResponsiveContainer>
        </motion.div>
      </div>

      {/* Transactions Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="rounded-xl overflow-hidden"
        style={{ 
          backgroundColor: COLORS.surface,
          border: `1px solid ${COLORS.border}`,
        }}
      >
        <div className="p-4 border-b" style={{ borderColor: COLORS.border }}>
          <div className="flex justify-between items-center">
            <h2 className="text-lg font-semibold" style={{ color: COLORS.primary }}>
              Recent Transactions
            </h2>
            <button className="text-xs px-3 py-1 rounded-lg transition-all hover:bg-white/5" style={{ color: COLORS.textMuted }}>
              View All
            </button>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                <th className="text-left p-4 text-xs font-medium" style={{ color: COLORS.textMuted }}>Date</th>
                <th className="text-left p-4 text-xs font-medium" style={{ color: COLORS.textMuted }}>Source</th>
                <th className="text-left p-4 text-xs font-medium" style={{ color: COLORS.textMuted }}>Amount</th>
                <th className="text-left p-4 text-xs font-medium" style={{ color: COLORS.textMuted }}>Status</th>
              </tr>
            </thead>
            <tbody>
              <AnimatePresence>
                {transactions.map((tx, idx) => (
                  <motion.tr
                    key={tx.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.05 }}
                    style={{ borderBottom: `1px solid ${COLORS.border}` }}
                    className="hover:bg-white/5 transition-colors"
                  >
                    <td className="p-4 text-sm" style={{ color: COLORS.textSecondary }}>{tx.date}</td>
                    <td className="p-4 text-sm font-medium" style={{ color: COLORS.primary }}>{tx.source}</td>
                    <td className="p-4 text-sm font-semibold" style={{ color: COLORS.primary }}>${tx.amount.toFixed(2)}</td>
                    <td className="p-4">
                      <span 
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${
                          tx.status === "Completed" 
                            ? "bg-green-500/10 text-green-500" 
                            : "bg-yellow-500/10 text-yellow-500"
                        }`}
                      >
                        <span className={`w-1.5 h-1.5 rounded-full ${
                          tx.status === "Completed" ? "bg-green-500" : "bg-yellow-500"
                        }`} />
                        {tx.status}
                      </span>
                    </td>
                  </motion.tr>
                ))}
              </AnimatePresence>
            </tbody>
          </table>
        </div>
        
        {/* Table Footer */}
        <div className="p-4 border-t" style={{ borderColor: COLORS.border }}>
          <div className="flex justify-between items-center">
            <p className="text-xs" style={{ color: COLORS.textMuted }}>
              Showing {transactions.length} recent transactions
            </p>
            <div className="flex gap-2">
              <button className="p-1 rounded hover:bg-white/5 transition-colors disabled:opacity-50" disabled>
                <svg className="w-4 h-4" style={{ color: COLORS.textMuted }} fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </button>
              <button className="p-1 rounded hover:bg-white/5 transition-colors">
                <svg className="w-4 h-4" style={{ color: COLORS.textMuted }} fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default RevenuePage;