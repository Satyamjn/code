// types/custom.d.ts

declare module "cors";
declare module "nodemailer";

declare module "multer" {
  const multer: any;
  export default multer;
}

declare module "multer-s3" {
  const multerS3: any;
  export default multerS3;
}

declare global {
  namespace Express {
    namespace Multer {
      interface File {
        location?: string;
      }
    }

    interface Request {
      user?: {
        id: string;
        role: string;
        [key: string]: any;
      };
      files?:
        | Express.Multer.File[]
        | { [fieldname: string]: Express.Multer.File[] };
    }
  }
}
export interface HomepageItem {
  id: string;
  title: string;
  type: "MOVIE" | "WEB_SERIES";
  contentKind: "MOVIE" | "EPISODE" | "PODCAST_EP" | "MUSIC_TRACK" | "SHORT" | "STANDUP";
  genreId: string | null;
  thumbnailUrl: string | null;
  posterUrl: string | null;
  rating?: number;
  releaseYear?: number;
  duration?: number;
  status: string;
}

export interface PaginatedResponse {
  items: HomepageItem[];
  totalCount: number;
  hasMore: boolean;
  nextOffset?: number;
}

export {}; // 🔥 VERY IMPORTANT
