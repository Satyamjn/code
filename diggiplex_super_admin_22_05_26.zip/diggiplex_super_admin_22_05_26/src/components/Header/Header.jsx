import { useState } from "react";
import {
  AppBar, Toolbar, Box, IconButton,
  Avatar, Button, Badge, Tooltip, Typography,
  Menu, MenuItem, Divider, ListItemIcon, Dialog,
  DialogTitle, DialogContent, DialogContentText,
  DialogActions
} from "@mui/material";
import NotificationsRoundedIcon from "@mui/icons-material/NotificationsRounded";
import MenuRoundedIcon from "@mui/icons-material/MenuRounded";
import AddRoundedIcon from "@mui/icons-material/AddRounded";
import KeyboardArrowDownRoundedIcon from "@mui/icons-material/KeyboardArrowDownRounded";
import LogoutRoundedIcon from "@mui/icons-material/LogoutRounded";
import PersonRoundedIcon from "@mui/icons-material/PersonRounded";
import SettingsRoundedIcon from "@mui/icons-material/SettingsRounded";
import DashboardRoundedIcon from "@mui/icons-material/DashboardRounded";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { COLORS } from "../../theme/theme";
import { useLogout } from "../../Hook/userLogin.js";

export default function Header({ setMobileOpen, setActivePage }) {
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const [openLogoutDialog, setOpenLogoutDialog] = useState(false);
  const open = Boolean(anchorEl);
  
  // Get logout mutation hook
  const logoutMutation = useLogout();

  // Get user data from localStorage
const userData = JSON.parse(localStorage.getItem("user") || "{}");
const userName = userData?.email || "User";
const userEmail = userData?.email || "";
const userRole = userData?.role || "Creator";
const userInitial = userName.charAt(0).toUpperCase();

  // Handle dropdown open
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  // Handle dropdown close
  const handleClose = () => {
    setAnchorEl(null);
  };

  // Open logout confirmation dialog
  const handleLogoutClick = () => {
    handleClose();
    setOpenLogoutDialog(true);
  };

  // Confirm logout
  const confirmLogout = () => {
    setOpenLogoutDialog(false);
    
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        // Clear localStorage
        localStorage.clear();
     
        
        toast.success("Logged out successfully!");
        navigate("/");
      },
      onError: (error) => {
        console.error("Logout error:", error);
        // Still clear local data
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        toast.error(error?.response?.data?.message || "Logout failed");
        navigate("/");
      },
    });
  };

  // Cancel logout
  const cancelLogout = () => {
    setOpenLogoutDialog(false);
  };

  // Handle profile click
  const handleProfile = () => {
    handleClose();
    setActivePage("profile");
  };

  // Handle settings click
  const handleSettings = () => {
    handleClose();
    setActivePage("settings");
  };

  // Handle dashboard click
  const handleDashboard = () => {
    handleClose();
    setActivePage("dashboard");
  };

  return (
    <>
      <AppBar
        position="fixed"
        elevation={0}
        sx={{
          zIndex: (theme) => theme.zIndex.drawer - 1,
          bgcolor: "rgba(15,10,10,0.85)",
          backdropFilter: "blur(20px)",
          borderBottom: `1px solid ${COLORS.border}`,
        }}
      >
        <Toolbar sx={{ px: { xs: 2, md: 3 }, minHeight: "72px !important", gap: 2 }}>
          {/* Mobile menu */}
          <IconButton
            sx={{ display: { sm: "none" }, color: COLORS.textSecondary }}
            onClick={() => setMobileOpen(true)}
          >
            <MenuRoundedIcon />
          </IconButton>

          <Box sx={{ flex: 1 }} />

          {/* Upload button */}
          {/* <Button
            variant="contained"
            startIcon={<AddRoundedIcon />}
            onClick={() => setActivePage("studio")}
            sx={{
              display: { xs: "none", sm: "flex" },
              background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.accentDark})`,
              color: "#0F0A0A",
              fontWeight: 700,
              fontSize: "0.82rem",
              borderRadius: "5px",
              px: 2.5,
              py: 1,
              boxShadow: `0 4px 20px rgba(245,199,122,0.3)`,
              "&:hover": {
                boxShadow: `0 6px 28px rgba(245,199,122,0.45)`,
                transform: "translateY(-1px)",
              },
              transition: "all 0.2s",
            }}
          >
            Upload Content
          </Button> */}

          {/* Notifications */}
          <Tooltip title="Notifications">
            <IconButton
              sx={{
                color: COLORS.textSecondary,
                bgcolor: COLORS.surface,
                border: `1px solid ${COLORS.border}`,
                borderRadius: "5px",
                width: 40, height: 40,
                "&:hover": { bgcolor: COLORS.surfaceElevated, color: COLORS.text },
              }}
            >
              <Badge
                badgeContent={3}
                sx={{
                  "& .MuiBadge-badge": {
                    bgcolor: COLORS.accent,
                    color: "#0F0A0A",
                    fontWeight: 700,
                    fontSize: "0.6rem",
                    minWidth: 16,
                    height: 16,
                  },
                }}
              >
                <NotificationsRoundedIcon fontSize="small" />
              </Badge>
            </IconButton>
          </Tooltip>

          {/* Profile Avatar with Dropdown */}
          <Box
            onClick={handleClick}
            sx={{
              display: "flex", alignItems: "center", gap: 1,
              cursor: "pointer", ml: 0.5,
              bgcolor: COLORS.surface,
              border: `1px solid ${COLORS.border}`,
              borderRadius: "5px",
              px: 1.2, py: 0.7,
              transition: "all 0.2s",
              "&:hover": { bgcolor: COLORS.surfaceElevated, borderColor: "rgba(245,199,122,0.3)" },
            }}
          >
            <Avatar
              sx={{
                width: 30, height: 30, fontSize: "0.72rem", fontWeight: 700,
                background: `linear-gradient(135deg, ${COLORS.accent}, ${COLORS.accentDark})`,
                color: "#0F0A0A",
              }}
            >
              {userInitial}
            </Avatar>
            <Box sx={{ display: { xs: "none", md: "block" } }}>
              <Typography sx={{ fontSize: "0.78rem", fontWeight: 600, color: COLORS.text, lineHeight: 1.2 }}>
                {userName}
              </Typography>
              <Typography sx={{ fontSize: "0.62rem", color: COLORS.accent }}>
                {userRole}
              </Typography>
            </Box>
            <KeyboardArrowDownRoundedIcon sx={{ color: COLORS.textMuted, fontSize: 16, display: { xs: "none", md: "block" } }} />
          </Box>

          {/* Dropdown Menu */}
          <Menu
            anchorEl={anchorEl}
            open={open}
            onClose={handleClose}
            onClick={handleClose}
            PaperProps={{
              elevation: 0,
              sx: {
                overflow: 'visible',
                filter: 'drop-shadow(0px 2px 8px rgba(0,0,0,0.32))',
                mt: 1.5,
                bgcolor: COLORS.surfaceElevated,
                border: `1px solid ${COLORS.border}`,
                borderRadius: "8px",
                minWidth: 220,
                '& .MuiAvatar-root': {
                  width: 32,
                  height: 32,
                  ml: -0.5,
                  mr: 1,
                },
                '&::before': {
                  content: '""',
                  display: 'block',
                  position: 'absolute',
                  top: 0,
                  right: 14,
                  width: 10,
                  height: 10,
                  bgcolor: COLORS.surfaceElevated,
                  transform: 'translateY(-50%) rotate(45deg)',
                  zIndex: 0,
                  borderLeft: `1px solid ${COLORS.border}`,
                  borderTop: `1px solid ${COLORS.border}`,
                },
              },
            }}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
          >
            {/* User Info */}
            <Box sx={{ px: 2, py: 1.5, borderBottom: `1px solid ${COLORS.border}` }}>
              <Typography sx={{ fontSize: "0.85rem", fontWeight: 600, color: COLORS.text }}>
                {userName}
              </Typography>
              <Typography sx={{ fontSize: "0.7rem", color: COLORS.textMuted }}>
                {userEmail}
              </Typography>
            </Box>

            {/* Menu Items */}
            <MenuItem onClick={handleDashboard} sx={{ py: 1, gap: 1 }}>
              <ListItemIcon>
                <DashboardRoundedIcon sx={{ color: COLORS.accent, fontSize: 20 }} />
              </ListItemIcon>
              <Typography sx={{ fontSize: "0.85rem", color: COLORS.text }}>Dashboard</Typography>
            </MenuItem>

            <MenuItem onClick={handleProfile} sx={{ py: 1, gap: 1 }}>
              <ListItemIcon>
                <PersonRoundedIcon sx={{ color: COLORS.accent, fontSize: 20 }} />
              </ListItemIcon>
              <Typography sx={{ fontSize: "0.85rem", color: COLORS.text }}>My Profile</Typography>
            </MenuItem>

            <MenuItem onClick={handleSettings} sx={{ py: 1, gap: 1 }}>
              <ListItemIcon>
                <SettingsRoundedIcon sx={{ color: COLORS.accent, fontSize: 20 }} />
              </ListItemIcon>
              <Typography sx={{ fontSize: "0.85rem", color: COLORS.text }}>Settings</Typography>
            </MenuItem>

            <Divider sx={{ my: 0.5, borderColor: COLORS.border }} />

            {/* Logout Button */}
            <MenuItem onClick={handleLogoutClick} sx={{ py: 1, gap: 1 }}>
              <ListItemIcon>
                <LogoutRoundedIcon sx={{ color: "#f44336", fontSize: 20 }} />
              </ListItemIcon>
              <Typography sx={{ fontSize: "0.85rem", color: "#f44336" }}>
                Logout
              </Typography>
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      {/* Logout Confirmation Dialog */}
      <Dialog
        open={openLogoutDialog}
        onClose={cancelLogout}
        PaperProps={{
          sx: {
            bgcolor: COLORS.surfaceElevated,
            borderRadius: "12px",
            border: `1px solid ${COLORS.border}`,
            minWidth: { xs: "90%", sm: 400 },
          }
        }}
      >
        <DialogTitle sx={{ color: COLORS.text, borderBottom: `1px solid ${COLORS.border}`, pb: 2 }}>
          <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
            <LogoutRoundedIcon sx={{ color: "#f44336" }} />
            <span>Confirm Logout</span>
          </Box>
        </DialogTitle>
        <DialogContent sx={{ mt: 2 }}>
          <DialogContentText sx={{ color: COLORS.textMuted }}>
            Are you sure you want to logout? You will need to login again to access your account.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ p: 2, gap: 1, borderTop: `1px solid ${COLORS.border}` }}>
          <Button 
            onClick={cancelLogout}
            sx={{
              color: COLORS.text,
              bgcolor: COLORS.surface,
              '&:hover': { bgcolor: COLORS.surfaceElevated }
            }}
          >
            Cancel
          </Button>
          <Button 
            onClick={confirmLogout}
            disabled={logoutMutation.isPending}
            sx={{
              bgcolor: "#f44336",
              color: "white",
              '&:hover': { bgcolor: "#d32f2f" },
              '&.Mui-disabled': { bgcolor: "rgba(244,67,54,0.5)" }
            }}
          >
            {logoutMutation.isPending ? "Logging out..." : "Logout"}
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}