// src/pages/UploadDetails.jsx
import React, { useState, useEffect, useRef, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useUploadDetails } from "../Hook/useUpload.js";
import Hls from "hls.js";

/* ─────────────────────────────────────────────────────────────
   Inject global styles once
───────────────────────────────────────────────────────────── */
if (typeof document !== "undefined" && !document.getElementById("ud-styles")) {
  const s = document.createElement("style");
  s.id = "ud-styles";
  s.textContent = `
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap');
    @keyframes ud-spin    { to { transform: rotate(360deg); } }
    @keyframes ud-pulse   { 0%,100%{opacity:1} 50%{opacity:.4} }
    @keyframes ud-fadein  { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
    @keyframes ud-modal-in{ from{opacity:0;transform:scale(.96) translateY(8px)} to{opacity:1;transform:scale(1) translateY(0)} }
    @keyframes ud-shimmer {
      0%{background-position:-400px 0}
      100%{background-position:400px 0}
    }
    .ud-animate { animation: ud-fadein .4s ease both; }
    .ud-tab-btn {
      padding: 10px 20px; font-size: 13px; font-weight: 500;
      font-family: 'DM Sans', sans-serif; cursor: pointer;
      border: none; background: transparent; color: rgba(255,255,255,.4);
      border-bottom: 2px solid transparent; transition: all .2s;
      white-space: nowrap;
    }
    .ud-tab-btn:hover { color: rgba(255,255,255,.75); }
    .ud-tab-btn.active { color: #f5c77a; border-bottom-color: #f5c77a; }
    .ud-card {
      background: #1e1814;
      border: 0.5px solid rgba(245,199,122,.1);
      border-radius: 12px; padding: 16px 18px;
    }
    .ud-info-grid {
      display: grid; grid-template-columns: repeat(auto-fill, minmax(200px,1fr)); gap: 12px;
    }
    .ud-field { background: #241e18; border-radius: 8px; padding: 12px 14px; }
    .ud-field-label {
      font-size: 10px; letter-spacing: .8px; text-transform: uppercase;
      color: rgba(255,255,255,.35); margin-bottom: 5px;
      display: flex; align-items: center; gap: 5px;
    }
    .ud-field-val { font-size: 14px; color: #e8e0d0; font-weight: 400; }
    .ud-copy-btn {
      font-size: 10px; padding: 3px 8px; border-radius: 4px;
      background: rgba(245,199,122,.1); border: 0.5px solid rgba(245,199,122,.25);
      color: #f5c77a; cursor: pointer; font-family: 'DM Sans',sans-serif;
      transition: background .15s; white-space: nowrap;
    }
    .ud-copy-btn:hover { background: rgba(245,199,122,.2); }
    .ud-submit-btn {
      padding: 10px 28px; border-radius: 8px; border: none; cursor: pointer;
      font-family: 'DM Sans',sans-serif; font-weight: 500; font-size: 13px;
      background: linear-gradient(135deg, #f5c77a, #c49a4e);
      color: #0f0a0a; transition: opacity .2s, transform .15s;
    }
    .ud-submit-btn:hover:not(:disabled) { opacity: .9; transform: translateY(-1px); }
    .ud-submit-btn:disabled { opacity: .4; cursor: not-allowed; }
    .ud-back-btn {
      display: inline-flex; align-items: center; gap: 6px;
      font-size: 12px; color: #f5c77a; background: none;
      border: none; cursor: pointer; font-family: 'DM Sans',sans-serif;
      padding: 0; transition: opacity .2s;
    }
    .ud-back-btn:hover { opacity: .75; }
    .ud-refresh-btn {
      display: inline-flex; align-items: center; gap: 6px;
      font-size: 12px; padding: 7px 14px; border-radius: 7px; cursor: pointer;
      font-family: 'DM Sans',sans-serif;
      background: rgba(245,199,122,.08);
      border: 0.5px solid rgba(245,199,122,.25);
      color: #f5c77a; transition: background .2s;
    }
    .ud-refresh-btn:hover { background: rgba(245,199,122,.16); }

    /* ── HLS Player quality buttons ── */
    .hls-quality-btn {
      padding: 4px 10px; font-size: 10px; border-radius: 5px; letter-spacing: .3px;
      border: 0.5px solid rgba(255,255,255,.12); cursor: pointer;
      font-family: 'DM Sans',sans-serif; font-weight: 500;
      background: rgba(255,255,255,.05); color: rgba(255,255,255,.5);
      transition: all .15s;
    }
    .hls-quality-btn:hover { background: rgba(255,255,255,.1); color: rgba(255,255,255,.85); }
    .hls-quality-btn.active {
      background: #f5c77a; color: #0f0a0a;
      border-color: #f5c77a; font-weight: 600;
    }

    /* ── Modal ── */
    .ud-modal-overlay {
      position: fixed; inset: 0; background: rgba(0,0,0,.8);
      z-index: 9999; display: flex; align-items: center; justify-content: center;
      padding: 20px; backdrop-filter: blur(4px);
    }
    .ud-img-modal-box {
      background: #1c1612; border: 0.5px solid rgba(245,199,122,.25);
      border-radius: 14px; overflow: hidden;
      width: 100%; max-width: 900px; animation: ud-modal-in .25s ease;
    }
    .ud-tag {
      display: inline-flex; align-items: center;
      padding: 3px 10px; border-radius: 4px; font-size: 11px; font-weight: 500;
    }

    /* ── Video player wrapper ── */
    .hls-player-wrap { background: #000; border-radius: 12px; overflow: hidden; position: relative; }
    .hls-player-wrap video { width: 100%; display: block; background: #000; }
    .hls-spinner {
      position: absolute; inset: 0;
      display: flex; align-items: center; justify-content: center;
      background: rgba(0,0,0,.6); pointer-events: none;
    }
    .hls-ctrl-bar {
      display: flex; align-items: center; justify-content: space-between;
      padding: 8px 14px; background: #0d0d0d;
      border-top: 0.5px solid rgba(255,255,255,.05); flex-wrap: wrap; gap: 8px;
    }
    .hls-ctrl-left  { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
    .hls-ctrl-right { display: flex; align-items: center; gap: 8px; }
    .hls-label {
      font-size: 9px; color: rgba(255,255,255,.25);
      letter-spacing: 1px; text-transform: uppercase;
    }
  `;
  document.head.appendChild(s);
}

/* ─────────────────────────────────────────────────────────────
   Constants & helpers
───────────────────────────────────────────────────────────── */
const STATUS_CFG = {
  APPROVED: {
    bg: "rgba(76,175,80,.15)",
    color: "#81c784",
    border: "rgba(76,175,80,.35)",
    label: "Approved",
  },
  READY: {
    bg: "rgba(76,175,80,.15)",
    color: "#81c784",
    border: "rgba(76,175,80,.35)",
    label: "Ready",
  },
  REJECTED: {
    bg: "rgba(244,67,54,.15)",
    color: "#ef9a9a",
    border: "rgba(244,67,54,.35)",
    label: "Rejected",
  },
  PENDING: {
    bg: "rgba(255,152,0,.15)",
    color: "#ffb74d",
    border: "rgba(255,152,0,.35)",
    label: "Pending",
  },
  PENDING_APPROVAL: {
    bg: "rgba(255,152,0,.15)",
    color: "#ffb74d",
    border: "rgba(255,152,0,.35)",
    label: "Pending Approval",
  },
  PENDING_UPLOAD: {
    bg: "rgba(255,152,0,.15)",
    color: "#ffb74d",
    border: "rgba(255,152,0,.35)",
    label: "Pending Upload",
  },
  PROCESSING: {
    bg: "rgba(156,39,176,.15)",
    color: "#ce93d8",
    border: "rgba(156,39,176,.35)",
    label: "Processing",
  },
  UPLOADED: {
    bg: "rgba(33,150,243,.15)",
    color: "#64b5f6",
    border: "rgba(33,150,243,.35)",
    label: "Uploaded",
  },
  IN_REVIEW: {
    bg: "rgba(33,150,243,.15)",
    color: "#64b5f6",
    border: "rgba(33,150,243,.35)",
    label: "In Review",
  },
  PUBLISHED: {
    bg: "rgba(0,200,83,.15)",
    color: "#69f0ae",
    border: "rgba(0,200,83,.35)",
    label: "Published",
  },
};
const getStatusCfg = (s) =>
  STATUS_CFG[(s || "").toUpperCase()] || {
    bg: "rgba(255,255,255,.08)",
    color: "rgba(255,255,255,.5)",
    border: "rgba(255,255,255,.15)",
    label: s || "Unknown",
  };

const CONTENT_ICONS = {
  MOVIE: "🎬",
  WEBSERIES: "📺",
  SHORT: "🎥",
  STANDUP: "🎙️",
  PODCAST_EP: "🎧",
  MUSIC_TRACK: "🎵",
};
const contentIcon = (t) => CONTENT_ICONS[(t || "").toUpperCase()] || "📁";

const fmtDate = (d) =>
  d
    ? new Date(d).toLocaleString("en-IN", {
        day: "numeric",
        month: "short",
        year: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "N/A";

const getMasterBase = (masterUrl) =>
  masterUrl ? masterUrl.replace(/\/master\.m3u8$/i, "") : null;

const QUALITY_LEVELS = ["480p", "720p", "1080p", "2k"];

/* ─────────────────────────────────────────────────────────────
   HLS Player Component
───────────────────────────────────────────────────────────── */
const HLSPlayer = ({ src, poster, title }) => {
  const videoRef = useRef(null);
  const hlsRef = useRef(null);
  const wrapRef = useRef(null);
  const [selected, setSelected] = useState("auto");
  const [hlsLevels, setHlsLevels] = useState([]);
  const [loading, setLoading] = useState(true);
  const [buffering, setBuffering] = useState(false);
  const [errMsg, setErrMsg] = useState(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const baseUrl = getMasterBase(src);

  // Keyboard shortcuts
  useEffect(() => {
    const handleKey = (e) => {
      const v = videoRef.current;
      if (
        !v ||
        (!wrapRef.current?.contains(document.activeElement) &&
          document.activeElement?.tagName !== "BODY")
      )
        return;
      if (e.target.tagName === "INPUT" || e.target.tagName === "TEXTAREA")
        return;
      if (e.code === "Space") {
        e.preventDefault();
        v.paused ? v.play() : v.pause();
      }
      if (e.code === "KeyF") {
        e.preventDefault();
        toggleFullscreen();
      }
      if (e.code === "KeyM") {
        e.preventDefault();
        v.muted = !v.muted;
      }
      if (e.code === "ArrowRight") {
        e.preventDefault();
        v.currentTime += 5;
      }
      if (e.code === "ArrowLeft") {
        e.preventDefault();
        v.currentTime -= 5;
      }
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  // Fullscreen listener
  useEffect(() => {
    const onFs = () => setIsFullscreen(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", onFs);
    return () => document.removeEventListener("fullscreenchange", onFs);
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      wrapRef.current?.requestFullscreen?.();
    } else {
      document.exitFullscreen?.();
    }
  };

  const initHls = useCallback((url) => {
    const video = videoRef.current;
    if (!video || !url) return;
    setLoading(true);
    setErrMsg(null);

    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    if (Hls.isSupported()) {
      const hls = new Hls({
        startLevel: -1,
        enableWorker: true,
        lowLatencyMode: false,
        maxBufferLength: 60,
        maxMaxBufferLength: 120,
      });
      hlsRef.current = hls;
      hls.loadSource(url);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, (_, data) => {
        setLoading(false);
        setHlsLevels(
          data.levels.map((l, i) => ({
            index: i,
            label: l.height ? `${l.height}p` : `Level ${i + 1}`,
          })),
        );
      });

      hls.on(Hls.Events.ERROR, (_, data) => {
        if (data.fatal) {
          setLoading(false);
          if (data.type === Hls.ErrorTypes.NETWORK_ERROR) {
            hls.startLoad();
          } else {
            setErrMsg(`Playback error: ${data.details}`);
          }
        }
      });

      return () => {
        hls.destroy();
        hlsRef.current = null;
      };
    } else if (video.canPlayType("application/vnd.apple.mpegurl")) {
      video.src = url;
      video.onloadedmetadata = () => setLoading(false);
    }
  }, []);

  useEffect(() => {
    const cleanup = initHls(src);
    return cleanup;
  }, [src, initHls]);

  // Buffer / waiting events
  useEffect(() => {
    const v = videoRef.current;
    if (!v) return;
    const onWait = () => setBuffering(true);
    const onPlaying = () => setBuffering(false);
    v.addEventListener("waiting", onWait);
    v.addEventListener("playing", onPlaying);
    v.addEventListener("canplay", onPlaying);
    return () => {
      v.removeEventListener("waiting", onWait);
      v.removeEventListener("playing", onPlaying);
      v.removeEventListener("canplay", onPlaying);
    };
  }, []);

  const handleQuality = (q) => {
    setSelected(q);
    if (q === "auto") {
      if (hlsRef.current) hlsRef.current.currentLevel = -1;
      else initHls(src);
      return;
    }

    if (hlsRef.current && hlsLevels.length > 0) {
      const idx = hlsLevels.findIndex((l) => l.label === q);
      if (idx !== -1) {
        hlsRef.current.currentLevel = idx;
        return;
      }
    }

    if (baseUrl) {
      const qualityUrl = `${baseUrl}/${q}/index.m3u8`;
      const video = videoRef.current;
      const currentTime = video?.currentTime || 0;
      const wasPlaying = !video?.paused;

      if (Hls.isSupported()) {
        if (hlsRef.current) hlsRef.current.destroy();
        const hls = new Hls({ startLevel: 0 });
        hlsRef.current = hls;
        hls.loadSource(qualityUrl);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED, () => {
          if (video) {
            video.currentTime = currentTime;
            if (wasPlaying) video.play().catch(() => {});
          }
        });
        hls.on(Hls.Events.ERROR, (_, data) => {
          if (data.fatal) setErrMsg(`Could not load ${q} quality`);
        });
      } else if (video?.canPlayType("application/vnd.apple.mpegurl")) {
        const prev = video.currentTime;
        video.src = qualityUrl;
        video.currentTime = prev;
        if (wasPlaying) video.play().catch(() => {});
      }
    }
  };

  const qualityOptions =
    hlsLevels.length > 0 ? hlsLevels.map((l) => l.label) : QUALITY_LEVELS;

  const showSpinner = loading || buffering;

  return (
    <div
      ref={wrapRef}
      className="hls-player-wrap"
      tabIndex={0}
      style={{ outline: "none" }}
    >
      <video
        ref={videoRef}
        poster={poster}
        controls
        playsInline
        style={{ maxHeight: 500 }}
      />

      {showSpinner && (
        <div className="hls-spinner">
          <div style={{ textAlign: "center" }}>
            <div
              style={{
                width: 42,
                height: 42,
                border: "3px solid rgba(245,199,122,.15)",
                borderTop: "3px solid #f5c77a",
                borderRadius: "50%",
                animation: "ud-spin .75s linear infinite",
                margin: "0 auto 10px",
              }}
            />
            <span style={{ fontSize: 11, color: "rgba(255,255,255,.45)" }}>
              {loading ? "Loading stream…" : "Buffering…"}
            </span>
          </div>
        </div>
      )}

      <div className="hls-ctrl-bar">
        <div className="hls-ctrl-left">
          <span className="hls-label">Quality</span>
          <button
            className={`hls-quality-btn${selected === "auto" ? " active" : ""}`}
            onClick={() => handleQuality("auto")}
          >
            Auto
          </button>
          {[...qualityOptions].reverse().map((q) => (
            <button
              key={q}
              className={`hls-quality-btn${selected === q ? " active" : ""}`}
              onClick={() => handleQuality(q)}
            >
              {q}
            </button>
          ))}
        </div>

        <div className="hls-ctrl-right">
          {title && (
            <span
              style={{
                fontSize: 10,
                color: "rgba(255,255,255,.25)",
                maxWidth: 180,
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
              }}
            >
              {title}
            </span>
          )}
          <button
            onClick={toggleFullscreen}
            title="Fullscreen (F)"
            style={{
              background: "rgba(255,255,255,.06)",
              border: "0.5px solid rgba(255,255,255,.1)",
              color: "rgba(255,255,255,.5)",
              borderRadius: 5,
              width: 28,
              height: 28,
              cursor: "pointer",
              fontSize: 12,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              transition: "background .15s",
            }}
          >
            {isFullscreen ? "⛶" : "⛶"}
          </button>
        </div>
      </div>

      {errMsg && (
        <div
          style={{
            padding: "8px 14px",
            fontSize: 11,
            color: "#ef9a9a",
            background: "rgba(244,67,54,.08)",
            borderTop: "0.5px solid rgba(244,67,54,.2)",
          }}
        >
          ⚠ {errMsg} —{" "}
          <span
            style={{ textDecoration: "underline", cursor: "pointer" }}
            onClick={() => {
              setErrMsg(null);
              initHls(src);
            }}
          >
            Retry
          </span>
        </div>
      )}
    </div>
  );
};

/* ─────────────────────────────────────────────────────────────
   Status Badge Component
───────────────────────────────────────────────────────────── */
const StatusBadge = ({ status }) => {
  const cfg = getStatusCfg(status);
  return (
    <span
      className="ud-tag"
      style={{
        background: cfg.bg,
        color: cfg.color,
        border: `0.5px solid ${cfg.border}`,
      }}
    >
      {cfg.label}
    </span>
  );
};

/* ─────────────────────────────────────────────────────────────
   Field Component
───────────────────────────────────────────────────────────── */
const Field = ({ icon, label, children, mono, wide }) => (
  <div className="ud-field" style={wide ? { gridColumn: "1 / -1" } : {}}>
    <div className="ud-field-label">
      {icon && <span style={{ fontSize: 10 }}>{icon}</span>}
      {label}
    </div>
    <div
      className="ud-field-val"
      style={
        mono
          ? { fontFamily: "monospace", fontSize: 11, wordBreak: "break-all" }
          : {}
      }
    >
      {children}
    </div>
  </div>
);

/* ─────────────────────────────────────────────────────────────
   Main Component
───────────────────────────────────────────────────────────── */
const UploadDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  const [activeTab, setActiveTab] = useState("overview");
  const [copySuccess, setCopySuccess] = useState("");
  const [imgModal, setImgModal] = useState({
    open: false,
    url: null,
    title: null,
  });

  // ✅ CORRECT: Use useUploadDetails hook for fetching single upload details
  const {
    data: uploadDetails,
    isLoading: detailsLoading,
    error: detailsError,
    refetch: refetchDetails,
  } = useUploadDetails(id);

  // Extract upload data from response
  const upload = uploadDetails?.data?.upload || uploadDetails?.upload || null;

  // const getAsset = (role) => upload?.assets?.find((a) => a.assetRole === role) || null;

  const getAsset = (role) => {
    if (!upload?.assets) return null;

    const roleAssets = upload.assets.filter((a) => a.assetRole === role);
    if (roleAssets.length === 0) return null;

    // pehle isLatest:true dhundo
    const latest = roleAssets.find((a) => a.isLatest === true);
    if (latest) return latest;

    // fallback — highest version wala lo
    return roleAssets.reduce(
      (max, a) => ((a.version || 0) > (max.version || 0) ? a : max),
      roleAssets[0],
    );
  };

  const mainAsset = getAsset("MAIN");
  const thumbnailAsset = getAsset("THUMBNAIL");
  const trailerAsset = getAsset("TRAILER");

  const handleCopy = (text, key) => {
    navigator.clipboard.writeText(text);
    setCopySuccess(key);
    setTimeout(() => setCopySuccess(""), 2000);
  };

  const openImgModal = (url, title) => {
    setImgModal({ open: true, url, title });
    document.body.style.overflow = "hidden";
  };

  const closeImgModal = () => {
    setImgModal({ open: false, url: null, title: null });
    document.body.style.overflow = "";
  };

  // const isPlayable = (asset) => {
  //   if (!asset) return false;
  //   const url = asset.masterPlaylistUrl;
  //   const st = asset.status;
  //   return !!url && ["APPROVED", "UPLOADED", "PUBLISHED"].includes((st || "").toUpperCase());
  // };

  const isPlayable = (asset) => {
    if (!asset) return false;
    const url = asset.masterPlaylistUrl;
    const st = (asset.status || "").toUpperCase();
    return (
      !!url &&
      ["APPROVED", "PENDING_APPROVAL", "UPLOADED", "PUBLISHED"].includes(st)
    );
  };

  const getPlayUrl = (asset) => {
    if (!asset) return null;
    return asset.masterPlaylistUrl;
  };

  // Loading state
  if (detailsLoading) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#0d0a07",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: 14,
        }}
      >
        <div
          style={{
            width: 40,
            height: 40,
            border: "3px solid rgba(245,199,122,.15)",
            borderTop: "3px solid #f5c77a",
            borderRadius: "50%",
            animation: "ud-spin .8s linear infinite",
          }}
        />
        <p
          style={{
            fontSize: 12,
            color: "rgba(255,255,255,.3)",
            fontFamily: "'DM Sans',sans-serif",
          }}
        >
          Loading details...
        </p>
      </div>
    );
  }

  // Error state
  if (detailsError) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#0d0a07",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: 12,
          color: "#ef9a9a",
          fontFamily: "'DM Sans',sans-serif",
        }}
      >
        <span style={{ fontSize: 40 }}>⚠</span>
        <p style={{ fontSize: 13 }}>
          Error: {detailsError?.message || "Failed to load"}
        </p>
        <p style={{ fontSize: 12, color: "rgba(255,255,255,.5)" }}>
          Upload ID: {id}
        </p>
        <button className="ud-submit-btn" onClick={() => refetchDetails()}>
          Try Again
        </button>
        <button
          className="ud-back-btn"
          onClick={() => navigate(-1)}
          style={{ marginTop: 8 }}
        >
          Go Back
        </button>
      </div>
    );
  }

  // Not found state
  if (!upload) {
    return (
      <div
        style={{
          minHeight: "100vh",
          background: "#0d0a07",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          flexDirection: "column",
          gap: 12,
          color: "#ef9a9a",
          fontFamily: "'DM Sans',sans-serif",
        }}
      >
        <span style={{ fontSize: 40 }}>📭</span>
        <p style={{ fontSize: 13 }}>Upload not found</p>
        <p style={{ fontSize: 12, color: "rgba(255,255,255,.3)" }}>ID: {id}</p>
        <button className="ud-back-btn" onClick={() => navigate(-1)}>
          ← Go Back
        </button>
      </div>
    );
  }

  const meta = upload.metadata || {};
  const tabs = [
    { key: "overview", label: "Overview" },
    { key: "preview", label: "Preview" },
  ];

  return (
    <div
      style={{
        minHeight: "100vh",
        color: "#e8e0d0",
        fontFamily: "'DM Sans',sans-serif",
        paddingBottom: 60,
      }}
    >
      {/* Hero Banner */}
      <div style={{ position: "relative", height: 260, overflow: "hidden" }}>
        {thumbnailAsset?.masterPlaylistUrl ? (
          <img
            src={thumbnailAsset.masterPlaylistUrl}
            alt=""
            style={{
              width: "100%",
              height: "100%",
              objectFit: "cover",
              filter: "brightness(.35) saturate(.7)",
            }}
          />
        ) : (
          <div
            style={{
              height: "100%",
              background: "linear-gradient(135deg,#1a100a,#0d0a07)",
            }}
          />
        )}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background:
              "linear-gradient(to bottom, rgba(13,10,7,0.1) 0%, rgba(13,10,7,0.85) 80%, #0d0a07 100%)",
          }}
        />

        <div
          style={{
            position: "absolute",
            bottom: 24,
            left: 0,
            right: 0,
            padding: "0 28px",
            maxWidth: 1200,
            margin: "0 auto",
          }}
        >
          <div
            style={{
              display: "flex",
              alignItems: "flex-end",
              justifyContent: "space-between",
              flexWrap: "wrap",
              gap: 14,
            }}
          >
            <div>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 8,
                  marginBottom: 6,
                }}
              >
                <span style={{ fontSize: 22 }}>{contentIcon(upload.type)}</span>
                <span
                  style={{
                    fontSize: 11,
                    color: "rgba(255,255,255,.4)",
                    letterSpacing: 1,
                    textTransform: "uppercase",
                  }}
                >
                  {upload.type}
                </span>
                <StatusBadge status={upload.status} />
              </div>
              <h1
                style={{
                  fontFamily: "'Bebas Neue',Impact,sans-serif",
                  fontSize: 42,
                  letterSpacing: 2,
                  color: "#fff",
                  margin: 0,
                  lineHeight: 1,
                  textShadow: "0 2px 12px rgba(0,0,0,.8)",
                }}
              >
                {upload.title}
              </h1>
              <div
                style={{
                  display: "flex",
                  gap: 10,
                  marginTop: 8,
                  flexWrap: "wrap",
                }}
              >
                {meta.releaseYear && (
                  <span style={{ fontSize: 12, color: "rgba(255,255,255,.5)" }}>
                    {meta.releaseYear}
                  </span>
                )}
                {meta.rating && (
                  <span style={{ fontSize: 12, color: "#ffd54f" }}>
                    ★ {meta.rating}/10
                  </span>
                )}
                {meta.duration && (
                  <span style={{ fontSize: 12, color: "rgba(255,255,255,.5)" }}>
                    {meta.duration} min
                  </span>
                )}
                {meta.ageRating && (
                  <span style={{ fontSize: 12, color: "rgba(255,255,255,.5)" }}>
                    {meta.ageRating}
                  </span>
                )}
                {upload.defaultLanguage && (
                  <span style={{ fontSize: 12, color: "rgba(255,255,255,.5)" }}>
                    🌐 {upload.defaultLanguage}
                  </span>
                )}
              </div>
            </div>

            {/* Refresh button */}
            <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
              <button
                className="ud-refresh-btn"
                onClick={() => refetchDetails()}
              >
                ↻ Refresh
              </button>
            </div>
          </div>
        </div>

        <div style={{ position: "absolute", top: 20, left: 28 }}>
          <button className="ud-back-btn" onClick={() => navigate(-1)}>
            ← Back
          </button>
        </div>
      </div>

      {/* Page Body */}
      <div style={{ maxWidth: 1200, margin: "0 auto", padding: "0 28px" }}>
        {/* Tabs */}
        <div
          style={{
            display: "flex",
            gap: 0,
            borderBottom: "0.5px solid rgba(255,255,255,.08)",
            marginBottom: 24,
            overflowX: "auto",
          }}
        >
          {tabs.map((t) => (
            <button
              key={t.key}
              className={`ud-tab-btn${activeTab === t.key ? " active" : ""}`}
              onClick={() => setActiveTab(t.key)}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Overview Tab */}
        {activeTab === "overview" && (
          <div className="ud-animate">
            {upload.description && (
              <div className="ud-card" style={{ marginBottom: 16 }}>
                <p
                  style={{
                    fontSize: 10,
                    letterSpacing: 0.8,
                    textTransform: "uppercase",
                    color: "rgba(255,255,255,.35)",
                    marginBottom: 8,
                  }}
                >
                  Description
                </p>
                <p
                  style={{
                    fontSize: 14,
                    color: "rgba(255,255,255,.7)",
                    lineHeight: 1.65,
                    margin: 0,
                  }}
                >
                  {upload.description}
                </p>
              </div>
            )}

            <div className="ud-card" style={{ marginBottom: 16 }}>
              <p
                style={{
                  fontSize: 10,
                  letterSpacing: 0.8,
                  textTransform: "uppercase",
                  color: "rgba(255,255,255,.35)",
                  marginBottom: 12,
                }}
              >
                Details
              </p>
              <div className="ud-info-grid">
                {meta.director && (
                  <Field icon="🎬" label="Director">
                    {meta.director}
                  </Field>
                )}
                {meta.producer && (
                  <Field icon="🎥" label="Producer">
                    {meta.producer}
                  </Field>
                )}
                {meta.slug && (
                  <Field icon="🔗" label="Slug">
                    <span style={{ fontFamily: "monospace", fontSize: 12 }}>
                      {meta.slug}
                    </span>
                  </Field>
                )}
                {upload.contentKind && (
                  <Field icon="📂" label="Content Kind">
                    {upload.contentKind}
                  </Field>
                )}
                {upload.genreName && (
                  <Field icon="🏷" label="Genre ID" mono>
                    {upload.genreName}
                  </Field>
                )}
                {upload.languageName && (
                  <Field icon="🌐" label="Language ID" mono>
                    {upload.languageName}
                  </Field>
                )}
                {upload.defaultLanguage && (
                  <Field icon="🗣️" label="Default Language">
                    {upload.defaultLanguage}
                  </Field>
                )}
                <Field icon="📅" label="Created">
                  {fmtDate(upload.createdAt)}
                </Field>
                <Field icon="🔄" label="Updated">
                  {fmtDate(upload.updatedAt)}
                </Field>
                {meta.shortDescription && (
                  <Field icon="📝" label="Short Description" wide>
                    {meta.shortDescription}
                  </Field>
                )}
              </div>
            </div>

            {(meta.cast?.length > 0 || meta.tags?.length > 0) && (
              <div className="ud-card" style={{ marginBottom: 16 }}>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fill,minmax(250px,1fr))",
                    gap: 16,
                  }}
                >
                  {meta.cast?.length > 0 && (
                    <div>
                      <p
                        style={{
                          fontSize: 10,
                          letterSpacing: 0.8,
                          textTransform: "uppercase",
                          color: "rgba(255,255,255,.35)",
                          marginBottom: 10,
                        }}
                      >
                        Cast ({meta.cast.length})
                      </p>
                      <div
                        style={{ display: "flex", flexWrap: "wrap", gap: 6 }}
                      >
                        {meta.cast.map((c, i) => (
                          <span
                            key={i}
                            className="ud-tag"
                            style={{
                              background: "rgba(245,199,122,.08)",
                              color: "#f5c77a",
                              border: "0.5px solid rgba(245,199,122,.2)",
                              fontSize: 11,
                            }}
                          >
                            {c}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                  {meta.tags?.length > 0 && (
                    <div>
                      <p
                        style={{
                          fontSize: 10,
                          letterSpacing: 0.8,
                          textTransform: "uppercase",
                          color: "rgba(255,255,255,.35)",
                          marginBottom: 10,
                        }}
                      >
                        Tags ({meta.tags.length})
                      </p>
                      <div
                        style={{ display: "flex", flexWrap: "wrap", gap: 6 }}
                      >
                        {meta.tags.map((t, i) => (
                          <span
                            key={i}
                            className="ud-tag"
                            style={{
                              background: "rgba(76,175,80,.08)",
                              color: "#81c784",
                              border: "0.5px solid rgba(76,175,80,.2)",
                              fontSize: 11,
                            }}
                          >
                            #{t}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {upload.errorMessage && (
              <div
                style={{
                  background: "rgba(244,67,54,.08)",
                  border: "0.5px solid rgba(244,67,54,.3)",
                  borderRadius: 10,
                  padding: "12px 16px",
                  marginBottom: 16,
                }}
              >
                <p
                  style={{
                    fontSize: 10,
                    color: "#ef9a9a",
                    textTransform: "uppercase",
                    letterSpacing: 0.8,
                    marginBottom: 6,
                  }}
                >
                  ⚠ Error Message
                </p>
                <code
                  style={{
                    fontSize: 11,
                    color: "rgba(244,67,54,.8)",
                    display: "block",
                    whiteSpace: "pre-wrap",
                    wordBreak: "break-all",
                  }}
                >
                  {upload.errorMessage}
                </code>
              </div>
            )}
          </div>
        )}

        {/* Preview Tab */}
        {activeTab === "preview" && (
          <div className="ud-animate">
            {/* Thumbnail */}
            <div className="ud-card" style={{ marginBottom: 16 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  marginBottom: 12,
                  flexWrap: "wrap",
                }}
              >
                <p
                  style={{
                    fontSize: 10,
                    letterSpacing: 0.8,
                    textTransform: "uppercase",
                    color: "rgba(255,255,255,.35)",
                    margin: 0,
                  }}
                >
                  🖼️ Thumbnail
                </p>
                <StatusBadge status={thumbnailAsset?.status} />
              </div>

              {thumbnailAsset?.masterPlaylistUrl ? (
                <div
                  style={{
                    position: "relative",
                    cursor: "pointer",
                    borderRadius: 10,
                    overflow: "hidden",
                    maxHeight: 280,
                  }}
                  onClick={() =>
                    openImgModal(thumbnailAsset.masterPlaylistUrl, "Thumbnail")
                  }
                >
                  <img
                    src={thumbnailAsset.masterPlaylistUrl}
                    alt="Thumbnail"
                    style={{
                      width: "100%",
                      maxHeight: 280,
                      objectFit: "cover",
                      display: "block",
                    }}
                  />
                  <div
                    style={{
                      position: "absolute",
                      inset: 0,
                      background: "rgba(0,0,0,0)",
                      transition: "background .2s",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = "rgba(0,0,0,.45)";
                      e.currentTarget.querySelector("span").style.opacity = "1";
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = "rgba(0,0,0,0)";
                      e.currentTarget.querySelector("span").style.opacity = "0";
                    }}
                  >
                    <span
                      style={{
                        fontSize: 13,
                        background: "#f5c77a",
                        color: "#0f0a0a",
                        padding: "6px 16px",
                        borderRadius: 6,
                        fontWeight: 500,
                        opacity: 0,
                        transition: "opacity .2s",
                      }}
                    >
                      ⛶ Expand
                    </span>
                  </div>
                </div>
              ) : (
                <div
                  style={{
                    textAlign: "center",
                    padding: "40px 0",
                    color: "rgba(255,255,255,.2)",
                    fontSize: 13,
                  }}
                >
                  No thumbnail available
                </div>
              )}
            </div>

            {/* Main Video */}
            <div className="ud-card" style={{ marginBottom: 16 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  marginBottom: 14,
                  flexWrap: "wrap",
                }}
              >
                <p
                  style={{
                    fontSize: 10,
                    letterSpacing: 0.8,
                    textTransform: "uppercase",
                    color: "rgba(255,255,255,.35)",
                    margin: 0,
                  }}
                >
                  🎬 Main Video
                </p>
                {mainAsset && <StatusBadge status={mainAsset.status} />}
              </div>

              {mainAsset ? (
                isPlayable(mainAsset) ? (
                  <HLSPlayer
                    src={getPlayUrl(mainAsset)}
                    poster={thumbnailAsset?.masterPlaylistUrl}
                    title={upload.title}
                  />
                ) : (
                  <div
                    style={{
                      background: "#1a130e",
                      borderRadius: 10,
                      padding: "24px 20px",
                      textAlign: "center",
                    }}
                  >
                    <p style={{ fontSize: 12, color: "rgba(255,255,255,.35)" }}>
                      🕐 Video is still processing — playback will be available
                      once complete.
                    </p>
                    <p style={{ fontSize: 11, color: "#f5c77a", marginTop: 8 }}>
                      Status: {mainAsset.status}
                    </p>
                  </div>
                )
              ) : (
                <div
                  style={{
                    textAlign: "center",
                    padding: "40px 0",
                    color: "rgba(255,255,255,.2)",
                    fontSize: 13,
                  }}
                >
                  No main video uploaded
                </div>
              )}
            </div>

            {/* Trailer */}
            {trailerAsset && (
              <div className="ud-card">
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    marginBottom: 14,
                    flexWrap: "wrap",
                  }}
                >
                  <p
                    style={{
                      fontSize: 10,
                      letterSpacing: 0.8,
                      textTransform: "uppercase",
                      color: "rgba(255,255,255,.35)",
                      margin: 0,
                    }}
                  >
                    ▷ Trailer
                  </p>
                  <StatusBadge status={trailerAsset.status} />
                </div>

                {isPlayable(trailerAsset) ? (
                  <HLSPlayer
                    src={getPlayUrl(trailerAsset)}
                    poster={thumbnailAsset?.masterPlaylistUrl}
                    title={`${upload.title} — Trailer`}
                  />
                ) : (
                  <div
                    style={{
                      background: "#1a130e",
                      borderRadius: 10,
                      padding: "24px 20px",
                      textAlign: "center",
                    }}
                  >
                    <p style={{ fontSize: 12, color: "rgba(255,255,255,.35)" }}>
                      🕐 Trailer is still processing…
                    </p>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Image Modal */}
      {imgModal.open && (
        <div className="ud-modal-overlay" onClick={closeImgModal}>
          <div
            className="ud-img-modal-box"
            onClick={(e) => e.stopPropagation()}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "14px 18px",
                borderBottom: "0.5px solid rgba(255,255,255,.06)",
              }}
            >
              <span
                style={{
                  fontFamily: "'Bebas Neue',sans-serif",
                  fontSize: 20,
                  letterSpacing: 1.5,
                  color: "#f5c77a",
                }}
              >
                {imgModal.title}
              </span>
              <button
                onClick={closeImgModal}
                style={{
                  width: 30,
                  height: 30,
                  borderRadius: 6,
                  background: "rgba(255,255,255,.06)",
                  border: "0.5px solid rgba(255,255,255,.1)",
                  color: "rgba(255,255,255,.6)",
                  cursor: "pointer",
                  fontSize: 14,
                }}
              >
                ✕
              </button>
            </div>
            <div
              style={{
                padding: 16,
                background: "#000",
                maxHeight: "75vh",
                overflowY: "auto",
              }}
            >
              <img
                src={imgModal.url}
                alt={imgModal.title}
                style={{
                  width: "100%",
                  maxHeight: "70vh",
                  objectFit: "contain",
                  borderRadius: 8,
                }}
              />
            </div>
            <div
              style={{
                padding: "10px 18px",
                borderTop: "0.5px solid rgba(255,255,255,.06)",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <button
                className="ud-copy-btn"
                onClick={() => handleCopy(imgModal.url, "modal-url")}
              >
                {copySuccess === "modal-url" ? "✓ Copied" : "Copy URL"}
              </button>
              <button
                className="ud-submit-btn"
                style={{ padding: "6px 18px", fontSize: 12 }}
                onClick={closeImgModal}
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default UploadDetails;
