import express from "express";
const router = express.Router();
import * as streController from "../controllers/streamController.js";
import * as stremHomeController from "../controllers/streamHomeController.js";
import { authMiddleware } from "../middleware/authMiddleware.js";

router.get("/videos", authMiddleware, streController.getPublishedVideos);
router.get(
  "/videos/genre/:profileId",
  authMiddleware,
  streController.getHomeContentByProfile,
);
router.get("/videos/:videoId", authMiddleware, streController.getVideoDetail);
// router.get("/videos/:videoId", authMiddleware, streController.getVideoDetail);
router.post("/videos/:id/play", authMiddleware, streController.getPlayUrl);
router.post(
  "/videos/:id/progress",
  authMiddleware,
  streController.saveWatchProgress,
);


router.post("/session/end", authMiddleware, streController.endStreamingSession);
router.post("/history", authMiddleware, streController.getWatchHistory);


router.post("/content/continue-watching", authMiddleware, stremHomeController.getContinueWatching); 
 

 
router.post("/content/:profileId/top10", authMiddleware, stremHomeController.getTop10);
router.post("/content/:profileId/newly-added", authMiddleware, stremHomeController.getNewlyAdded);
router.post("/content/:profileId/genres", authMiddleware, stremHomeController.getSelectedGenres);
router.post(
  "/content/:profileId/featured",
  authMiddleware,
  stremHomeController.getFeaturedContent
);



// webseries routes--
router.get("/webseries/:id", authMiddleware, streController.getWebSeriesDetailById);
export default router;
