import React, { useState } from "react";
import { Box, Typography, Tabs, Tab, Paper } from "@mui/material";
import UploadPage from "../components/CreatorStudio/UploadPage";

import { COLORS } from "../theme/theme";

const CreatorStudioPage = () => {

  return (
    <Box>
      <Typography variant="h5" sx={{ fontWeight: 700, color: COLORS.primary, mb: 3 }}>
        Creator Studio
      </Typography>

      <Paper sx={{ background: COLORS.background, borderRadius: "20px", border: `1px solid ${COLORS.primary}20` }}>
        
  
        <Box sx={{ p: 3 }}>
      <UploadPage />
        
        </Box>
      </Paper>
    </Box>
  );
};

export default CreatorStudioPage;