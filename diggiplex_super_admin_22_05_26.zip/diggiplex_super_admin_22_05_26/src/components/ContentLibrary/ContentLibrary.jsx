// src/components/ContentLibrary/ContentLibrary.jsx
import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";

// Clean Color scheme
const COLORS = {
  primary: "#f5c77a",
  primaryDark: "#c49a4e",
  background: "rgba(15, 10, 10, 0.85)",
  surface: "#1C1616",
  surfaceLight: "#231D1D",
  text: "#FFFFFF",
  textSecondary: "#B3B3B3",
  textMuted: "#6B6B6B",
  success: "#4caf7d",
  error: "#f44336",
  warning: "#ff9800",
  border: "rgba(245,199,122,0.125)",
};

const VIDEOS = [
  { title: "Cinematic Travel Vlog — Bali 2024", date: "Dec 12, 2024", views: "284K", duration: "18:42", status: "Approved", thumb: "🏝", category: "Travel" },
  { title: "Complete React + TypeScript Course", date: "Dec 10, 2024", views: "156K", duration: "2:14:08", status: "Approved", thumb: "💻", category: "Tech" },
  { title: "Street Food Tour — Mumbai Night Life", date: "Dec 8, 2024", views: "98K", duration: "24:16", status: "Pending", thumb: "🍜", category: "Food" },
  { title: "Productivity System for Creators", date: "Dec 5, 2024", views: "62K", duration: "31:22", status: "Approved", thumb: "📋", category: "Lifestyle" },
  { title: "Behind the Camera — My Studio Tour", date: "Dec 3, 2024", views: "41K", duration: "22:58", status: "Rejected", thumb: "📷", category: "Tech" },
  { title: "Indian Classical Music Masterclass", date: "Nov 28, 2024", views: "38K", duration: "48:10", status: "Approved", thumb: "🎵", category: "Music" },
  { title: "Startup Funding: What Investors Look For", date: "Nov 22, 2024", views: "72K", duration: "28:44", status: "Approved", thumb: "💼", category: "Finance" },
  { title: "Morning Routine for High Performers", date: "Nov 18, 2024", views: "54K", duration: "16:30", status: "Pending", thumb: "☀️", category: "Lifestyle" },
  { title: "Building a SaaS App from Scratch", date: "Nov 14, 2024", views: "29K", duration: "1:42:05", status: "Approved", thumb: "🚀", category: "Tech" },
];

const STATUS_STYLES = {
  Approved: { bg: "rgba(76,175,125,0.1)", color: COLORS.success },
  Pending: { bg: "rgba(245,199,122,0.1)", color: COLORS.primary },
  Rejected: { bg: "rgba(244,67,54,0.1)", color: COLORS.error },
};

// Compact Video Card Component
const VideoCard = ({ video, onEdit, onAnalytics }) => {
  const st = STATUS_STYLES[video.status];

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <div 
        className="rounded-lg overflow-hidden transition-all duration-200 hover:shadow-lg"
        style={{ 
          backgroundColor: COLORS.surface,
          border: `1px solid ${COLORS.border}`,
        }}
      >
        <div className="flex">
          {/* Thumbnail */}
          <div className="w-28 h-28 flex-shrink-0 flex items-center justify-center text-3xl" style={{ backgroundColor: COLORS.surfaceLight }}>
            {video.thumb}
          </div>
          
          {/* Content */}
          <div className="flex-1 p-3">
            <div className="flex justify-between items-start gap-2">
              <h3 className="text-sm font-medium line-clamp-2 flex-1" style={{ color: COLORS.text }}>
                {video.title}
              </h3>
              <button className="p-1 rounded hover:bg-white/5 transition-colors">
                <svg className="w-3.5 h-3.5" style={{ color: COLORS.textMuted }} fill="currentColor" viewBox="0 0 20 20">
                  <path d="M10 6a2 2 0 110-4 2 2 0 010 4zM10 12a2 2 0 110-4 2 2 0 010 4zM10 18a2 2 0 110-4 2 2 0 010 4z" />
                </svg>
              </button>
            </div>
            
            <div className="flex items-center gap-3 mt-1.5 text-xs" style={{ color: COLORS.textMuted }}>
              <span>{video.category}</span>
              <span>•</span>
              <span>{video.date}</span>
            </div>
            
            <div className="flex items-center justify-between mt-2">
              <div className="flex items-center gap-2 text-xs">
                <div className="flex items-center gap-1">
                  <svg className="w-3 h-3" style={{ color: COLORS.textMuted }} fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                    <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                  </svg>
                  <span style={{ color: COLORS.textSecondary }}>{video.views}</span>
                </div>
                <div className="flex items-center gap-1">
                  <svg className="w-3 h-3" style={{ color: COLORS.textMuted }} fill="currentColor" viewBox="0 0 20 20">
                    <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd" />
                  </svg>
                  <span style={{ color: COLORS.textSecondary }}>{video.duration}</span>
                </div>
              </div>
              <span 
                className="text-xs px-2 py-0.5 rounded-full font-medium"
                style={{ 
                  backgroundColor: st.bg,
                  color: st.color
                }}
              >
                {video.status}
              </span>
            </div>
            
            {/* Actions */}
            <div className="flex gap-2 mt-2.5">
              <button
                onClick={() => onEdit && onEdit(video)}
                className="flex-1 flex items-center justify-center gap-1 px-2 py-1 rounded text-xs font-medium transition-all hover:opacity-80"
                style={{ 
                  backgroundColor: `${COLORS.primary}15`,
                  color: COLORS.primary
                }}
              >
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                </svg>
                Edit
              </button>
              <button
                onClick={() => onAnalytics && onAnalytics(video)}
                className="flex-1 flex items-center justify-center gap-1 px-2 py-1 rounded text-xs font-medium transition-all hover:opacity-80"
                style={{ 
                  backgroundColor: `${COLORS.textMuted}15`,
                  color: COLORS.textSecondary
                }}
              >
                <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
                </svg>
                Analytics
              </button>
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

// Main Component
export default function ContentLibrary({ searchQuery = "", viewMode = "grid", onNotification }) {
  const [statusFilter, setStatusFilter] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");

  const effectiveSearch = searchQuery !== undefined ? searchQuery : searchTerm;

  const filteredVideos = VIDEOS.filter(video => {
    const matchesSearch = effectiveSearch === "" || 
      video.title.toLowerCase().includes(effectiveSearch.toLowerCase()) ||
      video.category.toLowerCase().includes(effectiveSearch.toLowerCase());
    const matchesStatus = statusFilter === "all" || 
      video.status.toLowerCase() === statusFilter.toLowerCase();
    return matchesSearch && matchesStatus;
  });

  const stats = {
    all: VIDEOS.length,
    approved: VIDEOS.filter(v => v.status === "Approved").length,
    pending: VIDEOS.filter(v => v.status === "Pending").length,
    rejected: VIDEOS.filter(v => v.status === "Rejected").length,
  };

  const handleEdit = (video) => {
    if (onNotification) onNotification(`Editing: ${video.title}`, "info");
  };

  const handleAnalytics = (video) => {
    if (onNotification) onNotification(`Analytics for: ${video.title}`, "info");
  };

  const statItems = [
    { label: "All", count: stats.all, value: "all" },
    { label: "Approved", count: stats.approved, value: "approved" },
    { label: "Pending", count: stats.pending, value: "pending" },
    { label: "Rejected", count: stats.rejected, value: "rejected" },
  ];

  return (
    <div>
      {/* Search and Filters */}
      <div className="flex flex-wrap gap-3 items-center justify-between mb-5">
        <div className="flex gap-2 flex-wrap">
          {statItems.map(({ label, count, value }) => (
            <button
              key={label}
              onClick={() => setStatusFilter(value)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                statusFilter === value 
                  ? "bg-[#f5c77a] text-[#1C1616]" 
                  : "hover:bg-white/5"
              }`}
              style={{ 
                backgroundColor: statusFilter === value ? COLORS.primary : "transparent",
                color: statusFilter === value ? COLORS.background : COLORS.textSecondary,
                border: statusFilter === value ? "none" : `1px solid ${COLORS.border}`
              }}
            >
              {label} ({count})
            </button>
          ))}
        </div>

        {searchQuery === undefined && (
          <div className="relative">
            <input
              type="text"
              placeholder="Search videos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-8 pr-3 py-1.5 text-sm rounded-lg border outline-none focus:border-[#f5c77a] transition-colors"
              style={{
                backgroundColor: COLORS.surface,
                borderColor: COLORS.border,
                color: COLORS.text,
                width: "200px"
              }}
            />
            <svg className="absolute left-2.5 top-1/2 transform -translate-y-1/2 w-3.5 h-3.5" style={{ color: COLORS.textMuted }} fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M8 4a4 4 0 100 8 4 4 0 000-8zM2 8a6 6 0 1110.89 3.476l4.817 4.817a1 1 0 01-1.414 1.414l-4.816-4.816A6 6 0 012 8z" clipRule="evenodd" />
            </svg>
          </div>
        )}
      </div>

      {/* Videos Grid */}
      {filteredVideos.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-4xl mb-2 opacity-50">📭</div>
          <p className="text-sm" style={{ color: COLORS.textMuted }}>No videos found</p>
        </div>
      ) : (
        <>
          <div className="space-y-2">
            <AnimatePresence>
              {filteredVideos.map((video, idx) => (
                <VideoCard
                  key={idx}
                  video={video}
                  onEdit={handleEdit}
                  onAnalytics={handleAnalytics}
                />
              ))}
            </AnimatePresence>
          </div>

          <div className="mt-4 text-center">
            <p className="text-xs" style={{ color: COLORS.textMuted }}>
              Showing {filteredVideos.length} of {VIDEOS.length} videos
            </p>
          </div>
        </>
      )}
    </div>
  );
}