// src/pages/User.jsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useGetUsers } from "../Hook/useUser";

const User = () => {
  const navigate = useNavigate();
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(10);

  const {
    data: usersData,
    isLoading,
    isError,
    error: fetchError,
    refetch,
  } = useGetUsers(currentPage, itemsPerPage);

  const users = usersData?.data?.users || [];
  const pagination = usersData?.data?.pagination || {
    total: 0,
    page: 1,
    limit: itemsPerPage,
    totalPages: 1,
  };
  const totalPages = pagination.totalPages || 1;

  const formatDate = (dateString) => {
    if (!dateString) return "N/A";
    return new Date(dateString).toLocaleString();
  };

  const getAuthProviderLabel = (provider) => {
    if (provider === "PHONE") return "Phone Number";
    if (provider === "EMAIL") return "Email";
    if (provider === "GOOGLE") return "Google";
    return provider || "Unknown";
  };

  return (
    <div
      className="w-full overflow-hidden"
      style={{ background: "rgba(15, 10, 10, 0.85)", minHeight: "100vh" }}
    >
      <div className="w-full max-w-full px-4 py-8">

        {/* Header */}
        <div className="mb-6">
          <h5 className="text-xl font-bold text-[#f5c77a]">User Management</h5>
          <p className="text-[#B3B3B3] text-sm mt-1">View and manage registered users</p>
        </div>

        {/* Table Card */}
        <div className="bg-[#1C1616] rounded-lg border border-[rgba(245,199,122,0.125)] min-w-0">

          <div className="p-4 border-b border-[rgba(255,255,255,0.07)]">
            <h6 className="text-lg font-semibold text-[#f5c77a]">Users List</h6>
            <p className="text-[#B3B3B3] text-sm mt-1">Total Users: {pagination.total || 0}</p>
          </div>

          <div className="overflow-x-auto">
            {isLoading ? (
              <div className="flex justify-center items-center py-12">
                <svg className="animate-spin h-8 w-8 text-[#f5c77a]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              </div>
            ) : isError ? (
              <div className="text-center py-12 text-red-400">
                <i className="fas fa-exclamation-triangle text-3xl mb-2 block"></i>
                <p>{fetchError?.message || "Failed to load users"}</p>
                <button
                  onClick={() => refetch()}
                  className="mt-4 px-4 py-2 bg-[#f5c77a] text-[#0F0A0A] rounded text-sm"
                >
                  Try Again
                </button>
              </div>
            ) : users?.length > 0 ? (
              <>
                <table className="w-full" style={{ minWidth: "700px" }}>
                  <thead className="bg-[#231D1D] border-b border-[rgba(255,255,255,0.07)]">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider w-12">S.No</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Email / Phone</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Auth Provider</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Verified</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Created At</th>
                      <th className="px-4 py-3 text-left text-xs font-semibold text-[#B3B3B3] uppercase tracking-wider">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[rgba(255,255,255,0.07)]">
                    {users.map((user, index) => (
                      <tr key={user.id} className="hover:bg-[rgba(245,199,122,0.05)] transition">
                        <td className="px-4 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                          {(currentPage - 1) * itemsPerPage + index + 1}
                        </td>
                        <td className="px-4 py-4 text-sm text-white whitespace-nowrap">
                          <div>
                            {user.email && (
                              <div className="flex items-center gap-1">
                                <i className="fas fa-envelope text-xs text-[#B3B3B3]"></i>
                                <span>{user.email}</span>
                              </div>
                            )}
                            {user.phone && (
                              <div className="flex items-center gap-1 text-xs text-[#B3B3B3] mt-1">
                                <i className="fas fa-phone text-xs"></i>
                                <span>{user.phone}</span>
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="px-4 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                          <span className="px-2 py-1 text-xs rounded-full bg-[rgba(156,39,176,0.15)] text-[#ce93d8] border border-[rgba(156,39,176,0.3)]">
                            <i className="fas fa-id-card mr-1"></i> {getAuthProviderLabel(user.auth_provider)}
                          </span>
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          {user.isActive ? (
                            <span className="px-2 py-1 text-xs rounded-full bg-[rgba(76,175,80,0.15)] text-[#4caf7d] border border-[rgba(76,175,80,0.3)]">
                              <i className="fas fa-check-circle mr-1"></i> Active
                            </span>
                          ) : (
                            <span className="px-2 py-1 text-xs rounded-full bg-[rgba(244,67,54,0.15)] text-[#f44336] border border-[rgba(244,67,54,0.3)]">
                              <i className="fas fa-ban mr-1"></i> Inactive
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-4 whitespace-nowrap">
                          {user.isVerified ? (
                            <span className="px-2 py-1 text-xs rounded-full bg-[rgba(76,175,80,0.15)] text-[#4caf7d] border border-[rgba(76,175,80,0.3)]">
                              <i className="fas fa-check-circle mr-1"></i> Verified
                            </span>
                          ) : (
                            <span className="px-2 py-1 text-xs rounded-full bg-[rgba(255,152,0,0.15)] text-[#ff9800] border border-[rgba(255,152,0,0.3)]">
                              <i className="fas fa-clock mr-1"></i> Pending
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-4 text-sm text-[#B3B3B3] whitespace-nowrap">
                          {formatDate(user.createdAt)}
                        </td>

                        {/* ✅ View Details → navigate to /user_details/:id */}
                        <td className="px-4 py-4 whitespace-nowrap">
                          <button
                            onClick={() => navigate(`/user_details/${user.id}`)}
                            className="px-3 py-1 text-xs bg-[rgba(33,150,243,0.15)] text-[#2196f3] rounded hover:bg-[rgba(33,150,243,0.25)] transition flex items-center gap-1"
                          >
                            <i className="fas fa-eye"></i> View Details
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div className="flex justify-center gap-2 py-4 border-t border-[rgba(255,255,255,0.07)]">
                    <button
                      onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                      disabled={currentPage === 1}
                      className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                    >
                      Previous
                    </button>
                    {[...Array(totalPages)].map((_, i) => (
                      <button
                        key={i}
                        onClick={() => setCurrentPage(i + 1)}
                        className={`px-3 py-1 text-sm rounded transition ${
                          currentPage === i + 1
                            ? "bg-[#f5c77a] text-[#0F0A0A]"
                            : "bg-[#231D1D] text-[#B3B3B3] hover:bg-[rgba(245,199,122,0.1)]"
                        }`}
                      >
                        {i + 1}
                      </button>
                    ))}
                    <button
                      onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                      disabled={currentPage === totalPages}
                      className="px-3 py-1 text-sm bg-[#231D1D] text-[#B3B3B3] rounded disabled:opacity-50 hover:bg-[rgba(245,199,122,0.1)] transition"
                    >
                      Next
                    </button>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-12 text-[#B3B3B3]">
                <i className="fas fa-users text-3xl mb-2 block"></i>
                <p>No Users found</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default User;