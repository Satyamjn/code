import React from 'react'

const CreatorList = () => {
  return (
    <div>
      CreatorList
    </div>
  )
}

export default CreatorList
