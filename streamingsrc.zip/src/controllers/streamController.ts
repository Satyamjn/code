import { and, desc, eq, sql, ilike, inArray } from "drizzle-orm";
import { randomUUID } from "crypto";
import { Request, Response } from "express";
import { asyncHandler } from "../utils/asyncHandler.js";
import { HTTP_STATUS } from "../constants/constant.js";
import ApiResponse from "../utils/ApiResponse.js";
import ApiError from "../utils/ApiError.js";
import {
  db,
  videos,
  videoAssets,
  watchHistory,
  streamingSessions,
  uploads,
  genres,
  profiles,
shows,      
  uploadAssets, 
} from "@digiiplex6112/db";

type UploadWithAssets = typeof uploads.$inferSelect & {
  assets: (typeof uploadAssets.$inferSelect)[];
};

type SeasonGroup = {
  seasonNumber: number;
  totalEpisodes: number;
  episodes: UploadWithAssets[];
};

type ShowDetailGroup = typeof shows.$inferSelect & {
  seasons: SeasonGroup[];
};

const getString = (val: any): string | null => {
  if (Array.isArray(val)) return val[0];
  return val ?? null;
};
export const getPublishedVideos = asyncHandler(
  async (req: Request, res: Response) => {
    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(50, Number(req.query.limit) || 10);
    const offset = (page - 1) * limit;

    const search =
      typeof req.query.search === "string" ? req.query.search.trim() : "";

    const where = and(
      eq(videos.status, "PUBLISHED"),
      search ? ilike(videos.title, `%${search}%`) : undefined,
    );

    const [rows, [{ count }]] = await Promise.all([
      db
        .select()
        .from(videos)
        .where(where)
        .orderBy(desc(videos.publishedAt))
        .limit(limit)
        .offset(offset),

      db
        .select({ count: sql<number>`cast(count(*) as int)` })
        .from(videos)
        .where(where),
    ]);

    const videoIds = rows.map((v) => v.id);

    const assets = videoIds.length
      ? await db
          .select()
          .from(videoAssets)
          .where(
            and(
              inArray(videoAssets.videoId, videoIds),
              eq(videoAssets.assetType, "MAIN"),
            ),
          )
      : [];

    const assetMap = new Map(assets.map((a) => [a.videoId, a]));

    const result = rows.map((v) => {
      const asset = assetMap.get(v.id);
      return {
        ...v,
        thumbnailUrl: asset?.thumbnailUrl ?? null,
        availableQualities: asset?.availableQualities ?? [],
      };
    });

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Videos fetched", {
        videos: result,
        pagination: {
          total: count,
          page,
          limit,
          totalPages: Math.ceil(count / limit),
        },
      }),
    );
  },
);

export const getVideoDetail = asyncHandler(
  async (req: Request, res: Response) => {
    const { videoId } = req.params;

    const video = await db
      .select()
      .from(videos)
      .where(
        and(eq(videos.id, videoId as string), eq(videos.status, "PUBLISHED")),
      )
      .limit(1)
      .then((res) => res[0]);

    if (!video) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Video not found");

    const assets = await db
      .select()
      .from(videoAssets)
      .where(eq(videoAssets.videoId, videoId as string));

    const mainAsset = assets.find((a) => a.assetType === "MAIN");
    const trailerAsset = assets.find((a) => a.assetType === "TRAILER");

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Video fetched", {
        video: {
          ...video,
          mainAsset: mainAsset ?? null,
          trailerAsset: trailerAsset ?? null,
        },
      }),
    );
  },
);


export const getPlayUrl = asyncHandler(async (req: Request, res: Response) => {
  const uploadId = getString(req.params.id);         
  const { assetType = "MAIN", deviceId, deviceInfo } = req.body;
  const userId = getString((req as any).user?.id);

  if (!uploadId) {
    throw new ApiError(HTTP_STATUS.BAD_REQUEST, "id is required");
  }

  const video = await db
    .select()
    .from(videos)
    .where(
      and(
        eq(videos.uploadId, uploadId),       // ← KEY FIX
        eq(videos.status, "PUBLISHED")
      )
    )
    .limit(1)
    .then((res) => res[0]);

  if (!video) {
    throw new ApiError(
      HTTP_STATUS.NOT_FOUND,
      "Video not found or not published"
    );
  }

  const asset = await db
    .select()
    .from(videoAssets)
    .where(
      and(
        eq(videoAssets.videoId, video.id),
        eq(videoAssets.assetType, assetType as any)
      )
    )
    .limit(1)
    .then((res) => res[0]);

  if (!asset) {
    throw new ApiError(HTTP_STATUS.NOT_FOUND, `${assetType} asset not found`);
  }

  let sessionToken: string | null = null;

  if (userId) {
    const token = randomUUID();

    await db.insert(streamingSessions).values({
      userId: userId,
      videoId: video.id,
      videoAssetId: asset.id,
      sessionToken: token,
      deviceId: getString(deviceId),
      deviceInfo: deviceInfo ?? {},
      clientIp: getString(req.ip),
    });

    sessionToken = token;
  }

  return res.status(HTTP_STATUS.OK).json(
    new ApiResponse(HTTP_STATUS.OK, "Play URL ready", {
      masterPlaylistUrl: asset.masterPlaylistUrl,
      streamingProtocol: asset.streamingProtocol,
      availableQualities: asset.availableQualities ?? [],
      drmEnabled: asset.drmEnabled,
      drmProvider: asset.drmProvider,
      videoAssetId: asset.id,
      sessionToken,
      video: {
        id: uploadId,           
        videoId: video.id,      
        title: video.title,
        duration: video.duration,
        thumbnailUrl: asset.thumbnailUrl,
      },
    })
  );
});


export const saveWatchProgress = asyncHandler(
  async (req: Request, res: Response) => {
    const uploadId = req.params.id;
    const {
      position,
      duration,
      completed = false,
      videoAssetId,
      sessionToken,
      videoId: bodyVideoId,
      profileId,          // ← yeh add karo
    } = req.body;

    const userId = (req as any).user?.id;

    if (!userId)
      throw new ApiError(HTTP_STATUS.UNAUTHORIZED, "Login required");
    if (position === undefined)
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "position is required");
    if (!videoAssetId)
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "videoAssetId is required");

    const getString = (val: any) =>
      Array.isArray(val) ? val[0] : (val ?? null);

    let resolvedVideoId: string;

    if (bodyVideoId) {
      resolvedVideoId = getString(bodyVideoId)!;
    } else {
      const video = await db
        .select({ id: videos.id })
        .from(videos)
        .where(eq(videos.uploadId, getString(uploadId)!))
        .limit(1)
        .then((r) => r[0]);

      if (!video)
        throw new ApiError(HTTP_STATUS.NOT_FOUND, "Video not found");

      resolvedVideoId = video.id;
    }

    await db
      .insert(watchHistory)
      .values({
        userId: getString(userId)!,
        profileId: getString(profileId) ?? null,   // ← yeh add karo
        videoId: resolvedVideoId,
        videoAssetId: getString(videoAssetId)!,
        position: Number(position),
        duration: duration ? Number(duration) : null,
        completed,
        ipAddress: getString(req.ip),
        userAgent: getString(req.headers["user-agent"]),
      })
      .onConflictDoUpdate({
        target: [
          watchHistory.userId,
          watchHistory.videoId,
          watchHistory.videoAssetId,
        ],
        set: {
          profileId: getString(profileId) ?? null,  // ← yeh bhi
          position: Number(position),
          completed,
          watchedAt: new Date(),
        },
      });

    if (sessionToken) {
      await db
        .update(streamingSessions)
        .set({
          lastHeartbeat: new Date(),
          totalWatchTime: sql`total_watch_time + ${Math.round(Number(position))}`,
        })
        .where(eq(streamingSessions.sessionToken, getString(sessionToken)!));
    }

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Progress saved", {
        position,
        completed,
      })
    );
  }
);  


export const endStreamingSession = asyncHandler(
  async (req: Request, res: Response) => {
    const { sessionToken } = req.body;

    if (!sessionToken)
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "sessionToken is required");

    await db
      .update(streamingSessions)
      .set({ endedAt: new Date() })
      .where(eq(streamingSessions.sessionToken, sessionToken));

    return res
      .status(HTTP_STATUS.OK)
      .json(new ApiResponse(HTTP_STATUS.OK, "Session ended", {}));
  },
);

export const getWatchHistory = asyncHandler(
  async (req: Request, res: Response) => {
    const userId = (req as any).user?.id;

    if (!userId) throw new ApiError(HTTP_STATUS.UNAUTHORIZED, "Login required");

    const page = Math.max(1, Number(req.query.page) || 1);
    const limit = Math.min(50, Number(req.query.limit) || 20);
    const offset = (page - 1) * limit;

    const history = await db
      .select()
      .from(watchHistory)
      .where(eq(watchHistory.userId, userId))
      .orderBy(desc(watchHistory.watchedAt))
      .limit(limit)
      .offset(offset);

    const videoIds = [...new Set(history.map((h) => h.videoId))];

    const videoRows = videoIds.length
      ? await db.select().from(videos).where(inArray(videos.id, videoIds))
      : [];

    const videoMap = new Map(videoRows.map((v) => [v.id, v]));

    const result = history.map((h) => ({
      ...h,
      video: videoMap.get(h.videoId) ?? null,
    }));

    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Watch history fetched", {
        history: result,
        pagination: { page, limit },
      }),
    );
  },
);

export const getHomeContentByProfile = asyncHandler(async (req, res) => {
  const { profileId } = req.params;

  const page = Number(req.query.page) || 1;
  const limit = Number(req.query.limit) || 20;
  const offset = (page - 1) * limit;

  const profileIdStr = Array.isArray(profileId) ? profileId[0] : profileId;

  const profile = await db.query.profiles.findFirst({
    where: eq(profiles.id, profileIdStr),
  });

  if (!profile) {
    throw new ApiError(404, "Profile not found");
  }

  const userGenres = (profile.genresIds || [])
    .flat()
    .filter(Boolean) as string[];

  if (userGenres.length === 0) {
    throw new ApiError(400, "No genres selected for this profile");
  }

  const allGenres = await db.select().from(genres);

  const genreMap = new Map<string, string>();
  for (const g of allGenres) {
    if (g.id) genreMap.set(g.id, g.name);
  }

  const allContent = await db
    .select({
      id: uploads.id,
      title: uploads.title,
      type: uploads.type,
      description: uploads.description,
      genreId: uploads.genreId,
      languageId: uploads.languageId,
      metadata: uploads.metadata,
      createdAt: uploads.createdAt,
    })
    .from(uploads)
    .where(
      and(
        inArray(uploads.genreId, userGenres),
        eq(uploads.deletedFlg, false),
        eq(uploads.status, "PUBLISHED"),
      ),
    )
    .orderBy(desc(uploads.createdAt))
    .limit(limit)
    .offset(offset);

  const homeContent: Record<string, any> = {};

  for (const item of allContent) {
    const genreKey = item.genreId ?? "unknown";

    const genreName = genreMap.get(genreKey) ?? "Unknown";

    const meta = (item.metadata as any) || {};

    const formattedItem = {
      id: item.id,
      title: item.title,
      type: item.type,
      description: item.description,

      thumbnail: meta.thumbnail ?? meta.poster ?? null,
      poster: meta.poster ?? null,

      rating: meta.rating ?? null,
      duration: meta.duration ?? null,
      releaseYear: meta.releaseYear ?? null,
      ageRating: meta.ageRating ?? null,

      seasons: meta.seasons ?? null,
      episodes: meta.episodes ?? null,

      director: meta.director ?? null,
      cast: meta.cast ?? [],

      isWatched: false,
      watchProgress: 0,
    };

    if (!homeContent[genreName]) {
      homeContent[genreName] = {
        genreId: genreKey,
        totalItems: 0,
        items: [],
      };
    }

    homeContent[genreName].items.push(formattedItem);
    homeContent[genreName].totalItems++;
  }

  return res.status(200).json(
    new ApiResponse(200, "Home content fetched successfully", {
      profileId: profile.id,
      profileName: profile.profileName,
      homeContent,
      pagination: {
        page,
        limit,
      },
    }),
  );
});


//webseries detail api 
// ─── Show Helpers ────────────────────────────────────────────────────────────
const buildShowDetailPayload = async (
  showId: string,
): Promise<ShowDetailGroup> => {
 const show = await db
  .select()
  .from(shows)
  .where(
    and(
      eq(shows.id, showId),
      eq(shows.deletedFlg, false),
      eq(shows.status, "PUBLISHED")
    )
  )
  .limit(1)
  .then((r) => r[0] ?? null); 
  if (!show) throw new ApiError(HTTP_STATUS.NOT_FOUND, "Show not found");

  const episodeRows = await db
    .select()
    .from(uploads)
    .where(
      and(
        eq(uploads.showId, showId),
        eq(uploads.deletedFlg, false),
        eq(uploads.contentKind, "EPISODE"),
      ),
    )
    .orderBy(uploads.seasonNumber, uploads.episodeNumber);

  const episodeIds = episodeRows.map((episode) => episode.id);

  const episodeAssets = episodeIds.length
    ? await db
      .select()
      .from(uploadAssets)
      .where(
        and(
          inArray(uploadAssets.uploadId, episodeIds),
          eq(uploadAssets.deletedFlg, false),
        ),
      )
    : [];

  const assetsByEpisodeId = episodeAssets.reduce<
    Record<string, (typeof uploadAssets.$inferSelect)[]>
  >((acc, asset) => {
    (acc[asset.uploadId] ??= []).push(asset);
    return acc;
  }, {});

  const episodesWithAssets: UploadWithAssets[] = episodeRows.map((episode) => ({
    ...episode,
    assets: assetsByEpisodeId[episode.id] ?? [],
  }));

  const seasons: SeasonGroup[] = Array.from(
    episodesWithAssets
      .reduce<Map<number, SeasonGroup>>((acc, episode) => {
        if (episode.seasonNumber == null) return acc;
        const seasonNumber = episode.seasonNumber;
        let seasonGroup = acc.get(seasonNumber);
        if (!seasonGroup) {
          seasonGroup = { seasonNumber, totalEpisodes: 0, episodes: [] };
          acc.set(seasonNumber, seasonGroup);
        }
        seasonGroup.episodes.push(episode);
        seasonGroup.totalEpisodes++;
        return acc;
      }, new Map<number, SeasonGroup>())
      .values(),
  )
    .map((sg) => ({
      ...sg,
      episodes: sg.episodes.sort(
        (a, b) => (a.episodeNumber ?? 0) - (b.episodeNumber ?? 0),
      ),
    }))
    .sort((a, b) => a.seasonNumber - b.seasonNumber);

  return {
    ...show,
    totalSeasons: show.totalSeasons ?? seasons.length,
    seasons,
  };
};

export const getWebSeriesDetailById = asyncHandler(
  async (req: Request, res: Response) => {
    const showId = req.params.id;
    if (!showId)
      throw new ApiError(HTTP_STATUS.BAD_REQUEST, "showId is required");
    const show = await buildShowDetailPayload(showId as string);
    return res.status(HTTP_STATUS.OK).json(
      new ApiResponse(HTTP_STATUS.OK, "Web series detail fetched", {
        contentKind: "EPISODE",
        show,
      }),
    );
  },
);



